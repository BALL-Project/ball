/* A Bison parser, made by GNU Bison 1.875d.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TK_OPTIONS = 258,
     TK_NOEMITTERS = 259,
     TK_DOC = 260,
     TK_EXPORTEDDOC = 261,
     TK_MAKEFILE = 262,
     TK_ACCESSCODE = 263,
     TK_GETCODE = 264,
     TK_SETCODE = 265,
     TK_PREINITCODE = 266,
     TK_POSTINITCODE = 267,
     TK_UNITCODE = 268,
     TK_MODCODE = 269,
     TK_TYPECODE = 270,
     TK_PREPYCODE = 271,
     TK_COPYING = 272,
     TK_MAPPEDTYPE = 273,
     TK_CODELINE = 274,
     TK_IF = 275,
     TK_END = 276,
     TK_NAME = 277,
     TK_PATHNAME = 278,
     TK_STRING = 279,
     TK_VIRTUALCATCHERCODE = 280,
     TK_TRAVERSECODE = 281,
     TK_CLEARCODE = 282,
     TK_READBUFFERCODE = 283,
     TK_WRITEBUFFERCODE = 284,
     TK_SEGCOUNTCODE = 285,
     TK_CHARBUFFERCODE = 286,
     TK_METHODCODE = 287,
     TK_FROMTYPE = 288,
     TK_TOTYPE = 289,
     TK_TOSUBCLASS = 290,
     TK_INCLUDE = 291,
     TK_OPTINCLUDE = 292,
     TK_IMPORT = 293,
     TK_EXPHEADERCODE = 294,
     TK_MODHEADERCODE = 295,
     TK_TYPEHEADERCODE = 296,
     TK_MODULE = 297,
     TK_CMODULE = 298,
     TK_CLASS = 299,
     TK_STRUCT = 300,
     TK_PUBLIC = 301,
     TK_PROTECTED = 302,
     TK_PRIVATE = 303,
     TK_SIGNALS = 304,
     TK_SLOTS = 305,
     TK_BOOL = 306,
     TK_SHORT = 307,
     TK_INT = 308,
     TK_LONG = 309,
     TK_FLOAT = 310,
     TK_DOUBLE = 311,
     TK_CHAR = 312,
     TK_VOID = 313,
     TK_PYOBJECT = 314,
     TK_PYTUPLE = 315,
     TK_PYLIST = 316,
     TK_PYDICT = 317,
     TK_PYCALLABLE = 318,
     TK_PYSLICE = 319,
     TK_PYTYPE = 320,
     TK_VIRTUAL = 321,
     TK_ENUM = 322,
     TK_SIGNED = 323,
     TK_UNSIGNED = 324,
     TK_SCOPE = 325,
     TK_LOGICAL_OR = 326,
     TK_CONST = 327,
     TK_STATIC = 328,
     TK_SIPSIGNAL = 329,
     TK_SIPSLOT = 330,
     TK_SIPANYSLOT = 331,
     TK_SIPRXCON = 332,
     TK_SIPRXDIS = 333,
     TK_SIPSLOTCON = 334,
     TK_SIPSLOTDIS = 335,
     TK_NUMBER = 336,
     TK_REAL = 337,
     TK_TYPEDEF = 338,
     TK_NAMESPACE = 339,
     TK_TIMELINE = 340,
     TK_PLATFORMS = 341,
     TK_FEATURE = 342,
     TK_LICENSE = 343,
     TK_QCHAR = 344,
     TK_TRUE = 345,
     TK_FALSE = 346,
     TK_NULL = 347,
     TK_OPERATOR = 348,
     TK_THROW = 349,
     TK_QOBJECT = 350,
     TK_EXCEPTION = 351,
     TK_RAISECODE = 352,
     TK_EXPLICIT = 353,
     TK_TEMPLATE = 354,
     TK_ELLIPSIS = 355
   };
#endif
#define TK_OPTIONS 258
#define TK_NOEMITTERS 259
#define TK_DOC 260
#define TK_EXPORTEDDOC 261
#define TK_MAKEFILE 262
#define TK_ACCESSCODE 263
#define TK_GETCODE 264
#define TK_SETCODE 265
#define TK_PREINITCODE 266
#define TK_POSTINITCODE 267
#define TK_UNITCODE 268
#define TK_MODCODE 269
#define TK_TYPECODE 270
#define TK_PREPYCODE 271
#define TK_COPYING 272
#define TK_MAPPEDTYPE 273
#define TK_CODELINE 274
#define TK_IF 275
#define TK_END 276
#define TK_NAME 277
#define TK_PATHNAME 278
#define TK_STRING 279
#define TK_VIRTUALCATCHERCODE 280
#define TK_TRAVERSECODE 281
#define TK_CLEARCODE 282
#define TK_READBUFFERCODE 283
#define TK_WRITEBUFFERCODE 284
#define TK_SEGCOUNTCODE 285
#define TK_CHARBUFFERCODE 286
#define TK_METHODCODE 287
#define TK_FROMTYPE 288
#define TK_TOTYPE 289
#define TK_TOSUBCLASS 290
#define TK_INCLUDE 291
#define TK_OPTINCLUDE 292
#define TK_IMPORT 293
#define TK_EXPHEADERCODE 294
#define TK_MODHEADERCODE 295
#define TK_TYPEHEADERCODE 296
#define TK_MODULE 297
#define TK_CMODULE 298
#define TK_CLASS 299
#define TK_STRUCT 300
#define TK_PUBLIC 301
#define TK_PROTECTED 302
#define TK_PRIVATE 303
#define TK_SIGNALS 304
#define TK_SLOTS 305
#define TK_BOOL 306
#define TK_SHORT 307
#define TK_INT 308
#define TK_LONG 309
#define TK_FLOAT 310
#define TK_DOUBLE 311
#define TK_CHAR 312
#define TK_VOID 313
#define TK_PYOBJECT 314
#define TK_PYTUPLE 315
#define TK_PYLIST 316
#define TK_PYDICT 317
#define TK_PYCALLABLE 318
#define TK_PYSLICE 319
#define TK_PYTYPE 320
#define TK_VIRTUAL 321
#define TK_ENUM 322
#define TK_SIGNED 323
#define TK_UNSIGNED 324
#define TK_SCOPE 325
#define TK_LOGICAL_OR 326
#define TK_CONST 327
#define TK_STATIC 328
#define TK_SIPSIGNAL 329
#define TK_SIPSLOT 330
#define TK_SIPANYSLOT 331
#define TK_SIPRXCON 332
#define TK_SIPRXDIS 333
#define TK_SIPSLOTCON 334
#define TK_SIPSLOTDIS 335
#define TK_NUMBER 336
#define TK_REAL 337
#define TK_TYPEDEF 338
#define TK_NAMESPACE 339
#define TK_TIMELINE 340
#define TK_PLATFORMS 341
#define TK_FEATURE 342
#define TK_LICENSE 343
#define TK_QCHAR 344
#define TK_TRUE 345
#define TK_FALSE 346
#define TK_NULL 347
#define TK_OPERATOR 348
#define TK_THROW 349
#define TK_QOBJECT 350
#define TK_EXCEPTION 351
#define TK_RAISECODE 352
#define TK_EXPLICIT 353
#define TK_TEMPLATE 354
#define TK_ELLIPSIS 355




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 102 "parser.y"
typedef union YYSTYPE {
    char            qchar;
    char            *text;
    long            number;
    double          real;
    argDef          memArg;
    signatureDef    signature;
    signatureDef    *optsignature;
    throwArgs       *throwlist;
    codeBlock       *codeb;
    valueDef        value;
    valueDef        *valp;
    optFlags        optflags;
    optFlag         flag;
    scopedNameDef   *scpvalp;
    fcallDef        fcall;
    int             boolean;
    exceptionDef    exceptionbase;
    classDef        *klass;
} YYSTYPE;
/* Line 1285 of yacc.c.  */
#line 258 "parser.h"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;



