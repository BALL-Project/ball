/* A Bison parser, made by GNU Bison 1.875d.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Written by Richard Stallman by simplifying the original so called
   ``semantic'' parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TK_OPTIONS = 258,
     TK_NOEMITTERS = 259,
     TK_DOC = 260,
     TK_EXPORTEDDOC = 261,
     TK_MAKEFILE = 262,
     TK_ACCESSCODE = 263,
     TK_GETCODE = 264,
     TK_SETCODE = 265,
     TK_PREINITCODE = 266,
     TK_POSTINITCODE = 267,
     TK_UNITCODE = 268,
     TK_MODCODE = 269,
     TK_TYPECODE = 270,
     TK_PREPYCODE = 271,
     TK_COPYING = 272,
     TK_MAPPEDTYPE = 273,
     TK_CODELINE = 274,
     TK_IF = 275,
     TK_END = 276,
     TK_NAME = 277,
     TK_PATHNAME = 278,
     TK_STRING = 279,
     TK_VIRTUALCATCHERCODE = 280,
     TK_TRAVERSECODE = 281,
     TK_CLEARCODE = 282,
     TK_READBUFFERCODE = 283,
     TK_WRITEBUFFERCODE = 284,
     TK_SEGCOUNTCODE = 285,
     TK_CHARBUFFERCODE = 286,
     TK_METHODCODE = 287,
     TK_FROMTYPE = 288,
     TK_TOTYPE = 289,
     TK_TOSUBCLASS = 290,
     TK_INCLUDE = 291,
     TK_OPTINCLUDE = 292,
     TK_IMPORT = 293,
     TK_EXPHEADERCODE = 294,
     TK_MODHEADERCODE = 295,
     TK_TYPEHEADERCODE = 296,
     TK_MODULE = 297,
     TK_CMODULE = 298,
     TK_CLASS = 299,
     TK_STRUCT = 300,
     TK_PUBLIC = 301,
     TK_PROTECTED = 302,
     TK_PRIVATE = 303,
     TK_SIGNALS = 304,
     TK_SLOTS = 305,
     TK_BOOL = 306,
     TK_SHORT = 307,
     TK_INT = 308,
     TK_LONG = 309,
     TK_FLOAT = 310,
     TK_DOUBLE = 311,
     TK_CHAR = 312,
     TK_VOID = 313,
     TK_PYOBJECT = 314,
     TK_PYTUPLE = 315,
     TK_PYLIST = 316,
     TK_PYDICT = 317,
     TK_PYCALLABLE = 318,
     TK_PYSLICE = 319,
     TK_PYTYPE = 320,
     TK_VIRTUAL = 321,
     TK_ENUM = 322,
     TK_SIGNED = 323,
     TK_UNSIGNED = 324,
     TK_SCOPE = 325,
     TK_LOGICAL_OR = 326,
     TK_CONST = 327,
     TK_STATIC = 328,
     TK_SIPSIGNAL = 329,
     TK_SIPSLOT = 330,
     TK_SIPANYSLOT = 331,
     TK_SIPRXCON = 332,
     TK_SIPRXDIS = 333,
     TK_SIPSLOTCON = 334,
     TK_SIPSLOTDIS = 335,
     TK_NUMBER = 336,
     TK_REAL = 337,
     TK_TYPEDEF = 338,
     TK_NAMESPACE = 339,
     TK_TIMELINE = 340,
     TK_PLATFORMS = 341,
     TK_FEATURE = 342,
     TK_LICENSE = 343,
     TK_QCHAR = 344,
     TK_TRUE = 345,
     TK_FALSE = 346,
     TK_NULL = 347,
     TK_OPERATOR = 348,
     TK_THROW = 349,
     TK_QOBJECT = 350,
     TK_EXCEPTION = 351,
     TK_RAISECODE = 352,
     TK_EXPLICIT = 353,
     TK_TEMPLATE = 354,
     TK_ELLIPSIS = 355
   };
#endif
#define TK_OPTIONS 258
#define TK_NOEMITTERS 259
#define TK_DOC 260
#define TK_EXPORTEDDOC 261
#define TK_MAKEFILE 262
#define TK_ACCESSCODE 263
#define TK_GETCODE 264
#define TK_SETCODE 265
#define TK_PREINITCODE 266
#define TK_POSTINITCODE 267
#define TK_UNITCODE 268
#define TK_MODCODE 269
#define TK_TYPECODE 270
#define TK_PREPYCODE 271
#define TK_COPYING 272
#define TK_MAPPEDTYPE 273
#define TK_CODELINE 274
#define TK_IF 275
#define TK_END 276
#define TK_NAME 277
#define TK_PATHNAME 278
#define TK_STRING 279
#define TK_VIRTUALCATCHERCODE 280
#define TK_TRAVERSECODE 281
#define TK_CLEARCODE 282
#define TK_READBUFFERCODE 283
#define TK_WRITEBUFFERCODE 284
#define TK_SEGCOUNTCODE 285
#define TK_CHARBUFFERCODE 286
#define TK_METHODCODE 287
#define TK_FROMTYPE 288
#define TK_TOTYPE 289
#define TK_TOSUBCLASS 290
#define TK_INCLUDE 291
#define TK_OPTINCLUDE 292
#define TK_IMPORT 293
#define TK_EXPHEADERCODE 294
#define TK_MODHEADERCODE 295
#define TK_TYPEHEADERCODE 296
#define TK_MODULE 297
#define TK_CMODULE 298
#define TK_CLASS 299
#define TK_STRUCT 300
#define TK_PUBLIC 301
#define TK_PROTECTED 302
#define TK_PRIVATE 303
#define TK_SIGNALS 304
#define TK_SLOTS 305
#define TK_BOOL 306
#define TK_SHORT 307
#define TK_INT 308
#define TK_LONG 309
#define TK_FLOAT 310
#define TK_DOUBLE 311
#define TK_CHAR 312
#define TK_VOID 313
#define TK_PYOBJECT 314
#define TK_PYTUPLE 315
#define TK_PYLIST 316
#define TK_PYDICT 317
#define TK_PYCALLABLE 318
#define TK_PYSLICE 319
#define TK_PYTYPE 320
#define TK_VIRTUAL 321
#define TK_ENUM 322
#define TK_SIGNED 323
#define TK_UNSIGNED 324
#define TK_SCOPE 325
#define TK_LOGICAL_OR 326
#define TK_CONST 327
#define TK_STATIC 328
#define TK_SIPSIGNAL 329
#define TK_SIPSLOT 330
#define TK_SIPANYSLOT 331
#define TK_SIPRXCON 332
#define TK_SIPRXDIS 333
#define TK_SIPSLOTCON 334
#define TK_SIPSLOTDIS 335
#define TK_NUMBER 336
#define TK_REAL 337
#define TK_TYPEDEF 338
#define TK_NAMESPACE 339
#define TK_TIMELINE 340
#define TK_PLATFORMS 341
#define TK_FEATURE 342
#define TK_LICENSE 343
#define TK_QCHAR 344
#define TK_TRUE 345
#define TK_FALSE 346
#define TK_NULL 347
#define TK_OPERATOR 348
#define TK_THROW 349
#define TK_QOBJECT 350
#define TK_EXCEPTION 351
#define TK_RAISECODE 352
#define TK_EXPLICIT 353
#define TK_TEMPLATE 354
#define TK_ELLIPSIS 355




/* Copy the first part of user declarations.  */
#line 16 "parser.y"

#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "sip.h"


#define MAX_NESTED_IF       10
#define MAX_NESTED_SCOPE    10

#define inMainModule()      (currentSpec -> module == currentModule)


static sipSpec *currentSpec;            /* The current spec being parsed. */
static stringList *neededQualifiers;    /* The list of required qualifiers. */
static stringList *excludedQualifiers;  /* The list of excluded qualifiers. */
static moduleDef *currentModule;        /* The current module being parsed. */
static mappedTypeDef *currentMappedType;    /* The current mapped type. */
static enumDef *currentEnum;            /* The current enum being parsed. */
static int sectionFlags;                /* The current section flags. */
static int currentOverIsVirt;           /* Set if the overload is virtual. */
static int currentCtorIsExplicit;       /* Set if the ctor is explicit. */
static int currentIsStatic;             /* Set if the current is static. */
static char *previousFile;              /* The file just parsed. */
static parserContext newContext;        /* The new pending context. */
static int skipStackPtr;                /* The skip stack pointer. */
static int skipStack[MAX_NESTED_IF];    /* Stack of skip flags. */
static classDef *scopeStack[MAX_NESTED_SCOPE];  /* The scope stack. */
static int sectFlagsStack[MAX_NESTED_SCOPE];    /* The section flags stack. */
static int currentScopeIdx;             /* The scope stack index. */
static int currentTimelineOrder;        /* The current timeline order. */


static char *getPythonName(optFlags *optflgs, char *cname);
static nameDef *cacheName(sipSpec *,char *);
static classDef *findClass(sipSpec *,ifaceFileType,scopedNameDef *);
static classDef *findClassWithInterface(sipSpec *pt, ifaceFileDef *iff);
static classDef *newClass(sipSpec *,ifaceFileType,scopedNameDef *);
static void finishClass(sipSpec *,moduleDef *,classDef *,optFlags *);
static exceptionDef *findException(sipSpec *pt, scopedNameDef *fqname, int new);
static mappedTypeDef *newMappedType(sipSpec *,argDef *);
static enumDef *newEnum(sipSpec *,moduleDef *,char *,optFlags *,int);
static void instantiateClassTemplate(sipSpec *pt, moduleDef *mod, classDef *scope, scopedNameDef *fqname, classTmplDef *tcd, templateDef *td);
static void newTypedef(sipSpec *,moduleDef *,char *,argDef *);
static void newVar(sipSpec *,moduleDef *,char *,int,argDef *,optFlags *,
           codeBlock *,codeBlock *,codeBlock *);
static void newCtor(char *,int,signatureDef *,optFlags *,codeBlock *,
            throwArgs *,signatureDef *,int);
static void newFunction(sipSpec *,moduleDef *,int,int,int,char *,
            signatureDef *,int,int,optFlags *,codeBlock *,
            codeBlock *,throwArgs *,signatureDef *);
static optFlag *findOptFlag(optFlags *,char *,flagType);
static memberDef *findFunction(sipSpec *,moduleDef *,classDef *,nameDef *,int,
                   int);
static void checkAttributes(sipSpec *,classDef *,char *,int);
static void newModule(FILE *,char *);
static void appendCodeBlock(codeBlock **,codeBlock *);
static void parseFile(FILE *,char *,moduleDef *,int);
static void handleEOF(void);
static void handleEOM(void);
static qualDef *findQualifier(char *);
static scopedNameDef *text2scopedName(char *);
static scopedNameDef *scopeScopedName(scopedNameDef *name);
static void pushScope(classDef *);
static void popScope(void);
static classDef *currentScope(void);
static void newQualifier(moduleDef *,int,int,char *,qualType);
static void newImport(char *);
static void usedInMainModule(sipSpec *,ifaceFileDef *);
static int timePeriod(char *,char *);
static int platOrFeature(char *,int);
static int isNeeded(qualDef *);
static int notSkipping(void);
static void getHooks(optFlags *,char **,char **);
static int getReleaseGIL(optFlags *);
static void templateSignature(signatureDef *sd, int result, classTmplDef *tcd, templateDef *td, classDef *ncd);
static void templateType(argDef *ad, classTmplDef *tcd, templateDef *td, classDef *ncd);
static int search_back(const char *end, const char *start, const char *target);
static char *getType(scopedNameDef *ename, argDef *ad);
static char *scopedNameToString(scopedNameDef *name);
static void addUsedFromCode(sipSpec *pt, ifaceFileList **used, const char *sname);
static int sameName(scopedNameDef *snd, const char *sname);
static int optFind(sipSpec *pt, const char *opt);


/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 102 "parser.y"
typedef union YYSTYPE {
    char            qchar;
    char            *text;
    long            number;
    double          real;
    argDef          memArg;
    signatureDef    signature;
    signatureDef    *optsignature;
    throwArgs       *throwlist;
    codeBlock       *codeb;
    valueDef        value;
    valueDef        *valp;
    optFlags        optflags;
    optFlag         flag;
    scopedNameDef   *scpvalp;
    fcallDef        fcall;
    int             boolean;
    exceptionDef    exceptionbase;
    classDef        *klass;
} YYSTYPE;
/* Line 191 of yacc.c.  */
#line 383 "parser.c"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 214 of yacc.c.  */
#line 395 "parser.c"

#if ! defined (yyoverflow) || YYERROR_VERBOSE

# ifndef YYFREE
#  define YYFREE free
# endif
# ifndef YYMALLOC
#  define YYMALLOC malloc
# endif

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   define YYSTACK_ALLOC alloca
#  endif
# else
#  if defined (alloca) || defined (_ALLOCA_H)
#   define YYSTACK_ALLOC alloca
#  else
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
# else
#  if defined (__STDC__) || defined (__cplusplus)
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   define YYSIZE_T size_t
#  endif
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
# endif
#endif /* ! defined (yyoverflow) || YYERROR_VERBOSE */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (defined (YYSTYPE_IS_TRIVIAL) && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short int yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short int) + sizeof (YYSTYPE))			\
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined (__GNUC__) && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  register YYSIZE_T yyi;		\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif

#if defined (__STDC__) || defined (__cplusplus)
   typedef signed char yysigned_char;
#else
   typedef short int yysigned_char;
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  4
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1141

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  123
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  134
/* YYNRULES -- Number of rules. */
#define YYNRULES  338
/* YYNRULES -- Number of states. */
#define YYNSTATES  561

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   355

#define YYTRANSLATE(YYX) 						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   107,     2,     2,     2,   121,   113,     2,
     101,   102,   111,   110,   103,   108,     2,   112,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,   118,   106,
     116,   109,   117,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,   119,     2,   120,   122,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   104,   114,   105,   115,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short int yyprhs[] =
{
       0,     0,     3,     5,     8,     9,    12,    14,    16,    18,
      20,    22,    24,    26,    28,    30,    32,    34,    36,    38,
      40,    42,    44,    46,    48,    50,    52,    54,    56,    58,
      60,    62,    64,    66,    68,    70,    72,    74,    76,    78,
      80,    82,    84,    89,    91,    95,    97,   107,   108,   112,
     115,   116,   121,   122,   128,   133,   135,   138,   140,   143,
     146,   147,   155,   157,   160,   161,   167,   169,   172,   174,
     177,   178,   184,   186,   189,   191,   196,   198,   201,   205,
     210,   212,   216,   218,   221,   225,   227,   229,   231,   233,
     234,   236,   239,   242,   245,   246,   249,   250,   253,   254,
     257,   260,   263,   266,   269,   270,   272,   275,   278,   281,
     284,   287,   290,   293,   296,   299,   302,   305,   308,   311,
     314,   319,   322,   324,   327,   328,   337,   338,   340,   341,
     343,   344,   346,   348,   351,   353,   355,   360,   361,   363,
     364,   367,   368,   371,   373,   377,   379,   381,   383,   385,
     387,   389,   390,   392,   394,   396,   398,   401,   403,   407,
     409,   411,   416,   418,   420,   422,   424,   426,   428,   430,
     431,   433,   437,   442,   453,   454,   463,   466,   471,   472,
     480,   481,   484,   486,   490,   492,   493,   497,   499,   502,
     504,   506,   508,   510,   512,   514,   516,   518,   520,   522,
     524,   526,   528,   530,   532,   534,   536,   538,   540,   543,
     546,   550,   554,   558,   561,   562,   564,   576,   577,   581,
     583,   593,   594,   600,   601,   608,   609,   611,   625,   640,
     654,   656,   658,   660,   662,   664,   666,   668,   670,   673,
     676,   679,   682,   685,   688,   691,   694,   697,   700,   704,
     708,   710,   713,   716,   718,   721,   724,   727,   729,   732,
     733,   735,   736,   739,   740,   744,   746,   750,   752,   756,
     758,   760,   762,   763,   766,   767,   770,   772,   773,   775,
     779,   783,   787,   791,   794,   797,   803,   809,   812,   815,
     816,   820,   822,   824,   826,   827,   831,   833,   841,   846,
     850,   854,   855,   857,   858,   861,   863,   868,   871,   874,
     876,   878,   881,   883,   885,   888,   891,   895,   897,   899,
     901,   904,   907,   909,   911,   913,   915,   917,   919,   921,
     923,   925,   927,   929,   933,   934,   939,   940,   942
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const short int yyrhs[] =
{
     124,     0,    -1,   125,    -1,   124,   125,    -1,    -1,   126,
     127,    -1,   159,    -1,   129,    -1,   131,    -1,   169,    -1,
     163,    -1,   164,    -1,   165,    -1,   150,    -1,   145,    -1,
     149,    -1,   158,    -1,   170,    -1,   171,    -1,   180,    -1,
     182,    -1,   183,    -1,   184,    -1,   185,    -1,   186,    -1,
     187,    -1,   188,    -1,   135,    -1,   137,    -1,   128,    -1,
     154,    -1,   157,    -1,   142,    -1,   210,    -1,   214,    -1,
     212,    -1,   132,    -1,   209,    -1,   191,    -1,   230,    -1,
     248,    -1,   172,    -1,     3,   101,   130,   102,    -1,    22,
      -1,   130,   103,    22,    -1,     4,    -1,    96,   205,   133,
     234,   104,   173,   134,   105,   106,    -1,    -1,   101,   205,
     102,    -1,    97,   189,    -1,    -1,    18,   253,   136,   139,
      -1,    -1,   213,    18,   253,   138,   139,    -1,   104,   140,
     105,   106,    -1,   141,    -1,   140,   141,    -1,   172,    -1,
      33,   189,    -1,    34,   189,    -1,    -1,    84,    22,   143,
     104,   144,   105,   106,    -1,   128,    -1,   144,   128,    -1,
      -1,    86,   146,   104,   147,   105,    -1,   148,    -1,   147,
     148,    -1,    22,    -1,    87,    22,    -1,    -1,    85,   151,
     104,   152,   105,    -1,   153,    -1,   152,   153,    -1,    22,
      -1,    20,   101,   156,   102,    -1,    22,    -1,   107,    22,
      -1,   155,    71,    22,    -1,   155,    71,   107,    22,    -1,
     155,    -1,   194,   108,   194,    -1,    21,    -1,    88,   234,
      -1,   160,   161,   162,    -1,    42,    -1,    43,    -1,    22,
      -1,    23,    -1,    -1,    81,    -1,    36,    23,    -1,    37,
      23,    -1,    38,    23,    -1,    -1,     8,   189,    -1,    -1,
       9,   189,    -1,    -1,    10,   189,    -1,    17,   189,    -1,
      39,   189,    -1,    40,   189,    -1,    41,   189,    -1,    -1,
     172,    -1,    26,   189,    -1,    27,   189,    -1,    28,   189,
      -1,    29,   189,    -1,    30,   189,    -1,    31,   189,    -1,
      14,   189,    -1,    15,   189,    -1,    11,   189,    -1,    12,
     189,    -1,    13,   189,    -1,    16,   189,    -1,     5,   189,
      -1,     6,   189,    -1,     7,    23,   193,   189,    -1,   190,
      21,    -1,    19,    -1,   190,    19,    -1,    -1,    67,   194,
     234,   192,   104,   195,   105,   106,    -1,    -1,    23,    -1,
      -1,    22,    -1,    -1,   196,    -1,   197,    -1,   196,   197,
      -1,   154,    -1,   157,    -1,    22,   199,   234,   198,    -1,
      -1,   103,    -1,    -1,   109,   204,    -1,    -1,   109,   201,
      -1,   204,    -1,   201,   202,   204,    -1,   108,    -1,   110,
      -1,   111,    -1,   112,    -1,   113,    -1,   114,    -1,    -1,
     107,    -1,   115,    -1,   108,    -1,   110,    -1,   203,   207,
      -1,   206,    -1,   205,    70,   206,    -1,    22,    -1,   205,
      -1,   253,   101,   208,   102,    -1,    82,    -1,    81,    -1,
      90,    -1,    91,    -1,    92,    -1,    24,    -1,    89,    -1,
      -1,   201,    -1,   208,   103,   201,    -1,    83,   249,    22,
     106,    -1,    83,   249,   101,   252,    22,   102,   101,   254,
     102,   106,    -1,    -1,    45,    22,   211,   234,   104,   220,
     105,   106,    -1,   213,   214,    -1,    99,   116,   254,   117,
      -1,    -1,    44,   205,   215,   216,   234,   219,   106,    -1,
      -1,   118,   217,    -1,   218,    -1,   217,   103,   218,    -1,
     205,    -1,    -1,   104,   220,   105,    -1,   221,    -1,   220,
     221,    -1,   154,    -1,   157,    -1,   142,    -1,   210,    -1,
     214,    -1,   132,    -1,   209,    -1,   191,    -1,   181,    -1,
     172,    -1,   174,    -1,   175,    -1,   176,    -1,   177,    -1,
     178,    -1,   179,    -1,   224,    -1,   223,    -1,   243,    -1,
      35,   189,    -1,    34,   189,    -1,    46,   222,   118,    -1,
      47,   222,   118,    -1,    48,   222,   118,    -1,    49,   118,
      -1,    -1,    50,    -1,   229,   115,    22,   101,   102,   255,
     233,   234,   106,   238,   239,    -1,    -1,    98,   225,   226,
      -1,   226,    -1,    22,   101,   240,   102,   255,   234,   227,
     106,   238,    -1,    -1,   119,   101,   240,   102,   120,    -1,
      -1,   119,   249,   101,   240,   102,   120,    -1,    -1,    66,
      -1,   249,    22,   101,   240,   102,   232,   255,   233,   234,
     228,   106,   238,   239,    -1,   249,    93,   231,   101,   240,
     102,   232,   255,   233,   234,   228,   106,   238,   239,    -1,
      93,   249,   101,   240,   102,   232,   255,   233,   234,   228,
     106,   238,   239,    -1,   110,    -1,   108,    -1,   111,    -1,
     112,    -1,   121,    -1,   113,    -1,   114,    -1,   122,    -1,
     116,   116,    -1,   117,   117,    -1,   110,   109,    -1,   108,
     109,    -1,   111,   109,    -1,   112,   109,    -1,   121,   109,
      -1,   113,   109,    -1,   114,   109,    -1,   122,   109,    -1,
     116,   116,   109,    -1,   117,   117,   109,    -1,   115,    -1,
     101,   102,    -1,   119,   120,    -1,   116,    -1,   116,   109,
      -1,   109,   109,    -1,   107,   109,    -1,   117,    -1,   117,
     109,    -1,    -1,    72,    -1,    -1,   109,    81,    -1,    -1,
     112,   235,   112,    -1,   236,    -1,   235,   103,   236,    -1,
      22,    -1,    22,   109,   237,    -1,    22,    -1,    24,    -1,
      81,    -1,    -1,    32,   189,    -1,    -1,    25,   189,    -1,
     241,    -1,    -1,   242,    -1,   241,   103,   242,    -1,    74,
     194,   200,    -1,    75,   194,   200,    -1,    76,   194,   200,
      -1,    77,   194,    -1,    78,   194,    -1,    79,   101,   240,
     102,   194,    -1,    80,   101,   240,   102,   194,    -1,    95,
     194,    -1,   250,   200,    -1,    -1,    73,   244,   245,    -1,
     245,    -1,   246,    -1,   248,    -1,    -1,    66,   247,   230,
      -1,   230,    -1,   249,    22,   234,   106,   166,   167,   168,
      -1,    72,   253,   252,   251,    -1,   253,   252,   251,    -1,
     249,   194,   234,    -1,    -1,   113,    -1,    -1,   252,   111,
      -1,   205,    -1,   205,   116,   254,   117,    -1,    45,   205,
      -1,    69,    52,    -1,    52,    -1,    69,    -1,    69,    53,
      -1,    53,    -1,    54,    -1,    69,    54,    -1,    54,    54,
      -1,    69,    54,    54,    -1,    55,    -1,    56,    -1,    51,
      -1,    68,    57,    -1,    69,    57,    -1,    57,    -1,    58,
      -1,    59,    -1,    60,    -1,    61,    -1,    62,    -1,    63,
      -1,    64,    -1,    65,    -1,   100,    -1,   249,    -1,   254,
     103,   249,    -1,    -1,    94,   101,   256,   102,    -1,    -1,
     205,    -1,   256,   103,   205,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short int yyrline[] =
{
       0,   287,   287,   288,   291,   291,   310,   311,   312,   313,
     314,   315,   316,   317,   318,   319,   320,   321,   325,   329,
     333,   334,   335,   336,   337,   338,   339,   340,   341,   342,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   369,   372,   375,   380,   389,   428,   432,   506,
     511,   511,   517,   517,   556,   570,   571,   574,   578,   587,
     598,   598,   635,   636,   639,   639,   666,   667,   670,   675,
     680,   680,   705,   706,   709,   714,   727,   730,   733,   736,
     741,   742,   747,   753,   780,   805,   808,   813,   814,   830,
     833,   836,   841,   846,   851,   854,   859,   862,   867,   870,
     875,   881,   886,   891,   896,   899,   902,   907,   912,   917,
     922,   927,   932,   937,   942,   948,   954,   960,   969,   975,
     980,   986,   989,   990,  1001,  1001,  1012,  1015,  1020,  1023,
    1028,  1029,  1032,  1033,  1036,  1037,  1038,  1071,  1072,  1075,
    1076,  1079,  1082,  1087,  1088,  1106,  1109,  1112,  1115,  1118,
    1121,  1126,  1129,  1132,  1135,  1138,  1143,  1161,  1162,  1170,
    1175,  1185,  1195,  1199,  1203,  1207,  1211,  1215,  1219,  1225,
    1230,  1236,  1254,  1258,  1281,  1281,  1301,  1326,  1331,  1331,
    1380,  1381,  1384,  1385,  1388,  1403,  1406,  1411,  1412,  1415,
    1416,  1417,  1418,  1419,  1420,  1421,  1422,  1423,  1427,  1431,
    1438,  1445,  1452,  1459,  1466,  1473,  1474,  1475,  1476,  1487,
    1498,  1505,  1512,  1519,  1528,  1531,  1536,  1583,  1583,  1584,
    1587,  1613,  1616,  1623,  1626,  1634,  1637,  1642,  1659,  1684,
    1762,  1763,  1764,  1765,  1766,  1767,  1768,  1769,  1770,  1771,
    1772,  1773,  1774,  1775,  1776,  1777,  1778,  1779,  1780,  1781,
    1782,  1783,  1784,  1785,  1786,  1787,  1788,  1789,  1790,  1793,
    1796,  1801,  1804,  1812,  1815,  1821,  1825,  1837,  1841,  1847,
    1851,  1855,  1861,  1864,  1869,  1872,  1877,  1925,  1930,  1936,
    1963,  1972,  1981,  1990,  1998,  2006,  2021,  2036,  2042,  2048,
    2048,  2049,  2052,  2053,  2056,  2056,  2057,  2060,  2093,  2099,
    2107,  2164,  2167,  2175,  2178,  2183,  2187,  2197,  2210,  2213,
    2216,  2219,  2222,  2225,  2228,  2231,  2234,  2237,  2240,  2243,
    2246,  2249,  2252,  2255,  2258,  2261,  2264,  2267,  2270,  2273,
    2276,  2279,  2284,  2290,  2306,  2309,  2336,  2342,  2349
};
#endif

#if YYDEBUG || YYERROR_VERBOSE
/* YYTNME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "TK_OPTIONS", "TK_NOEMITTERS", "TK_DOC",
  "TK_EXPORTEDDOC", "TK_MAKEFILE", "TK_ACCESSCODE", "TK_GETCODE",
  "TK_SETCODE", "TK_PREINITCODE", "TK_POSTINITCODE", "TK_UNITCODE",
  "TK_MODCODE", "TK_TYPECODE", "TK_PREPYCODE", "TK_COPYING",
  "TK_MAPPEDTYPE", "TK_CODELINE", "TK_IF", "TK_END", "TK_NAME",
  "TK_PATHNAME", "TK_STRING", "TK_VIRTUALCATCHERCODE", "TK_TRAVERSECODE",
  "TK_CLEARCODE", "TK_READBUFFERCODE", "TK_WRITEBUFFERCODE",
  "TK_SEGCOUNTCODE", "TK_CHARBUFFERCODE", "TK_METHODCODE", "TK_FROMTYPE",
  "TK_TOTYPE", "TK_TOSUBCLASS", "TK_INCLUDE", "TK_OPTINCLUDE", "TK_IMPORT",
  "TK_EXPHEADERCODE", "TK_MODHEADERCODE", "TK_TYPEHEADERCODE", "TK_MODULE",
  "TK_CMODULE", "TK_CLASS", "TK_STRUCT", "TK_PUBLIC", "TK_PROTECTED",
  "TK_PRIVATE", "TK_SIGNALS", "TK_SLOTS", "TK_BOOL", "TK_SHORT", "TK_INT",
  "TK_LONG", "TK_FLOAT", "TK_DOUBLE", "TK_CHAR", "TK_VOID", "TK_PYOBJECT",
  "TK_PYTUPLE", "TK_PYLIST", "TK_PYDICT", "TK_PYCALLABLE", "TK_PYSLICE",
  "TK_PYTYPE", "TK_VIRTUAL", "TK_ENUM", "TK_SIGNED", "TK_UNSIGNED",
  "TK_SCOPE", "TK_LOGICAL_OR", "TK_CONST", "TK_STATIC", "TK_SIPSIGNAL",
  "TK_SIPSLOT", "TK_SIPANYSLOT", "TK_SIPRXCON", "TK_SIPRXDIS",
  "TK_SIPSLOTCON", "TK_SIPSLOTDIS", "TK_NUMBER", "TK_REAL", "TK_TYPEDEF",
  "TK_NAMESPACE", "TK_TIMELINE", "TK_PLATFORMS", "TK_FEATURE",
  "TK_LICENSE", "TK_QCHAR", "TK_TRUE", "TK_FALSE", "TK_NULL",
  "TK_OPERATOR", "TK_THROW", "TK_QOBJECT", "TK_EXCEPTION", "TK_RAISECODE",
  "TK_EXPLICIT", "TK_TEMPLATE", "TK_ELLIPSIS", "'('", "')'", "','", "'{'",
  "'}'", "';'", "'!'", "'-'", "'='", "'+'", "'*'", "'/'", "'&'", "'|'",
  "'~'", "'<'", "'>'", "':'", "'['", "']'", "'%'", "'^'", "$accept",
  "specification", "statement", "@1", "modstatement", "nsstatement",
  "options", "optionlist", "noemitters", "exception", "baseexception",
  "raisecode", "mappedtype", "@2", "mappedtypetmpl", "@3", "mtdefinition",
  "mtbody", "mtline", "namespace", "@4", "nsbody", "platforms", "@5",
  "platformlist", "platform", "feature", "timeline", "@6", "qualifierlist",
  "qualifiername", "ifstart", "oredqualifiers", "qualifiers", "ifend",
  "license", "module", "modlang", "modname", "optnumber", "include",
  "optinclude", "import", "optaccesscode", "optgetcode", "optsetcode",
  "copying", "exphdrcode", "modhdrcode", "typehdrcode", "opttypehdrcode",
  "travcode", "clearcode", "readbufcode", "writebufcode", "segcountcode",
  "charbufcode", "modcode", "typecode", "preinitcode", "postinitcode",
  "unitcode", "prepycode", "doc", "exporteddoc", "makefile", "codeblock",
  "codelines", "enum", "@7", "optfilename", "optname", "optenumbody",
  "enumbody", "enumline", "optcomma", "optenumassign", "optassign", "expr",
  "binop", "optunop", "value", "scopedname", "scopepart", "simplevalue",
  "exprlist", "typedef", "struct", "@8", "classtmpl", "template", "class",
  "@9", "superclasses", "superlist", "superclass", "optclassbody",
  "classbody", "classline", "optslot", "dtor", "ctor", "@10", "simplector",
  "optctorsig", "optsig", "optvirtual", "function", "operatorname",
  "optconst", "optabstract", "optflags", "flaglist", "flag", "flagvalue",
  "methodcode", "virtualcatchercode", "arglist", "rawarglist", "argvalue",
  "varmember", "@11", "varmem", "member", "@12", "variable", "cpptype",
  "argtype", "optref", "deref", "basetype", "cpptypelist", "optexceptions",
  "exceptionlist", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const unsigned short int yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,    40,    41,    44,   123,   125,    59,    33,    45,    61,
      43,    42,    47,    38,   124,   126,    60,    62,    58,    91,
      93,    37,    94
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned short int yyr1[] =
{
       0,   123,   124,   124,   126,   125,   127,   127,   127,   127,
     127,   127,   127,   127,   127,   127,   127,   127,   127,   127,
     127,   127,   127,   127,   127,   127,   127,   127,   127,   127,
     128,   128,   128,   128,   128,   128,   128,   128,   128,   128,
     128,   128,   129,   130,   130,   131,   132,   133,   133,   134,
     136,   135,   138,   137,   139,   140,   140,   141,   141,   141,
     143,   142,   144,   144,   146,   145,   147,   147,   148,   149,
     151,   150,   152,   152,   153,   154,   155,   155,   155,   155,
     156,   156,   157,   158,   159,   160,   160,   161,   161,   162,
     162,   163,   164,   165,   166,   166,   167,   167,   168,   168,
     169,   170,   171,   172,   173,   173,   174,   175,   176,   177,
     178,   179,   180,   181,   182,   183,   184,   185,   186,   187,
     188,   189,   190,   190,   192,   191,   193,   193,   194,   194,
     195,   195,   196,   196,   197,   197,   197,   198,   198,   199,
     199,   200,   200,   201,   201,   202,   202,   202,   202,   202,
     202,   203,   203,   203,   203,   203,   204,   205,   205,   206,
     207,   207,   207,   207,   207,   207,   207,   207,   207,   208,
     208,   208,   209,   209,   211,   210,   212,   213,   215,   214,
     216,   216,   217,   217,   218,   219,   219,   220,   220,   221,
     221,   221,   221,   221,   221,   221,   221,   221,   221,   221,
     221,   221,   221,   221,   221,   221,   221,   221,   221,   221,
     221,   221,   221,   221,   222,   222,   223,   225,   224,   224,
     226,   227,   227,   228,   228,   229,   229,   230,   230,   230,
     231,   231,   231,   231,   231,   231,   231,   231,   231,   231,
     231,   231,   231,   231,   231,   231,   231,   231,   231,   231,
     231,   231,   231,   231,   231,   231,   231,   231,   231,   232,
     232,   233,   233,   234,   234,   235,   235,   236,   236,   237,
     237,   237,   238,   238,   239,   239,   240,   241,   241,   241,
     242,   242,   242,   242,   242,   242,   242,   242,   242,   244,
     243,   243,   245,   245,   247,   246,   246,   248,   249,   249,
     250,   251,   251,   252,   252,   253,   253,   253,   253,   253,
     253,   253,   253,   253,   253,   253,   253,   253,   253,   253,
     253,   253,   253,   253,   253,   253,   253,   253,   253,   253,
     253,   253,   254,   254,   255,   255,   256,   256,   256
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     1,     2,     0,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     4,     1,     3,     1,     9,     0,     3,     2,
       0,     4,     0,     5,     4,     1,     2,     1,     2,     2,
       0,     7,     1,     2,     0,     5,     1,     2,     1,     2,
       0,     5,     1,     2,     1,     4,     1,     2,     3,     4,
       1,     3,     1,     2,     3,     1,     1,     1,     1,     0,
       1,     2,     2,     2,     0,     2,     0,     2,     0,     2,
       2,     2,     2,     2,     0,     1,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       4,     2,     1,     2,     0,     8,     0,     1,     0,     1,
       0,     1,     1,     2,     1,     1,     4,     0,     1,     0,
       2,     0,     2,     1,     3,     1,     1,     1,     1,     1,
       1,     0,     1,     1,     1,     1,     2,     1,     3,     1,
       1,     4,     1,     1,     1,     1,     1,     1,     1,     0,
       1,     3,     4,    10,     0,     8,     2,     4,     0,     7,
       0,     2,     1,     3,     1,     0,     3,     1,     2,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     2,     2,
       3,     3,     3,     2,     0,     1,    11,     0,     3,     1,
       9,     0,     5,     0,     6,     0,     1,    13,    14,    13,
       1,     1,     1,     1,     1,     1,     1,     1,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     3,     3,
       1,     2,     2,     1,     2,     2,     2,     1,     2,     0,
       1,     0,     2,     0,     3,     1,     3,     1,     3,     1,
       1,     1,     0,     2,     0,     2,     1,     0,     1,     3,
       3,     3,     3,     2,     2,     5,     5,     2,     2,     0,
       3,     1,     1,     1,     0,     3,     1,     7,     4,     3,
       3,     0,     1,     0,     2,     1,     4,     2,     2,     1,
       1,     2,     1,     1,     2,     2,     3,     1,     1,     1,
       2,     2,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     3,     0,     4,     0,     1,     3
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const unsigned short int yydefact[] =
{
       4,     4,     2,     0,     1,     3,     0,    45,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    82,
     159,     0,     0,     0,     0,     0,     0,    85,    86,     0,
       0,   319,   309,   312,   313,   317,   318,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   128,     0,   310,     0,
       0,     0,    70,    64,     0,   263,     0,     0,     0,   331,
       5,    29,     7,     8,    36,    27,    28,    32,    14,    15,
      13,    30,    31,    16,     6,     0,    10,    11,    12,     9,
      17,    18,    41,    19,    20,    21,    22,    23,    24,    25,
      26,    38,   305,   157,    37,    33,    35,     0,    34,    39,
      40,     0,   303,     0,   122,   118,     0,   119,   126,   114,
     115,   116,   112,   117,   100,     0,    50,   128,    91,    92,
      93,   101,   102,   103,   178,   159,   307,   315,   129,   263,
     320,   308,   311,   314,   321,   303,     0,    60,     0,     0,
      69,     0,    83,     0,    47,     0,    87,    88,    89,     0,
       0,     0,   176,   263,     0,   301,    43,     0,   123,   121,
     127,     0,     0,    76,     0,    80,     0,     0,   180,   263,
     124,   316,   301,     0,   303,     0,     0,     0,   267,     0,
     265,   277,     0,   263,   332,     0,    90,    84,   158,     0,
      52,   277,     0,     0,     0,   231,     0,   230,   232,   233,
     235,   236,   250,   253,   257,     0,   234,   237,     0,   304,
     302,   299,    42,     0,   120,     0,    51,    77,     0,    75,
     128,     0,   263,     0,     0,   298,   172,     0,     0,    74,
       0,    72,    68,     0,    66,     0,     0,   264,   128,   128,
     128,   128,   128,     0,     0,   128,     0,   276,   278,   128,
     141,     0,     0,     0,   177,   306,     0,     0,    94,   251,
     256,   241,   255,   240,   242,   243,   245,   246,   254,   238,
     258,   239,   252,   244,   247,   277,    44,     0,     0,     0,
      55,    57,    78,     0,    81,   184,   181,   182,   185,   225,
     130,     0,    62,     0,     0,    71,    73,    65,    67,   269,
     270,   271,   268,   266,   141,   141,   141,   283,   284,   277,
     277,   287,   259,     0,   263,   151,   288,    48,   104,   333,
      53,   259,     0,    96,   248,   249,     0,    58,    59,     0,
      56,    79,     0,   225,     0,     0,   159,     0,     0,     0,
       0,     0,     0,     0,     0,   214,   214,   214,     0,   294,
     289,   217,   194,   191,   189,   190,   198,   199,   200,   201,
     202,   203,   204,   197,   196,   195,   192,   193,   225,   187,
     206,   205,   219,     0,   296,   207,   291,   292,   293,   139,
     134,   135,     0,   131,   132,     0,     0,    63,   280,   281,
     282,     0,     0,   260,   334,   279,   300,   152,   154,   155,
     153,   142,     0,   143,   105,     0,   334,    95,     0,    98,
     259,    54,   183,   225,   179,   113,   277,   106,   107,   108,
     109,   110,   111,   209,   208,   215,     0,     0,     0,   213,
       0,     0,     0,     0,   188,     0,   151,   263,     0,   133,
       0,    61,   128,   128,     0,   261,   145,   146,   147,   148,
     149,   150,   151,   167,   163,   162,   168,   164,   165,   166,
     160,   156,     0,     0,     0,   261,    97,     0,   297,   334,
     186,     0,   210,   211,   212,   295,     0,   294,   290,     0,
     218,   175,     0,   140,   137,   125,     0,   285,   286,   336,
       0,   263,   144,   151,    49,     0,   263,    99,   261,   334,
       0,     0,   138,   136,     0,   337,     0,   262,   223,   170,
       0,    46,   223,   263,   263,   334,   173,   335,     0,     0,
       0,   161,   151,     0,   223,   221,   261,   338,     0,   272,
     171,   272,     0,     0,     0,   263,   277,     0,   274,   274,
     272,   277,   272,     0,     0,   273,     0,   229,   227,   274,
       0,   220,   272,     0,   275,   228,     0,   274,   224,   222,
     216
};

/* YYDEFGOTO[NTERM-NUM]. */
static const short int yydefgoto[] =
{
      -1,     1,     2,     3,    60,    61,    62,   157,    63,   352,
     183,   464,    65,   162,    66,   256,   216,   279,   280,   353,
     175,   293,    68,   139,   233,   234,    69,    70,   138,   230,
     231,   354,   165,   166,   355,    73,    74,    75,   148,   187,
      76,    77,    78,   323,   409,   468,    79,    80,    81,   356,
     405,   357,   358,   359,   360,   361,   362,    83,   363,    84,
      85,    86,    87,    88,    89,    90,   105,   106,   364,   224,
     161,   129,   382,   383,   384,   503,   437,   316,   401,   452,
     402,   403,    92,    93,   461,   510,   365,   366,   169,    96,
     294,   367,   168,   222,   286,   287,   334,   368,   369,   426,
     370,   371,   432,   372,   534,   520,   373,   374,   208,   394,
     491,   142,   179,   180,   302,   538,   547,   246,   247,   248,
     375,   431,   376,   377,   430,   378,   249,   250,   211,   155,
     102,   185,   445,   506
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -478
static const short int yypact[] =
{
    -478,    68,  -478,   505,  -478,  -478,   -36,  -478,    81,    81,
      80,    81,    81,    81,    81,    81,    81,  1041,     6,  -478,
    -478,    93,   105,   138,    81,    81,    81,  -478,  -478,   170,
     178,  -478,  -478,  -478,   155,  -478,  -478,  -478,  -478,  -478,
    -478,  -478,  -478,  -478,  -478,  -478,   195,   161,    91,  1041,
     990,   198,  -478,  -478,   199,   110,   990,   170,   107,  -478,
    -478,  -478,  -478,  -478,  -478,  -478,  -478,  -478,  -478,  -478,
    -478,  -478,  -478,  -478,  -478,   131,  -478,  -478,  -478,  -478,
    -478,  -478,  -478,  -478,  -478,  -478,  -478,  -478,  -478,  -478,
    -478,  -478,   -25,  -478,  -478,  -478,  -478,    38,  -478,  -478,
    -478,    29,  -478,   202,  -478,  -478,   130,  -478,   204,  -478,
    -478,  -478,  -478,  -478,  -478,   170,  -478,     1,  -478,  -478,
    -478,  -478,  -478,  -478,   158,    13,   158,  -478,  -478,   110,
    -478,  -478,  -478,   171,  -478,  -478,    14,  -478,   125,   126,
    -478,   209,  -478,   133,   -13,   990,  -478,  -478,   151,   170,
     990,  1041,  -478,   -11,   163,   -27,  -478,    63,  -478,  -478,
    -478,    81,   132,   127,   215,   169,   140,   136,   128,   110,
    -478,  -478,   -27,   141,  -478,   144,   234,   235,   150,    -7,
    -478,   119,   170,   110,  -478,   -40,  -478,  -478,  -478,   -28,
    -478,   119,   154,   159,   153,   156,   157,   172,   174,   177,
     179,   180,  -478,   -45,     9,   143,   181,   183,   166,  -478,
    -478,  -478,  -478,   265,  -478,    65,  -478,  -478,    12,  -478,
     195,   170,   110,   189,   191,  -478,  -478,    -1,   866,  -478,
      16,  -478,  -478,    18,  -478,    28,   209,  -478,   195,   195,
     195,   195,   195,   196,   201,   195,   194,   203,  -478,   195,
     190,   -24,   205,   990,  -478,  -478,   132,   206,   299,  -478,
    -478,  -478,  -478,  -478,  -478,  -478,  -478,  -478,  -478,   213,
    -478,   214,  -478,  -478,  -478,   119,  -478,    81,    81,     8,
    -478,  -478,  -478,   302,  -478,   158,   222,  -478,   232,   751,
     186,   237,  -478,   809,   293,  -478,  -478,  -478,  -478,  -478,
    -478,  -478,  -478,  -478,   190,   190,   190,  -478,  -478,   119,
     119,  -478,   268,   119,   110,    95,  -478,  -478,   300,  -478,
    -478,   268,    81,   333,  -478,  -478,   241,  -478,  -478,   239,
    -478,  -478,   170,   751,   240,    81,   246,    81,    81,    81,
      81,    81,    81,    81,    81,   298,   298,   298,   231,   236,
    -478,  -478,  -478,  -478,  -478,  -478,  -478,  -478,  -478,  -478,
    -478,  -478,  -478,  -478,  -478,  -478,  -478,  -478,   587,  -478,
    -478,  -478,  -478,   238,  -478,  -478,  -478,  -478,  -478,   243,
    -478,  -478,   245,   186,  -478,   253,   249,  -478,  -478,  -478,
    -478,   254,   255,  -478,   264,  -478,  -478,  -478,  -478,  -478,
    -478,    19,   918,  -478,  -478,   262,   264,  -478,    81,   352,
     268,  -478,  -478,   669,  -478,  -478,   119,  -478,  -478,  -478,
    -478,  -478,  -478,  -478,  -478,  -478,   247,   248,   251,  -478,
     968,   420,   342,   261,  -478,   348,    95,   110,   266,  -478,
     990,  -478,   195,   195,   270,   267,  -478,  -478,  -478,  -478,
    -478,  -478,    95,  -478,  -478,  -478,  -478,  -478,  -478,  -478,
     -31,  -478,   273,    81,   272,   267,  -478,    81,  -478,   264,
    -478,   276,  -478,  -478,  -478,  -478,    31,  -478,  -478,   246,
    -478,  -478,   274,  -478,   277,  -478,    66,  -478,  -478,   170,
     303,   110,  -478,    32,  -478,   279,   110,  -478,   267,   264,
     278,   281,  -478,  -478,   282,   158,    83,  -478,   271,    19,
      87,  -478,   271,   110,   110,   264,  -478,  -478,   170,   990,
     283,  -478,    95,   285,   271,   286,   267,   158,   291,   355,
      19,   355,   289,   295,   292,   110,   119,    81,   375,   375,
     355,   119,   355,   296,   304,  -478,    81,  -478,  -478,   375,
     305,  -478,   355,   288,  -478,  -478,   290,   375,  -478,  -478,
    -478
};

/* YYPGOTO[NTERM-NUM].  */
static const short int yypgoto[] =
{
    -478,  -478,   400,  -478,  -478,  -196,  -478,  -478,  -478,    21,
    -478,  -478,  -478,  -478,  -478,  -478,   160,  -478,   134,    22,
    -478,  -478,  -478,  -478,  -478,   176,  -478,  -478,  -478,  -478,
     182,    10,  -478,  -478,    11,  -478,  -478,  -478,  -478,  -478,
    -478,  -478,  -478,  -478,  -478,  -478,  -478,  -478,  -478,    26,
    -478,  -478,  -478,  -478,  -478,  -478,  -478,  -478,  -478,  -478,
    -478,  -478,  -478,  -478,  -478,  -478,    -9,  -478,    23,  -478,
    -478,   -82,  -478,  -478,    34,  -478,  -478,   -93,  -439,  -478,
    -478,  -376,   -20,   275,  -478,  -478,    24,    25,  -478,  -478,
     408,    17,  -478,  -478,  -478,    82,  -478,    86,  -321,  -131,
    -478,  -478,  -478,   -17,  -478,  -431,  -478,    -2,  -478,  -299,
    -432,  -110,  -478,   184,  -478,  -473,  -477,  -173,  -478,   108,
    -478,  -478,    -8,  -478,  -478,    27,     5,  -478,   250,   -87,
      -5,  -119,  -395,  -478
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -306
static const short int yytable[] =
{
     107,    99,   109,   110,   111,   112,   113,   114,   101,   124,
     126,   465,   116,    71,    72,   121,   122,   123,   257,   170,
      98,   291,   406,   163,    64,    67,    91,    94,    95,    82,
     100,   189,   292,   496,   282,   167,   173,   144,   229,   149,
     232,   277,   278,   192,   135,   149,   149,   434,   172,    26,
     299,   153,   300,   500,   509,   136,   151,   149,   539,   223,
     483,   143,   548,   253,   268,   103,   513,   549,     4,   551,
    -305,   269,   555,   252,   498,   253,   492,   254,   317,   557,
     560,   523,    29,   530,   209,   150,   210,   227,   182,   255,
     191,   150,   434,   532,   535,   126,   236,   387,   277,   278,
     104,   141,   326,   108,   514,   237,    26,   117,   164,   301,
     209,   469,   288,   329,   152,   174,   118,  -174,   270,   283,
     526,   295,   154,   297,   154,  -174,   271,   446,   119,   447,
     448,   449,   450,   451,  -169,  -169,   391,   392,   284,   397,
     398,    20,   399,   131,   132,   133,   190,   400,   134,   158,
     184,   159,   214,   146,   147,   184,   304,   305,   306,   307,
     308,   120,   251,   311,   115,   212,   213,   314,   504,   253,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,   517,   518,    47,    48,   521,
     522,    49,    20,   238,   239,   240,   241,   242,   243,   244,
     125,   285,   397,   398,   396,   399,    18,    19,   379,   127,
     400,   388,   389,   390,   245,   427,   428,   128,   130,    59,
     137,   140,   141,   145,   156,   171,    99,   160,   149,   176,
     177,   178,   186,   101,   181,  -129,   215,   217,    71,    72,
     218,   281,   219,   471,   220,    98,   221,   226,   228,    64,
      67,    91,    94,    95,    82,   100,   229,   232,   319,   235,
     258,   259,   260,   272,   193,   261,   262,   275,   327,   328,
     194,   195,   196,   197,   198,   199,   200,   201,   202,   203,
     204,   263,   205,   264,   206,   207,   265,   276,   266,   267,
     273,    99,   274,   289,   101,   290,   312,   309,   101,   315,
     380,   381,   310,    71,    72,   281,   313,   322,   321,   318,
      98,   152,   285,   407,    64,    67,    91,    94,    95,    82,
     100,   486,   324,   325,   331,   332,   415,   484,   417,   418,
     419,   420,   421,   422,   423,   424,   333,    29,   101,   385,
     393,    26,   408,   410,   404,   411,   414,   416,   425,   429,
     438,  -226,   436,   435,   440,   441,   442,   443,   444,   463,
     487,   488,   467,   544,   479,   472,   473,   481,   550,   474,
     482,   489,   485,   101,   493,   501,   490,   495,   499,   191,
     502,   508,   460,   515,   507,   511,   512,   537,   516,   529,
     519,   531,   536,   380,   381,   540,   541,   462,   542,   466,
     546,     5,   552,   524,   525,   533,   553,   556,   558,   298,
     559,    97,   296,   330,   412,   480,   320,   439,   101,   413,
     303,   395,   225,   478,   188,   543,     0,     0,   475,     0,
       0,     0,     0,     0,     0,   476,   101,     0,     0,     0,
       0,     0,    20,     0,     0,   184,     0,     0,     0,     0,
       0,     0,     0,     0,   494,     0,     0,     0,   497,     0,
       0,     0,     0,     0,     0,   115,     0,     0,     0,   505,
       0,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,   477,     0,    47,    48,
       0,     0,    49,     0,     0,     0,     0,     0,   527,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     6,     7,
       8,     9,    10,    56,     0,     0,    11,    12,    13,    14,
      59,    15,    16,    17,   528,    18,    19,    20,   545,     0,
       0,     0,     0,     0,     0,     0,     0,   554,     0,     0,
       0,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,     0,     0,     0,     0,     0,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,     0,    46,    47,    48,     0,     0,    49,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    50,    51,
      52,    53,    54,    55,     0,     0,     0,     0,    56,     0,
       0,    57,   335,     0,    58,    59,     0,    18,    19,   336,
       0,     0,     0,   337,   338,   339,   340,   341,   342,     0,
       0,   343,   344,     0,     0,     0,     0,     0,    26,     0,
       0,    29,    30,   345,   346,   347,   348,     0,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,   349,    46,    47,    48,     0,     0,    49,
     350,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      50,    51,     0,     0,     0,     0,     0,     0,     0,     0,
      56,     0,     0,    57,   335,   351,     0,    59,     0,    18,
      19,   336,   433,     0,     0,   337,   338,   339,   340,   341,
     342,     0,     0,   343,   344,     0,     0,     0,     0,     0,
      26,     0,     0,    29,    30,   345,   346,   347,   348,     0,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,   349,    46,    47,    48,     0,
       0,    49,   350,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    50,    51,     0,     0,     0,     0,     0,     0,
       0,     0,    56,     0,     0,    57,   335,   351,     0,    59,
       0,    18,    19,   336,   470,     0,     0,   337,   338,   339,
     340,   341,   342,     0,     0,   343,   344,     0,     0,     0,
       0,     0,    26,     0,     0,    29,    30,   345,   346,   347,
     348,     0,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,   349,    46,    47,
      48,     0,     0,    49,   350,     0,     0,     0,     0,    18,
      19,    20,     0,     0,    50,    51,     0,     0,     0,     0,
       0,     0,     0,     0,    56,     0,     0,    57,     0,   351,
      26,    59,     0,    29,    30,     0,     0,     0,     0,     0,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,     0,    46,    47,    48,     0,
       0,    49,     0,     0,     0,     0,    18,    19,    20,     0,
       0,     0,    50,    51,     0,     0,     0,     0,     0,     0,
       0,     0,    56,     0,     0,    57,     0,    26,    58,    59,
      29,    30,     0,     0,   386,     0,     0,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,     0,    46,    47,    48,     0,     0,    49,     0,
      20,     0,   453,     0,     0,     0,     0,     0,     0,    50,
      51,     0,     0,     0,     0,     0,     0,     0,     0,    56,
       0,     0,    57,   115,     0,    58,    59,     0,     0,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,     0,     0,    47,    48,     0,     0,
      20,     0,     0,     0,     0,     0,     0,     0,     0,   454,
     455,     0,     0,     0,     0,     0,     0,   456,   457,   458,
     459,     0,    20,   115,     0,     0,     0,     0,    59,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,     0,   115,    47,    48,     0,     0,
      49,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,     0,     0,    47,    48,
       0,    56,    49,    20,     0,     0,     0,     0,    59,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   115,     0,     0,     0,
      59,     0,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,     0,     0,    47,
      48,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    59
};

static const short int yycheck[] =
{
       9,     3,    11,    12,    13,    14,    15,    16,     3,    29,
      30,   406,    17,     3,     3,    24,    25,    26,   191,   129,
       3,    22,   321,    22,     3,     3,     3,     3,     3,     3,
       3,   150,   228,   465,    22,   117,    22,    57,    22,    70,
      22,    33,    34,   153,    49,    70,    70,   368,   135,    41,
      22,    22,    24,    22,   493,    50,    18,    70,   531,   169,
     436,    56,   539,   103,   109,   101,   498,   540,     0,   542,
     101,   116,   549,   183,   469,   103,   452,   117,   102,   552,
     557,   512,    44,   522,   111,   116,   113,   174,   101,   117,
     101,   116,   413,   524,   526,   115,   103,   293,    33,    34,
      19,   112,   275,    23,   499,   112,    41,   101,   107,    81,
     111,   410,   222,   105,    97,   101,    23,   104,   109,   107,
     515,   105,    93,   105,    93,   112,   117,   108,    23,   110,
     111,   112,   113,   114,   102,   103,   309,   310,   220,   107,
     108,    22,   110,    52,    53,    54,   151,   115,    57,    19,
     145,    21,   161,    22,    23,   150,   238,   239,   240,   241,
     242,    23,   182,   245,    45,   102,   103,   249,   102,   103,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,    63,    64,    65,   102,   103,    68,    69,   102,
     103,    72,    22,    74,    75,    76,    77,    78,    79,    80,
      22,   221,   107,   108,   314,   110,    20,    21,    22,    54,
     115,   304,   305,   306,    95,   346,   347,    22,    57,   100,
      22,    22,   112,   116,    22,    54,   228,    23,    70,   104,
     104,    22,    81,   228,   101,   108,   104,    22,   228,   228,
      71,   215,   102,   416,   108,   228,   118,   106,   104,   228,
     228,   228,   228,   228,   228,   228,    22,    22,   253,   109,
     106,   102,   109,   120,   101,   109,   109,   101,   277,   278,
     107,   108,   109,   110,   111,   112,   113,   114,   115,   116,
     117,   109,   119,   109,   121,   122,   109,    22,   109,   109,
     109,   293,   109,   104,   289,   104,   102,   101,   293,   109,
     290,   290,   101,   293,   293,   279,   103,     8,   102,   104,
     293,   294,   332,   322,   293,   293,   293,   293,   293,   293,
     293,   440,   109,   109,    22,   103,   335,   437,   337,   338,
     339,   340,   341,   342,   343,   344,   104,    44,   333,   102,
      72,    41,     9,   102,   318,   106,   106,   101,    50,   118,
     105,   115,   109,   115,   101,   106,   102,   102,    94,    97,
     442,   443,    10,   536,    22,   118,   118,   106,   541,   118,
      22,   101,   106,   368,   101,   101,   109,   105,   102,   101,
     103,   491,   402,   102,    81,   106,   496,    32,   106,   106,
     119,   106,   101,   383,   383,   106,   101,   402,   106,   408,
      25,     1,   106,   513,   514,   119,   102,   102,   120,   233,
     120,     3,   230,   279,   332,   432,   256,   383,   413,   333,
     236,   313,   172,   431,   149,   535,    -1,    -1,   430,    -1,
      -1,    -1,    -1,    -1,    -1,   430,   431,    -1,    -1,    -1,
      -1,    -1,    22,    -1,    -1,   440,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   463,    -1,    -1,    -1,   467,    -1,
      -1,    -1,    -1,    -1,    -1,    45,    -1,    -1,    -1,   489,
      -1,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    63,    64,    65,    66,    -1,    68,    69,
      -1,    -1,    72,    -1,    -1,    -1,    -1,    -1,   518,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,     3,     4,
       5,     6,     7,    93,    -1,    -1,    11,    12,    13,    14,
     100,    16,    17,    18,   519,    20,    21,    22,   537,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   546,    -1,    -1,
      -1,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    -1,    -1,    -1,    -1,    -1,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    -1,    67,    68,    69,    -1,    -1,    72,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    83,    84,
      85,    86,    87,    88,    -1,    -1,    -1,    -1,    93,    -1,
      -1,    96,    15,    -1,    99,   100,    -1,    20,    21,    22,
      -1,    -1,    -1,    26,    27,    28,    29,    30,    31,    -1,
      -1,    34,    35,    -1,    -1,    -1,    -1,    -1,    41,    -1,
      -1,    44,    45,    46,    47,    48,    49,    -1,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
      63,    64,    65,    66,    67,    68,    69,    -1,    -1,    72,
      73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      83,    84,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      93,    -1,    -1,    96,    15,    98,    -1,   100,    -1,    20,
      21,    22,   105,    -1,    -1,    26,    27,    28,    29,    30,
      31,    -1,    -1,    34,    35,    -1,    -1,    -1,    -1,    -1,
      41,    -1,    -1,    44,    45,    46,    47,    48,    49,    -1,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,    63,    64,    65,    66,    67,    68,    69,    -1,
      -1,    72,    73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    83,    84,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    93,    -1,    -1,    96,    15,    98,    -1,   100,
      -1,    20,    21,    22,   105,    -1,    -1,    26,    27,    28,
      29,    30,    31,    -1,    -1,    34,    35,    -1,    -1,    -1,
      -1,    -1,    41,    -1,    -1,    44,    45,    46,    47,    48,
      49,    -1,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
      69,    -1,    -1,    72,    73,    -1,    -1,    -1,    -1,    20,
      21,    22,    -1,    -1,    83,    84,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    93,    -1,    -1,    96,    -1,    98,
      41,   100,    -1,    44,    45,    -1,    -1,    -1,    -1,    -1,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,    63,    64,    65,    -1,    67,    68,    69,    -1,
      -1,    72,    -1,    -1,    -1,    -1,    20,    21,    22,    -1,
      -1,    -1,    83,    84,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    93,    -1,    -1,    96,    -1,    41,    99,   100,
      44,    45,    -1,    -1,   105,    -1,    -1,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    60,    61,    62,    63,
      64,    65,    -1,    67,    68,    69,    -1,    -1,    72,    -1,
      22,    -1,    24,    -1,    -1,    -1,    -1,    -1,    -1,    83,
      84,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    93,
      -1,    -1,    96,    45,    -1,    99,   100,    -1,    -1,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,    63,    64,    65,    -1,    -1,    68,    69,    -1,    -1,
      22,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,
      82,    -1,    -1,    -1,    -1,    -1,    -1,    89,    90,    91,
      92,    -1,    22,    45,    -1,    -1,    -1,    -1,   100,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,    63,    64,    65,    -1,    45,    68,    69,    -1,    -1,
      72,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    63,    64,    65,    -1,    -1,    68,    69,
      -1,    93,    72,    22,    -1,    -1,    -1,    -1,   100,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    45,    -1,    -1,    -1,
     100,    -1,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    -1,    -1,    68,
      69,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   100
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned short int yystos[] =
{
       0,   124,   125,   126,     0,   125,     3,     4,     5,     6,
       7,    11,    12,    13,    14,    16,    17,    18,    20,    21,
      22,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    63,    64,    65,    67,    68,    69,    72,
      83,    84,    85,    86,    87,    88,    93,    96,    99,   100,
     127,   128,   129,   131,   132,   135,   137,   142,   145,   149,
     150,   154,   157,   158,   159,   160,   163,   164,   165,   169,
     170,   171,   172,   180,   182,   183,   184,   185,   186,   187,
     188,   191,   205,   206,   209,   210,   212,   213,   214,   230,
     248,   249,   253,   101,    19,   189,   190,   189,    23,   189,
     189,   189,   189,   189,   189,    45,   253,   101,    23,    23,
      23,   189,   189,   189,   205,    22,   205,    54,    22,   194,
      57,    52,    53,    54,    57,   253,   249,    22,   151,   146,
      22,   112,   234,   249,   205,   116,    22,    23,   161,    70,
     116,    18,   214,    22,    93,   252,    22,   130,    19,    21,
      23,   193,   136,    22,   107,   155,   156,   194,   215,   211,
     234,    54,   252,    22,   101,   143,   104,   104,    22,   235,
     236,   101,   101,   133,   249,   254,    81,   162,   206,   254,
     253,   101,   234,   101,   107,   108,   109,   110,   111,   112,
     113,   114,   115,   116,   117,   119,   121,   122,   231,   111,
     113,   251,   102,   103,   189,   104,   139,    22,    71,   102,
     108,   118,   216,   234,   192,   251,   106,   252,   104,    22,
     152,   153,    22,   147,   148,   109,   103,   112,    74,    75,
      76,    77,    78,    79,    80,    95,   240,   241,   242,   249,
     250,   205,   234,   103,   117,   117,   138,   240,   106,   102,
     109,   109,   109,   109,   109,   109,   109,   109,   109,   116,
     109,   117,   120,   109,   109,   101,    22,    33,    34,   140,
     141,   172,    22,   107,   194,   205,   217,   218,   234,   104,
     104,    22,   128,   144,   213,   105,   153,   105,   148,    22,
      24,    81,   237,   236,   194,   194,   194,   194,   194,   101,
     101,   194,   102,   103,   194,   109,   200,   102,   104,   249,
     139,   102,     8,   166,   109,   109,   240,   189,   189,   105,
     141,    22,   103,   104,   219,    15,    22,    26,    27,    28,
      29,    30,    31,    34,    35,    46,    47,    48,    49,    66,
      73,    98,   132,   142,   154,   157,   172,   174,   175,   176,
     177,   178,   179,   181,   191,   209,   210,   214,   220,   221,
     223,   224,   226,   229,   230,   243,   245,   246,   248,    22,
     154,   157,   195,   196,   197,   102,   105,   128,   200,   200,
     200,   240,   240,    72,   232,   242,   234,   107,   108,   110,
     115,   201,   203,   204,   172,   173,   232,   189,     9,   167,
     102,   106,   218,   220,   106,   189,   101,   189,   189,   189,
     189,   189,   189,   189,   189,    50,   222,   222,   222,   118,
     247,   244,   225,   105,   221,   115,   109,   199,   105,   197,
     101,   106,   102,   102,    94,   255,   108,   110,   111,   112,
     113,   114,   202,    24,    81,    82,    89,    90,    91,    92,
     205,   207,   253,    97,   134,   255,   189,    10,   168,   232,
     105,   240,   118,   118,   118,   230,   249,    66,   245,    22,
     226,   106,    22,   204,   234,   106,   254,   194,   194,   101,
     109,   233,   204,   101,   189,   105,   233,   189,   255,   102,
      22,   101,   103,   198,   102,   205,   256,    81,   234,   201,
     208,   106,   234,   233,   255,   102,   106,   102,   103,   119,
     228,   102,   103,   228,   234,   234,   255,   205,   249,   106,
     201,   106,   228,   119,   227,   233,   101,    32,   238,   238,
     106,   101,   106,   234,   240,   189,    25,   239,   239,   238,
     240,   238,   106,   102,   189,   239,   102,   238,   120,   120,
     239
};

#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# if defined (__STDC__) || defined (__cplusplus)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# endif
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { 								\
      yyerror ("syntax error: cannot back up");\
      YYERROR;							\
    }								\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

/* YYLLOC_DEFAULT -- Compute the default location (before the actions
   are run).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)		\
   ((Current).first_line   = (Rhs)[1].first_line,	\
    (Current).first_column = (Rhs)[1].first_column,	\
    (Current).last_line    = (Rhs)[N].last_line,	\
    (Current).last_column  = (Rhs)[N].last_column)
#endif

/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

# define YYDSYMPRINT(Args)			\
do {						\
  if (yydebug)					\
    yysymprint Args;				\
} while (0)

# define YYDSYMPRINTF(Title, Token, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr, 					\
                  Token, Value);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_stack_print (short int *bottom, short int *top)
#else
static void
yy_stack_print (bottom, top)
    short int *bottom;
    short int *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (/* Nothing. */; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_reduce_print (int yyrule)
#else
static void
yy_reduce_print (yyrule)
    int yyrule;
#endif
{
  int yyi;
  unsigned int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %u), ",
             yyrule - 1, yylno);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytname [yyrhs[yyi]]);
  YYFPRINTF (stderr, "-> %s\n", yytname [yyr1[yyrule]]);
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (Rule);		\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YYDSYMPRINT(Args)
# define YYDSYMPRINTF(Title, Token, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#if defined (YYMAXDEPTH) && YYMAXDEPTH == 0
# undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  register const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  register char *yyd = yydest;
  register const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

#endif /* !YYERROR_VERBOSE */



#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep)
#else
static void
yysymprint (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  if (yytype < YYNTOKENS)
    {
      YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
# ifdef YYPRINT
      YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
    }
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}

#endif /* ! YYDEBUG */
/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yydestruct (int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yytype, yyvaluep)
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  switch (yytype)
    {

      default:
        break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM);
# else
int yyparse ();
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM)
# else
int yyparse (YYPARSE_PARAM)
  void *YYPARSE_PARAM;
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  register int yystate;
  register int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  short int yyssa[YYINITDEPTH];
  short int *yyss = yyssa;
  register short int *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  register YYSTYPE *yyvsp;



#define YYPOPSTACK   (yyvsp--, yyssp--)

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* When reducing, the number of symbols on the RHS of the reduced
     rule.  */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;


  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short int *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyoverflowlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyoverflowlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	short int *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyoverflowlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YYDSYMPRINTF ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */
  YYDPRINTF ((stderr, "Shifting token %s, ", yytname[yytoken]));

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;


  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 4:
#line 291 "parser.y"
    {
            /*
             * We don't do these in parserEOF() because the parser
             * is reading ahead and that would be too early.
             */

            if (previousFile != NULL)
            {
                handleEOF();

                if (newContext.prevmod != NULL)
                    handleEOM();

                free(previousFile);
                previousFile = NULL;
            }
    }
    break;

  case 17:
#line 321 "parser.y"
    {
            if (notSkipping())
                appendCodeBlock(&currentSpec->exphdrcode, yyvsp[0].codeb);
        }
    break;

  case 18:
#line 325 "parser.y"
    {
            if (notSkipping() && inMainModule())
                appendCodeBlock(&currentSpec -> hdrcode,yyvsp[0].codeb);
        }
    break;

  case 19:
#line 329 "parser.y"
    {
            if (notSkipping() && inMainModule())
                appendCodeBlock(&currentSpec -> cppcode,yyvsp[0].codeb);
        }
    break;

  case 41:
#line 356 "parser.y"
    {
            if (notSkipping())
            {
                classDef *scope = currentScope();

                if (scope == NULL)
                    yyerror("%TypeHeaderCode can only be used in a namespace, class or mapped type");

                appendCodeBlock(&scope->hdrcode, yyvsp[0].codeb);
            }
        }
    break;

  case 43:
#line 372 "parser.y"
    {
            appendString(&currentSpec->options, yyvsp[0].text);
        }
    break;

  case 44:
#line 375 "parser.y"
    {
            appendString(&currentSpec->options, yyvsp[0].text);
        }
    break;

  case 45:
#line 380 "parser.y"
    {
            if (notSkipping())
            {
                yywarning("%SIPNoEmitters is deprecated, please use %SIPOptions instead");
                appendString(&currentSpec->options, "QtNoEmitters");
            }
        }
    break;

  case 46:
#line 389 "parser.y"
    {
            if (notSkipping())
            {
                exceptionDef *xd;
                char *pyname;

                if (currentSpec->genc)
                    yyerror("%Exception not allowed in a C module");

                pyname = getPythonName(&yyvsp[-5].optflags, scopedNameTail(yyvsp[-7].scpvalp));

                checkAttributes(currentSpec, NULL, pyname, FALSE);

                xd = findException(currentSpec, yyvsp[-7].scpvalp, TRUE);

                if (xd->cd != NULL)
                    yyerror("%Exception name has already been seen as a class name - it must be defined before being used");

                if (xd->iff->module != NULL)
                    yyerror("The %Exception has already been defined");

                /* Complete the definition. */

                xd->iff->module = currentModule;
                xd->pyname = pyname;
                xd->bibase = yyvsp[-6].exceptionbase.bibase;
                xd->base = yyvsp[-6].exceptionbase.base;
                xd->hdrcode = yyvsp[-3].codeb;
                xd->raisecode = yyvsp[-2].codeb;

                if (xd->bibase != NULL || xd->base != NULL)
                    xd->exceptionnr = currentModule->nrexceptions++;

                if (inMainModule() && xd->base != NULL && xd->base->iff->module != currentModule)
                    addToUsedList(&currentSpec->used, xd->base->iff);
            }
        }
    break;

  case 47:
#line 428 "parser.y"
    {
            yyval.exceptionbase.bibase = NULL;
            yyval.exceptionbase.base = NULL;
        }
    break;

  case 48:
#line 432 "parser.y"
    {
            exceptionDef *xd;

            yyval.exceptionbase.bibase = NULL;
            yyval.exceptionbase.base = NULL;

            /* See if it is a defined exception. */
            for (xd = currentSpec->exceptions; xd != NULL; xd = xd->next)
                if (sameScopedName(xd->iff->fqcname, yyvsp[-1].scpvalp))
                {
                    yyval.exceptionbase.base = xd;
                    break;
                }

            if (xd == NULL && yyvsp[-1].scpvalp->next == NULL && strncmp(yyvsp[-1].scpvalp->name, "SIP_", 4) == 0)
            {
                /* See if it is a builtin exception. */

                static char *builtins[] = {
                    "Exception",
                    "StopIteration",
                    "StandardError",
                    "ArithmeticError",
                    "LookupError",
                    "AssertionError",
                    "AttributeError",
                    "EOFError",
                    "FloatingPointError",
                    "EnvironmentError",
                    "IOError",
                    "OSError",
                    "ImportError",
                    "IndexError",
                    "KeyError",
                    "KeyboardInterrupt",
                    "MemoryError",
                    "NameError",
                    "OverflowError",
                    "RuntimeError",
                    "NotImplementedError",
                    "SyntaxError",
                    "IndentationError",
                    "TabError",
                    "ReferenceError",
                    "SystemError",
                    "SystemExit",
                    "TypeError",
                    "UnboundLocalError",
                    "UnicodeError",
                    "UnicodeEncodeError",
                    "UnicodeDecodeError",
                    "UnicodeTranslateError",
                    "ValueError",
                    "ZeroDivisionError",
                    "WindowsError",
                    "VMSError",
                    NULL
                };

                char **cp;

                for (cp = builtins; *cp != NULL; ++cp)
                    if (strcmp(yyvsp[-1].scpvalp->name + 4, *cp) == 0)
                    {
                        yyval.exceptionbase.bibase = *cp;
                        break;
                    }
            }

            if (yyval.exceptionbase.bibase == NULL && yyval.exceptionbase.base == NULL)
                yyerror("Unknown exception base type");
        }
    break;

  case 49:
#line 506 "parser.y"
    {
            yyval.codeb = yyvsp[0].codeb;
        }
    break;

  case 50:
#line 511 "parser.y"
    {
            if (notSkipping())
                currentMappedType = newMappedType(currentSpec,&yyvsp[0].memArg);
        }
    break;

  case 52:
#line 517 "parser.y"
    {
            int a;

            if (currentSpec->genc)
                yyerror("%MappedType templates not allowed in a C module");

            /* Check the template arguments are all just simple names. */
            for (a = 0; a < yyvsp[-2].signature.nrArgs; ++a)
                if (yyvsp[-2].signature.args[a].atype != defined_type || yyvsp[-2].signature.args[a].u.snd->next != NULL)
                    yyerror("%MappedType template arguments must be simple names");

            if (yyvsp[0].memArg.atype != template_type)
                yyerror("%MappedType template must map a template type");

            if (notSkipping())
            {
                mappedTypeTmplDef *mtt;

                /* Check a template hasn't already been provided. */
                for (mtt = currentSpec->mappedtypetemplates; mtt != NULL; mtt = mtt->next)
                    if (sameScopedName(mtt->mt->type.u.td->fqname, yyvsp[0].memArg.u.td->fqname) && sameTemplateSignature(&mtt->mt->type.u.td->types, &yyvsp[0].memArg.u.td->types, TRUE))
                        yyerror("%MappedType template for this type has already been defined");

                yyvsp[0].memArg.nrderefs = 0;
                yyvsp[0].memArg.argflags = 0;

                mtt = sipMalloc(sizeof (mappedTypeTmplDef));

                mtt->sig = yyvsp[-2].signature;
                mtt->mt = allocMappedType(&yyvsp[0].memArg);
                mtt->next = currentSpec->mappedtypetemplates;

                currentSpec->mappedtypetemplates = mtt;

                currentMappedType = mtt->mt;
            }
        }
    break;

  case 54:
#line 556 "parser.y"
    {
            if (notSkipping())
            {
                if (currentMappedType->convfromcode == NULL)
                    yyerror("%MappedType must have a %ConvertFromTypeCode directive");

                if (currentMappedType->convtocode == NULL)
                    yyerror("%MappedType must have a %ConvertToTypeCode directive");

                currentMappedType = NULL;
            }
        }
    break;

  case 57:
#line 574 "parser.y"
    {
            if (notSkipping())
                appendCodeBlock(&currentMappedType -> hdrcode,yyvsp[0].codeb);
        }
    break;

  case 58:
#line 578 "parser.y"
    {
            if (notSkipping())
            {
                if (currentMappedType -> convfromcode != NULL)
                    yyerror("%MappedType has more than one %ConvertFromTypeCode directive");

                currentMappedType -> convfromcode = yyvsp[0].codeb;
            }
        }
    break;

  case 59:
#line 587 "parser.y"
    {
            if (notSkipping())
            {
                if (currentMappedType -> convtocode != NULL)
                    yyerror("%MappedType has more than one %ConvertToTypeCode directive");

                currentMappedType -> convtocode = yyvsp[0].codeb;
            }
        }
    break;

  case 60:
#line 598 "parser.y"
    {
            if (currentSpec -> genc)
                yyerror("namespace definition not allowed in a C module");

            if (notSkipping())
            {
                classDef *ns;

                ns = newClass(currentSpec,namespace_iface,text2scopedName(yyvsp[0].text));

                pushScope(ns);

                sectionFlags = 0;
            }
        }
    break;

  case 61:
#line 612 "parser.y"
    {
            if (inMainModule())
            {
                classDef *ns = currentScope();

                if (!isUsedName(ns->iff->name))
                {
                    varDef *vd;

                    for (vd = currentSpec->vars; vd != NULL; vd = vd->next)
                        if (vd->ecd == ns)
                        {
                            setIsUsedName(ns->iff->name);
                            break;
                        }
                }
            }

            if (notSkipping())
                popScope();
        }
    break;

  case 64:
#line 639 "parser.y"
    {
            qualDef *qd;

            for (qd = currentModule -> qualifiers; qd != NULL; qd = qd -> next)
                if (qd -> qtype == platform_qualifier)
                    yyerror("%Platforms has already been defined for this module");
        }
    break;

  case 65:
#line 646 "parser.y"
    {
            qualDef *qd;
            int nrneeded;

            /*
             * Check that exactly one platform in the set was
             * requested.
             */

            nrneeded = 0;

            for (qd = currentModule -> qualifiers; qd != NULL; qd = qd -> next)
                if (qd -> qtype == platform_qualifier && isNeeded(qd))
                    ++nrneeded;

            if (nrneeded > 1)
                yyerror("No more than one of these %Platforms must be specified with the -t flag");
        }
    break;

  case 68:
#line 670 "parser.y"
    {
            newQualifier(currentModule,-1,-1,yyvsp[0].text,platform_qualifier);
        }
    break;

  case 69:
#line 675 "parser.y"
    {
            newQualifier(currentModule,-1,-1,yyvsp[0].text,feature_qualifier);
        }
    break;

  case 70:
#line 680 "parser.y"
    {
            currentTimelineOrder = 0;
        }
    break;

  case 71:
#line 683 "parser.y"
    {
            qualDef *qd;
            int nrneeded;

            /*
             * Check that exactly one time slot in the set was
             * requested.
             */

            nrneeded = 0;

            for (qd = currentModule -> qualifiers; qd != NULL; qd = qd -> next)
                if (qd -> qtype == time_qualifier && isNeeded(qd))
                    ++nrneeded;

            if (nrneeded > 1)
                yyerror("At most one of this %Timeline must be specified with the -t flag");

            currentModule -> nrtimelines++;
        }
    break;

  case 74:
#line 709 "parser.y"
    {
            newQualifier(currentModule,currentModule -> nrtimelines,currentTimelineOrder++,yyvsp[0].text,time_qualifier);
        }
    break;

  case 75:
#line 714 "parser.y"
    {
            if (skipStackPtr >= MAX_NESTED_IF)
                yyerror("Internal error: increase the value of MAX_NESTED_IF");

            /* Nested %Ifs are implicit logical ands. */

            if (skipStackPtr > 0)
                yyvsp[-1].boolean = (yyvsp[-1].boolean && skipStack[skipStackPtr - 1]);

            skipStack[skipStackPtr++] = yyvsp[-1].boolean;
        }
    break;

  case 76:
#line 727 "parser.y"
    {
            yyval.boolean = platOrFeature(yyvsp[0].text,FALSE);
        }
    break;

  case 77:
#line 730 "parser.y"
    {
            yyval.boolean = platOrFeature(yyvsp[0].text,TRUE);
        }
    break;

  case 78:
#line 733 "parser.y"
    {
            yyval.boolean = (platOrFeature(yyvsp[0].text,FALSE) || yyvsp[-2].boolean);
        }
    break;

  case 79:
#line 736 "parser.y"
    {
            yyval.boolean = (platOrFeature(yyvsp[0].text,TRUE) || yyvsp[-3].boolean);
        }
    break;

  case 81:
#line 742 "parser.y"
    {
            yyval.boolean = timePeriod(yyvsp[-2].text,yyvsp[0].text);
        }
    break;

  case 82:
#line 747 "parser.y"
    {
            if (skipStackPtr-- <= 0)
                yyerror("Too many %End directives");
        }
    break;

  case 83:
#line 753 "parser.y"
    {
            optFlag *of;

            if (yyvsp[0].optflags.nrFlags == 0)
                yyerror("%License details not specified");

            if ((of = findOptFlag(&yyvsp[0].optflags,"Type",string_flag)) == NULL)
                yyerror("%License type not specified");

            currentModule -> license = sipMalloc(sizeof (licenseDef));

            currentModule -> license -> type = of -> fvalue.sval;

            currentModule -> license -> licensee = 
                ((of = findOptFlag(&yyvsp[0].optflags,"Licensee",string_flag)) != NULL)
                    ? of -> fvalue.sval : NULL;

            currentModule -> license -> timestamp = 
                ((of = findOptFlag(&yyvsp[0].optflags,"Timestamp",string_flag)) != NULL)
                    ? of -> fvalue.sval : NULL;

            currentModule -> license -> sig = 
                ((of = findOptFlag(&yyvsp[0].optflags,"Signature",string_flag)) != NULL)
                    ? of -> fvalue.sval : NULL;
        }
    break;

  case 84:
#line 780 "parser.y"
    {
            /* Check the module hasn't already been defined. */

            moduleDef *mod;

            for (mod = currentSpec -> modules; mod != NULL; mod = mod -> next)
                if (mod->fullname != NULL && strcmp(mod->fullname, yyvsp[-1].text) == 0)
                    yyerror("Module is already defined");

            currentModule->fullname = yyvsp[-1].text;

            if ((currentModule->name = strrchr(yyvsp[-1].text, '.')) != NULL)
                currentModule->name++;
            else
                currentModule->name = yyvsp[-1].text;

            currentModule -> version = yyvsp[0].number;

            if (currentSpec -> genc < 0)
                currentSpec -> genc = yyvsp[-2].boolean;
            else if (currentSpec -> genc != yyvsp[-2].boolean)
                yyerror("Cannot mix C and C++ modules");
        }
    break;

  case 85:
#line 805 "parser.y"
    {
            yyval.boolean = FALSE;
        }
    break;

  case 86:
#line 808 "parser.y"
    {
            yyval.boolean = TRUE;
        }
    break;

  case 88:
#line 814 "parser.y"
    {
            /*
             * The grammar design is a bit broken and this is the
             * easiest way to allow periods in module names.
             */

            char *cp;

            for (cp = yyvsp[0].text; *cp != '\0'; ++cp)
                if (*cp != '.' && *cp != '_' && !isalnum(*cp))
                    yyerror("Invalid character in module name");

            yyval.text = yyvsp[0].text;
        }
    break;

  case 89:
#line 830 "parser.y"
    {
            yyval.number = -1;
        }
    break;

  case 91:
#line 836 "parser.y"
    {
            parseFile(NULL,yyvsp[0].text,NULL,FALSE);
        }
    break;

  case 92:
#line 841 "parser.y"
    {
            parseFile(NULL,yyvsp[0].text,NULL,TRUE);
        }
    break;

  case 93:
#line 846 "parser.y"
    {
            newImport(yyvsp[0].text);
        }
    break;

  case 94:
#line 851 "parser.y"
    {
            yyval.codeb = NULL;
        }
    break;

  case 95:
#line 854 "parser.y"
    {
            yyval.codeb = yyvsp[0].codeb;
        }
    break;

  case 96:
#line 859 "parser.y"
    {
            yyval.codeb = NULL;
        }
    break;

  case 97:
#line 862 "parser.y"
    {
            yyval.codeb = yyvsp[0].codeb;
        }
    break;

  case 98:
#line 867 "parser.y"
    {
            yyval.codeb = NULL;
        }
    break;

  case 99:
#line 870 "parser.y"
    {
            yyval.codeb = yyvsp[0].codeb;
        }
    break;

  case 100:
#line 875 "parser.y"
    {
            if (inMainModule())
                appendCodeBlock(&currentSpec -> copying,yyvsp[0].codeb);
        }
    break;

  case 101:
#line 881 "parser.y"
    {
            yyval.codeb = yyvsp[0].codeb;
        }
    break;

  case 102:
#line 886 "parser.y"
    {
            yyval.codeb = yyvsp[0].codeb;
        }
    break;

  case 103:
#line 891 "parser.y"
    {
            yyval.codeb = yyvsp[0].codeb;
        }
    break;

  case 104:
#line 896 "parser.y"
    {
            yyval.codeb = NULL;
        }
    break;

  case 106:
#line 902 "parser.y"
    {
            yyval.codeb = yyvsp[0].codeb;
        }
    break;

  case 107:
#line 907 "parser.y"
    {
            yyval.codeb = yyvsp[0].codeb;
        }
    break;

  case 108:
#line 912 "parser.y"
    {
            yyval.codeb = yyvsp[0].codeb;
        }
    break;

  case 109:
#line 917 "parser.y"
    {
            yyval.codeb = yyvsp[0].codeb;
        }
    break;

  case 110:
#line 922 "parser.y"
    {
            yyval.codeb = yyvsp[0].codeb;
        }
    break;

  case 111:
#line 927 "parser.y"
    {
            yyval.codeb = yyvsp[0].codeb;
        }
    break;

  case 112:
#line 932 "parser.y"
    {
            yyval.codeb = yyvsp[0].codeb;
        }
    break;

  case 113:
#line 937 "parser.y"
    {
            yyval.codeb = yyvsp[0].codeb;
        }
    break;

  case 114:
#line 942 "parser.y"
    {
            if (notSkipping() && inMainModule())
                appendCodeBlock(&currentSpec -> preinitcode,yyvsp[0].codeb);
        }
    break;

  case 115:
#line 948 "parser.y"
    {
            if (notSkipping() && inMainModule())
                appendCodeBlock(&currentSpec -> postinitcode,yyvsp[0].codeb);
        }
    break;

  case 116:
#line 954 "parser.y"
    {
            if (notSkipping() && inMainModule())
                appendCodeBlock(&currentSpec->unitcode, yyvsp[0].codeb);
        }
    break;

  case 117:
#line 960 "parser.y"
    {
            /*
             * This is a no-op and is retained for compatibility
             * until the last use of it (by SIP v3) can be removed
             * from PyQt.
             */
        }
    break;

  case 118:
#line 969 "parser.y"
    {
            if (inMainModule())
                appendCodeBlock(&currentSpec -> docs,yyvsp[0].codeb);
        }
    break;

  case 119:
#line 975 "parser.y"
    {
            appendCodeBlock(&currentSpec -> docs,yyvsp[0].codeb);
        }
    break;

  case 120:
#line 980 "parser.y"
    {
            if (inMainModule())
                yywarning("%Makefile is ignored, please use the -b flag instead");
        }
    break;

  case 123:
#line 990 "parser.y"
    {
            yyval.codeb = yyvsp[-1].codeb;

            append(&yyval.codeb->frag, yyvsp[0].codeb->frag);

            free(yyvsp[0].codeb->frag);
            free(yyvsp[0].codeb->filename);
            free(yyvsp[0].codeb);
        }
    break;

  case 124:
#line 1001 "parser.y"
    {
            if (notSkipping())
            {
                if (sectionFlags != 0 && (sectionFlags & ~(SECT_IS_PUBLIC | SECT_IS_PROT)) != 0)
                    yyerror("Class enums must be in the public or protected sections");

                currentEnum = newEnum(currentSpec,currentModule,yyvsp[-1].text,&yyvsp[0].optflags,sectionFlags);
            }
        }
    break;

  case 126:
#line 1012 "parser.y"
    {
            yyval.text = NULL;
        }
    break;

  case 127:
#line 1015 "parser.y"
    {
            yyval.text = yyvsp[0].text;
        }
    break;

  case 128:
#line 1020 "parser.y"
    {
            yyval.text = NULL;
        }
    break;

  case 129:
#line 1023 "parser.y"
    {
            yyval.text = yyvsp[0].text;
        }
    break;

  case 136:
#line 1038 "parser.y"
    {
            if (notSkipping())
            {
                /*
                 * Note that we don't use the assigned value.
                 * This is a hangover from when enums where
                 * generated in Python.  We can remove it when
                 * we have got around to updating all the .sip
                 * files.
                 */
                enumMemberDef *emd, **tail;

                emd = sipMalloc(sizeof (enumMemberDef));

                emd -> pyname = cacheName(currentSpec, getPythonName(&yyvsp[-1].optflags, yyvsp[-3].text));
                emd -> cname = yyvsp[-3].text;
                emd -> ed = currentEnum;
                emd -> next = NULL;

                checkAttributes(currentSpec,emd -> ed -> ecd,emd -> pyname -> text,FALSE);

                /* Append to preserve the order. */
                for (tail = &currentEnum->members; *tail != NULL; tail = &(*tail)->next)
                    ;

                *tail = emd;

                if (inMainModule())
                    setIsUsedName(emd -> pyname);
            }
        }
    break;

  case 141:
#line 1079 "parser.y"
    {
            yyval.valp = NULL;
        }
    break;

  case 142:
#line 1082 "parser.y"
    {
            yyval.valp = yyvsp[0].valp;
        }
    break;

  case 144:
#line 1088 "parser.y"
    {
            valueDef *vd;
 
            if (yyvsp[-2].valp -> vtype == string_value || yyvsp[0].valp -> vtype == string_value)
                yyerror("Invalid binary operator for string");
 
            /* Find the last value in the existing expression. */
 
            for (vd = yyvsp[-2].valp; vd -> next != NULL; vd = vd -> next)
                ;
 
            vd -> vbinop = yyvsp[-1].qchar;
            vd -> next = yyvsp[0].valp;

            yyval.valp = yyvsp[-2].valp;
        }
    break;

  case 145:
#line 1106 "parser.y"
    {
            yyval.qchar = '-';
        }
    break;

  case 146:
#line 1109 "parser.y"
    {
            yyval.qchar = '+';
        }
    break;

  case 147:
#line 1112 "parser.y"
    {
            yyval.qchar = '*';
        }
    break;

  case 148:
#line 1115 "parser.y"
    {
            yyval.qchar = '/';
        }
    break;

  case 149:
#line 1118 "parser.y"
    {
            yyval.qchar = '&';
        }
    break;

  case 150:
#line 1121 "parser.y"
    {
            yyval.qchar = '|';
        }
    break;

  case 151:
#line 1126 "parser.y"
    {
            yyval.qchar = '\0';
        }
    break;

  case 152:
#line 1129 "parser.y"
    {
            yyval.qchar = '!';
        }
    break;

  case 153:
#line 1132 "parser.y"
    {
            yyval.qchar = '~';
        }
    break;

  case 154:
#line 1135 "parser.y"
    {
            yyval.qchar = '-';
        }
    break;

  case 155:
#line 1138 "parser.y"
    {
            yyval.qchar = '+';
        }
    break;

  case 156:
#line 1143 "parser.y"
    {
            if (yyvsp[-1].qchar != '\0' && yyvsp[0].value.vtype == string_value)
                yyerror("Invalid unary operator for string");
 
            /*
             * Convert the value to a simple expression on the
             * heap.
             */
 
            yyval.valp = sipMalloc(sizeof (valueDef));
 
            *yyval.valp = yyvsp[0].value;
            yyval.valp -> vunop = yyvsp[-1].qchar;
            yyval.valp -> vbinop = '\0';
            yyval.valp -> next = NULL;
        }
    break;

  case 158:
#line 1162 "parser.y"
    {
            if (currentSpec -> genc)
                yyerror("Scoped names are not allowed in a C module");

            appendScopedName(&yyvsp[-2].scpvalp,yyvsp[0].scpvalp);
        }
    break;

  case 159:
#line 1170 "parser.y"
    {
            yyval.scpvalp = text2scopePart(yyvsp[0].text);
        }
    break;

  case 160:
#line 1175 "parser.y"
    {
            /*
             * We let the C++ compiler decide if the value is a
             * valid one - no point in building a full C++ parser
             * here.
             */

            yyval.value.vtype = scoped_value;
            yyval.value.u.vscp = yyvsp[0].scpvalp;
        }
    break;

  case 161:
#line 1185 "parser.y"
    {
            fcallDef *fcd;

            fcd = sipMalloc(sizeof (fcallDef));
            *fcd = yyvsp[-1].fcall;
            fcd -> type = yyvsp[-3].memArg;

            yyval.value.vtype = fcall_value;
            yyval.value.u.fcd = fcd;
        }
    break;

  case 162:
#line 1195 "parser.y"
    {
            yyval.value.vtype = real_value;
            yyval.value.u.vreal = yyvsp[0].real;
        }
    break;

  case 163:
#line 1199 "parser.y"
    {
            yyval.value.vtype = numeric_value;
            yyval.value.u.vnum = yyvsp[0].number;
        }
    break;

  case 164:
#line 1203 "parser.y"
    {
            yyval.value.vtype = numeric_value;
            yyval.value.u.vnum = 1;
        }
    break;

  case 165:
#line 1207 "parser.y"
    {
            yyval.value.vtype = numeric_value;
            yyval.value.u.vnum = 0;
        }
    break;

  case 166:
#line 1211 "parser.y"
    {
            yyval.value.vtype = numeric_value;
            yyval.value.u.vnum = 0;
        }
    break;

  case 167:
#line 1215 "parser.y"
    {
            yyval.value.vtype = string_value;
            yyval.value.u.vstr = yyvsp[0].text;
        }
    break;

  case 168:
#line 1219 "parser.y"
    {
            yyval.value.vtype = qchar_value;
            yyval.value.u.vqchar = yyvsp[0].qchar;
        }
    break;

  case 169:
#line 1225 "parser.y"
    {
            /* No values. */

            yyval.fcall.nrArgs = 0;
        }
    break;

  case 170:
#line 1230 "parser.y"
    {
            /* The single or first expression. */

            yyval.fcall.args[0] = yyvsp[0].valp;
            yyval.fcall.nrArgs = 1;
        }
    break;

  case 171:
#line 1236 "parser.y"
    {
            /* Check that it wasn't ...(,expression...). */

            if (yyval.fcall.nrArgs == 0)
                yyerror("First argument to function call is missing");

            /* Check there is room. */

            if (yyvsp[-2].fcall.nrArgs == MAX_NR_ARGS)
                yyerror("Too many arguments to function call");

            yyval.fcall = yyvsp[-2].fcall;

            yyval.fcall.args[yyval.fcall.nrArgs] = yyvsp[0].valp;
            yyval.fcall.nrArgs++;
        }
    break;

  case 172:
#line 1254 "parser.y"
    {
            if (notSkipping())
                newTypedef(currentSpec,currentModule,yyvsp[-1].text,&yyvsp[-2].memArg);
        }
    break;

  case 173:
#line 1258 "parser.y"
    {
            if (notSkipping())
            {
                argDef ftype;
                signatureDef *sig;

                /* Create the full signature on the heap. */
                sig = sipMalloc(sizeof (signatureDef));
                *sig = yyvsp[-2].signature;
                sig -> result = yyvsp[-8].memArg;

                /* Create the full type. */
                ftype.atype = function_type;
                ftype.argflags = 0;
                ftype.nrderefs = yyvsp[-6].number;
                ftype.defval = NULL;
                ftype.u.sa = sig;

                newTypedef(currentSpec,currentModule,yyvsp[-5].text,&ftype);
            }
        }
    break;

  case 174:
#line 1281 "parser.y"
    {
            if (notSkipping())
            {
                classDef *cd;

                cd = newClass(currentSpec,class_iface,text2scopedName(yyvsp[0].text));

                pushScope(cd);

                sectionFlags = SECT_IS_PUBLIC;
            }
        }
    break;

  case 175:
#line 1292 "parser.y"
    {
            if (notSkipping())
            {
                finishClass(currentSpec, currentModule, currentScope(), &yyvsp[-4].optflags);
                popScope();
            }
        }
    break;

  case 176:
#line 1301 "parser.y"
    {
            if (currentSpec->genc)
                yyerror("Class templates not allowed in a C module");

            if (notSkipping())
            {
                classTmplDef *tcd;

                /*
                 * Make sure there is room for the extra class
                 * name argument.
                 */
                if (yyvsp[-1].signature.nrArgs == MAX_NR_ARGS)
                    yyerror("Internal error - increase the value of MAX_NR_ARGS");

                tcd = sipMalloc(sizeof (classTmplDef));
                tcd->sig = yyvsp[-1].signature;
                tcd->cd = yyvsp[0].klass;
                tcd->next = currentSpec->classtemplates;

                currentSpec->classtemplates = tcd;
            }
        }
    break;

  case 177:
#line 1326 "parser.y"
    {
            yyval.signature = yyvsp[-1].signature;
        }
    break;

  case 178:
#line 1331 "parser.y"
    {
            if (currentSpec -> genc)
                yyerror("Class definition not allowed in a C module");

            if (notSkipping())
            {
                classDef *cd;

                cd = newClass(currentSpec, class_iface, scopeScopedName(yyvsp[0].scpvalp));

                pushScope(cd);

                sectionFlags = SECT_IS_PRIVATE;
            }
        }
    break;

  case 179:
#line 1345 "parser.y"
    {
            if (notSkipping())
            {
                classDef *cd = currentScope();

                /*
                 * See if the class was defined or just
                 * declared.
                 */
                if (yyvsp[-1].boolean)
                {
                    if (yyvsp[-5].scpvalp->next != NULL)
                        yyerror("A scoped name cannot be given in a class definition");

                }
                else if (cd->supers != NULL)
                    yyerror("Class has super-classes but no definition");
                else
                    setIsOpaque(cd);

                finishClass(currentSpec, currentModule, cd, &yyvsp[-2].optflags);
                popScope();

                /*
                 * Check that external classes have only been
                 * declared at the global scope.
                 */
                if (isExternal(cd) && currentScope() != NULL)
                    yyerror("External classes can only be declared in the global scope");

                yyval.klass = cd;
            }
        }
    break;

  case 184:
#line 1388 "parser.y"
    {
            if (notSkipping())
            {
                classDef *cd, *super;

                cd = currentScope();

                super = findClass(currentSpec,class_iface,yyvsp[0].scpvalp);

                appendToClassList(&cd -> supers,super);
                addToUsedList(&cd->iff->used, super->iff);
            }
        }
    break;

  case 185:
#line 1403 "parser.y"
    {
            yyval.boolean = FALSE;
        }
    break;

  case 186:
#line 1406 "parser.y"
    {
            yyval.boolean = TRUE;
        }
    break;

  case 197:
#line 1423 "parser.y"
    {
            if (notSkipping())
                appendCodeBlock(&currentScope() -> cppcode,yyvsp[0].codeb);
        }
    break;

  case 198:
#line 1427 "parser.y"
    {
            if (notSkipping())
                appendCodeBlock(&currentScope() -> hdrcode,yyvsp[0].codeb);
        }
    break;

  case 199:
#line 1431 "parser.y"
    {
            if (currentScope()->travcode != NULL)
                yyerror("%GCTraverseCode already given for class");

            if (notSkipping())
                currentScope()->travcode = yyvsp[0].codeb;
        }
    break;

  case 200:
#line 1438 "parser.y"
    {
            if (currentScope()->clearcode != NULL)
                yyerror("%GCClearCode already given for class");

            if (notSkipping())
                currentScope()->clearcode = yyvsp[0].codeb;
        }
    break;

  case 201:
#line 1445 "parser.y"
    {
            if (currentScope()->readbufcode != NULL)
                yyerror("%BIGetReadBufferCode already given for class");

            if (notSkipping())
                currentScope()->readbufcode = yyvsp[0].codeb;
        }
    break;

  case 202:
#line 1452 "parser.y"
    {
            if (currentScope()->writebufcode != NULL)
                yyerror("%BIGetWriteBufferCode already given for class");

            if (notSkipping())
                currentScope()->writebufcode = yyvsp[0].codeb;
        }
    break;

  case 203:
#line 1459 "parser.y"
    {
            if (currentScope()->segcountcode != NULL)
                yyerror("%BIGetSegCountCode already given for class");

            if (notSkipping())
                currentScope()->segcountcode = yyvsp[0].codeb;
        }
    break;

  case 204:
#line 1466 "parser.y"
    {
            if (currentScope()->charbufcode != NULL)
                yyerror("%BIGetCharBufferCode already given for class");

            if (notSkipping())
                currentScope()->charbufcode = yyvsp[0].codeb;
        }
    break;

  case 208:
#line 1476 "parser.y"
    {
            if (notSkipping())
            {
                classDef *cd = currentScope();

                if (cd -> convtosubcode != NULL)
                    yyerror("Class has more than one %ConvertToSubClassCode directive");

                cd -> convtosubcode = yyvsp[0].codeb;
            }
        }
    break;

  case 209:
#line 1487 "parser.y"
    {
            if (notSkipping())
            {
                classDef *cd = currentScope();

                if (cd -> convtocode != NULL)
                    yyerror("Class has more than one %ConvertToTypeCode directive");

                cd -> convtocode = yyvsp[0].codeb;
            }
        }
    break;

  case 210:
#line 1498 "parser.y"
    {
            if (currentSpec -> genc)
                yyerror("public section not allowed in a C module");

            if (notSkipping())
                sectionFlags = SECT_IS_PUBLIC | yyvsp[-1].number;
        }
    break;

  case 211:
#line 1505 "parser.y"
    {
            if (currentSpec -> genc)
                yyerror("protected section not allowed in a C module");

            if (notSkipping())
                sectionFlags = SECT_IS_PROT | yyvsp[-1].number;
        }
    break;

  case 212:
#line 1512 "parser.y"
    {
            if (currentSpec -> genc)
                yyerror("private section not allowed in a C module");

            if (notSkipping())
                sectionFlags = SECT_IS_PRIVATE | yyvsp[-1].number;
        }
    break;

  case 213:
#line 1519 "parser.y"
    {
            if (currentSpec -> genc)
                yyerror("signals section not allowed in a C module");

            if (notSkipping())
                sectionFlags = SECT_IS_SIGNAL;
        }
    break;

  case 214:
#line 1528 "parser.y"
    {
            yyval.number = 0;
        }
    break;

  case 215:
#line 1531 "parser.y"
    {
            yyval.number = SECT_IS_SLOT;
        }
    break;

  case 216:
#line 1536 "parser.y"
    {
            /* Note that we allow non-virtual dtors in C modules. */

            if (notSkipping())
            {
                classDef *cd = currentScope();

                if (strcmp(classBaseName(cd),yyvsp[-8].text) != 0)
                    yyerror("Destructor doesn't have the same name as its class");

                if (isDtor(cd))
                    yyerror("Destructor has already been defined");

                if (currentSpec -> genc && yyvsp[-1].codeb == NULL)
                    yyerror("Destructor in C modules must include %MethodCode");

                cd -> dealloccode = yyvsp[-1].codeb;
                cd -> dtorcode = yyvsp[0].codeb;
                cd -> dtorexceptions = yyvsp[-5].throwlist;
                cd -> classflags |= sectionFlags;

                if (yyvsp[-4].number)
                {
                    if (!yyvsp[-10].number)
                        yyerror("Abstract destructor must be virtual");

                    setIsAbstractClass(cd);
                }

                /*
                 * The class has a shadow if we have a virtual dtor or some
                 * dtor code.
                 */
                if (yyvsp[-10].number || yyvsp[0].codeb != NULL)
                {
                    if (currentSpec -> genc)
                        yyerror("Virtual destructor or %VirtualCatcherCode not allowed in a C module");

                    setHasShadow(cd);
                }

                if (getReleaseGIL(&yyvsp[-3].optflags))
                    setIsReleaseGILDtor(cd);
            }
        }
    break;

  case 217:
#line 1583 "parser.y"
    {currentCtorIsExplicit = TRUE;}
    break;

  case 220:
#line 1587 "parser.y"
    {
            /* Note that we allow ctors in C modules. */

            if (notSkipping())
            {
                if (currentSpec -> genc)
                {
                    if (yyvsp[0].codeb == NULL && yyvsp[-6].signature.nrArgs != 0)
                        yyerror("Constructors with arguments in C modules must include %MethodCode");

                    if (currentCtorIsExplicit)
                        yyerror("Explicit constructors not allowed in a C module");
                }

                if ((sectionFlags & (SECT_IS_PUBLIC | SECT_IS_PROT | SECT_IS_PRIVATE)) == 0)
                    yyerror("Constructor must be in the public, private or protected sections");

                newCtor(yyvsp[-8].text,sectionFlags,&yyvsp[-6].signature,&yyvsp[-3].optflags,yyvsp[0].codeb,yyvsp[-4].throwlist,yyvsp[-2].optsignature,currentCtorIsExplicit);
            }

            free(yyvsp[-8].text);

            currentCtorIsExplicit = FALSE;
        }
    break;

  case 221:
#line 1613 "parser.y"
    {
            yyval.optsignature = NULL;
        }
    break;

  case 222:
#line 1616 "parser.y"
    {
            yyval.optsignature = sipMalloc(sizeof (signatureDef));

            *yyval.optsignature = yyvsp[-2].signature;
        }
    break;

  case 223:
#line 1623 "parser.y"
    {
            yyval.optsignature = NULL;
        }
    break;

  case 224:
#line 1626 "parser.y"
    {
            yyval.optsignature = sipMalloc(sizeof (signatureDef));

            *yyval.optsignature = yyvsp[-2].signature;
            yyval.optsignature -> result = yyvsp[-4].memArg;
        }
    break;

  case 225:
#line 1634 "parser.y"
    {
            yyval.number = FALSE;
        }
    break;

  case 226:
#line 1637 "parser.y"
    {
            yyval.number = TRUE;
        }
    break;

  case 227:
#line 1642 "parser.y"
    {
            if (notSkipping())
            {
                if (sectionFlags != 0 && (sectionFlags & (SECT_IS_PUBLIC | SECT_IS_PROT | SECT_IS_PRIVATE | SECT_IS_SLOT | SECT_IS_SIGNAL)) == 0)
                    yyerror("Class function must be in the public, private, protected, slot or signal sections");

                yyvsp[-9].signature.result = yyvsp[-12].memArg;

                newFunction(currentSpec,currentModule,
                        sectionFlags,currentIsStatic,
                        currentOverIsVirt,
                        yyvsp[-11].text,&yyvsp[-9].signature,yyvsp[-7].number,yyvsp[-5].number,&yyvsp[-4].optflags,yyvsp[-1].codeb,yyvsp[0].codeb,yyvsp[-6].throwlist,yyvsp[-3].optsignature);
            }

            currentIsStatic = FALSE;
            currentOverIsVirt = FALSE;
        }
    break;

  case 228:
#line 1659 "parser.y"
    {
            if (notSkipping())
            {
                classDef *cd = currentScope();

                /* Handle the unary '+' and '-' operators. */
                if ((cd != NULL && yyvsp[-9].signature.nrArgs == 0) || (cd == NULL && yyvsp[-9].signature.nrArgs == 1))
                {
                    if (strcmp(yyvsp[-11].text, "__add__") == 0)
                        yyvsp[-11].text = "__pos__";
                    else if (strcmp(yyvsp[-11].text, "__sub__") == 0)
                        yyvsp[-11].text = "__neg__";
                }

                yyvsp[-9].signature.result = yyvsp[-13].memArg;

                newFunction(currentSpec,currentModule,
                        sectionFlags,currentIsStatic,
                        currentOverIsVirt,
                        yyvsp[-11].text,&yyvsp[-9].signature,yyvsp[-7].number,yyvsp[-5].number,&yyvsp[-4].optflags,yyvsp[-1].codeb,yyvsp[0].codeb,yyvsp[-6].throwlist,yyvsp[-3].optsignature);
            }

            currentIsStatic = FALSE;
            currentOverIsVirt = FALSE;
        }
    break;

  case 229:
#line 1684 "parser.y"
    {
            classDef *scope = currentScope();

            if (scope == NULL || yyvsp[-9].signature.nrArgs != 0)
                yyerror("Operator casts must be specified in a class and have no arguments");


            if (notSkipping())
            {
                char *sname;

                switch (yyvsp[-11].memArg.atype)
                {
                case defined_type:
                    sname = NULL;
                    break;

                case bool_type:
                case cbool_type:
                case short_type:
                case ushort_type:
                case int_type:
                case cint_type:
                case uint_type:
                    sname = "__int__";
                    break;

                case long_type:
                case ulong_type:
                case longlong_type:
                case ulonglong_type:
                    sname = "__long__";
                    break;

                case float_type:
                case cfloat_type:
                case double_type:
                case cdouble_type:
                    sname = "__float__";
                    break;

                default:
                    yyerror("Unsupported operator cast");
                }

                if (sname != NULL)
                {
                    yyvsp[-9].signature.result = yyvsp[-11].memArg;

                    newFunction(currentSpec, currentModule,
                            sectionFlags,
                            currentIsStatic,
                            currentOverIsVirt, sname,
                            &yyvsp[-9].signature, yyvsp[-7].number, yyvsp[-5].number, &yyvsp[-4].optflags, yyvsp[-1].codeb, yyvsp[0].codeb,
                            yyvsp[-6].throwlist, yyvsp[-3].optsignature);
                }
                else
                {
                    argList *al;

                    /* Check it doesn't already exist. */
                    for (al = scope->casts; al != NULL; al = al->next)
                        if (sameScopedName(yyvsp[-11].memArg.u.snd, al->arg.u.snd))
                            yyerror("This operator cast has already been specified in this class");

                    al = sipMalloc(sizeof (argList));
                    al->arg = yyvsp[-11].memArg;
                    al->next = scope->casts;

                    scope->casts = al;
                }
            }

            currentIsStatic = FALSE;
            currentOverIsVirt = FALSE;
        }
    break;

  case 230:
#line 1762 "parser.y"
    {yyval.text = "__add__";}
    break;

  case 231:
#line 1763 "parser.y"
    {yyval.text = "__sub__";}
    break;

  case 232:
#line 1764 "parser.y"
    {yyval.text = "__mul__";}
    break;

  case 233:
#line 1765 "parser.y"
    {yyval.text = "__div__";}
    break;

  case 234:
#line 1766 "parser.y"
    {yyval.text = "__mod__";}
    break;

  case 235:
#line 1767 "parser.y"
    {yyval.text = "__and__";}
    break;

  case 236:
#line 1768 "parser.y"
    {yyval.text = "__or__";}
    break;

  case 237:
#line 1769 "parser.y"
    {yyval.text = "__xor__";}
    break;

  case 238:
#line 1770 "parser.y"
    {yyval.text = "__lshift__";}
    break;

  case 239:
#line 1771 "parser.y"
    {yyval.text = "__rshift__";}
    break;

  case 240:
#line 1772 "parser.y"
    {yyval.text = "__iadd__";}
    break;

  case 241:
#line 1773 "parser.y"
    {yyval.text = "__isub__";}
    break;

  case 242:
#line 1774 "parser.y"
    {yyval.text = "__imul__";}
    break;

  case 243:
#line 1775 "parser.y"
    {yyval.text = "__idiv__";}
    break;

  case 244:
#line 1776 "parser.y"
    {yyval.text = "__imod__";}
    break;

  case 245:
#line 1777 "parser.y"
    {yyval.text = "__iand__";}
    break;

  case 246:
#line 1778 "parser.y"
    {yyval.text = "__ior__";}
    break;

  case 247:
#line 1779 "parser.y"
    {yyval.text = "__ixor__";}
    break;

  case 248:
#line 1780 "parser.y"
    {yyval.text = "__ilshift__";}
    break;

  case 249:
#line 1781 "parser.y"
    {yyval.text = "__irshift__";}
    break;

  case 250:
#line 1782 "parser.y"
    {yyval.text = "__invert__";}
    break;

  case 251:
#line 1783 "parser.y"
    {yyval.text = "__call__";}
    break;

  case 252:
#line 1784 "parser.y"
    {yyval.text = "__getitem__";}
    break;

  case 253:
#line 1785 "parser.y"
    {yyval.text = "__lt__";}
    break;

  case 254:
#line 1786 "parser.y"
    {yyval.text = "__le__";}
    break;

  case 255:
#line 1787 "parser.y"
    {yyval.text = "__eq__";}
    break;

  case 256:
#line 1788 "parser.y"
    {yyval.text = "__ne__";}
    break;

  case 257:
#line 1789 "parser.y"
    {yyval.text = "__gt__";}
    break;

  case 258:
#line 1790 "parser.y"
    {yyval.text = "__ge__";}
    break;

  case 259:
#line 1793 "parser.y"
    {
            yyval.number = FALSE;
        }
    break;

  case 260:
#line 1796 "parser.y"
    {
            yyval.number = TRUE;
        }
    break;

  case 261:
#line 1801 "parser.y"
    {
            yyval.number = 0;
        }
    break;

  case 262:
#line 1804 "parser.y"
    {
            if (yyvsp[0].number != 0)
                yyerror("Abstract virtual function '= 0' expected");

            yyval.number = TRUE;
        }
    break;

  case 263:
#line 1812 "parser.y"
    {
            yyval.optflags.nrFlags = 0;
        }
    break;

  case 264:
#line 1815 "parser.y"
    {
            yyval.optflags = yyvsp[-1].optflags;
        }
    break;

  case 265:
#line 1821 "parser.y"
    {
            yyval.optflags.flags[0] = yyvsp[0].flag;
            yyval.optflags.nrFlags = 1;
        }
    break;

  case 266:
#line 1825 "parser.y"
    {
            /* Check there is room. */

            if (yyvsp[-2].optflags.nrFlags == MAX_NR_FLAGS)
                yyerror("Too many optional flags");

            yyval.optflags = yyvsp[-2].optflags;

            yyval.optflags.flags[yyval.optflags.nrFlags++] = yyvsp[0].flag;
        }
    break;

  case 267:
#line 1837 "parser.y"
    {
            yyval.flag.ftype = bool_flag;
            yyval.flag.fname = yyvsp[0].text;
        }
    break;

  case 268:
#line 1841 "parser.y"
    {
            yyval.flag = yyvsp[0].flag;
            yyval.flag.fname = yyvsp[-2].text;
        }
    break;

  case 269:
#line 1847 "parser.y"
    {
            yyval.flag.ftype = name_flag;
            yyval.flag.fvalue.sval = yyvsp[0].text;
        }
    break;

  case 270:
#line 1851 "parser.y"
    {
            yyval.flag.ftype = string_flag;
            yyval.flag.fvalue.sval = yyvsp[0].text;
        }
    break;

  case 271:
#line 1855 "parser.y"
    {
            yyval.flag.ftype = integer_flag;
            yyval.flag.fvalue.ival = yyvsp[0].number;
        }
    break;

  case 272:
#line 1861 "parser.y"
    {
            yyval.codeb = NULL;
        }
    break;

  case 273:
#line 1864 "parser.y"
    {
            yyval.codeb = yyvsp[0].codeb;
        }
    break;

  case 274:
#line 1869 "parser.y"
    {
            yyval.codeb = NULL;
        }
    break;

  case 275:
#line 1872 "parser.y"
    {
            yyval.codeb = yyvsp[0].codeb;
        }
    break;

  case 276:
#line 1877 "parser.y"
    {
            int a, nrrxcon, nrrxdis, nrslotcon, nrslotdis, nrarray, nrarraysize;

            nrrxcon = nrrxdis = nrslotcon = nrslotdis = nrarray = nrarraysize = 0;

            for (a = 0; a < yyvsp[0].signature.nrArgs; ++a)
            {
                argDef *ad = &yyvsp[0].signature.args[a];

                switch (ad -> atype)
                {
                case rxcon_type:
                    ++nrrxcon;
                    break;

                case rxdis_type:
                    ++nrrxdis;
                    break;

                case slotcon_type:
                    ++nrslotcon;
                    break;

                case slotdis_type:
                    ++nrslotdis;
                    break;
                }

                if (isArray(ad))
                    ++nrarray;

                if (isArraySize(ad))
                    ++nrarraysize;
            }

            if (nrrxcon != nrslotcon || nrrxcon > 1)
                yyerror("SIP_RXOBJ_CON and SIP_SLOT_CON must both be given and at most once");

            if (nrrxdis != nrslotdis || nrrxdis > 1)
                yyerror("SIP_RXOBJ_DIS and SIP_SLOT_DIS must both be given and at most once");

            if (nrarray != nrarraysize || nrarray > 1)
                yyerror("/Array/ and /ArraySize/ must both be given and at most once");

            yyval.signature = yyvsp[0].signature;
        }
    break;

  case 277:
#line 1925 "parser.y"
    {
            /* No arguments. */

            yyval.signature.nrArgs = 0;
        }
    break;

  case 278:
#line 1930 "parser.y"
    {
            /* The single or first argument. */

            yyval.signature.args[0] = yyvsp[0].memArg;
            yyval.signature.nrArgs = 1;
        }
    break;

  case 279:
#line 1936 "parser.y"
    {
            /* Check that it wasn't ...(,arg...). */
            if (yyvsp[-2].signature.nrArgs == 0)
                yyerror("First argument of the list is missing");

            /* Check there is nothing after an ellipsis. */
            if (yyvsp[-2].signature.args[yyvsp[-2].signature.nrArgs - 1].atype == ellipsis_type)
                yyerror("An ellipsis must be at the end of the argument list");

            /*
             * If this argument has no default value, then the
             * previous one mustn't either.
             */
            if (yyvsp[0].memArg.defval == NULL && yyvsp[-2].signature.args[yyvsp[-2].signature.nrArgs - 1].defval != NULL)
                yyerror("Compulsory argument given after optional argument");

            /* Check there is room. */
            if (yyvsp[-2].signature.nrArgs == MAX_NR_ARGS)
                yyerror("Internal error - increase the value of MAX_NR_ARGS");

            yyval.signature = yyvsp[-2].signature;

            yyval.signature.args[yyval.signature.nrArgs] = yyvsp[0].memArg;
            yyval.signature.nrArgs++;
        }
    break;

  case 280:
#line 1963 "parser.y"
    {
            yyval.memArg.atype = signal_type;
            yyval.memArg.argflags = ARG_IS_CONST;
            yyval.memArg.nrderefs = 0;
            yyval.memArg.name = yyvsp[-1].text;
            yyval.memArg.defval = yyvsp[0].valp;

            currentSpec -> sigslots = TRUE;
        }
    break;

  case 281:
#line 1972 "parser.y"
    {
            yyval.memArg.atype = slot_type;
            yyval.memArg.argflags = ARG_IS_CONST;
            yyval.memArg.nrderefs = 0;
            yyval.memArg.name = yyvsp[-1].text;
            yyval.memArg.defval = yyvsp[0].valp;

            currentSpec -> sigslots = TRUE;
        }
    break;

  case 282:
#line 1981 "parser.y"
    {
            yyval.memArg.atype = anyslot_type;
            yyval.memArg.argflags = ARG_IS_CONST;
            yyval.memArg.nrderefs = 0;
            yyval.memArg.name = yyvsp[-1].text;
            yyval.memArg.defval = yyvsp[0].valp;

            currentSpec -> sigslots = TRUE;
        }
    break;

  case 283:
#line 1990 "parser.y"
    {
            yyval.memArg.atype = rxcon_type;
            yyval.memArg.argflags = 0;
            yyval.memArg.nrderefs = 0;
            yyval.memArg.name = yyvsp[0].text;

            currentSpec -> sigslots = TRUE;
        }
    break;

  case 284:
#line 1998 "parser.y"
    {
            yyval.memArg.atype = rxdis_type;
            yyval.memArg.argflags = 0;
            yyval.memArg.nrderefs = 0;
            yyval.memArg.name = yyvsp[0].text;

            currentSpec -> sigslots = TRUE;
        }
    break;

  case 285:
#line 2006 "parser.y"
    {
            yyval.memArg.atype = slotcon_type;
            yyval.memArg.argflags = ARG_IS_CONST;
            yyval.memArg.nrderefs = 0;
            yyval.memArg.name = yyvsp[0].text;

            yyvsp[-2].signature.result.atype = void_type;
            yyvsp[-2].signature.result.argflags = 0;
            yyvsp[-2].signature.result.nrderefs = 0;

            yyval.memArg.u.sa = sipMalloc(sizeof (signatureDef));
            *yyval.memArg.u.sa = yyvsp[-2].signature;

            currentSpec -> sigslots = TRUE;
        }
    break;

  case 286:
#line 2021 "parser.y"
    {
            yyval.memArg.atype = slotdis_type;
            yyval.memArg.argflags = ARG_IS_CONST;
            yyval.memArg.nrderefs = 0;
            yyval.memArg.name = yyvsp[0].text;

            yyvsp[-2].signature.result.atype = void_type;
            yyvsp[-2].signature.result.argflags = 0;
            yyvsp[-2].signature.result.nrderefs = 0;

            yyval.memArg.u.sa = sipMalloc(sizeof (signatureDef));
            *yyval.memArg.u.sa = yyvsp[-2].signature;

            currentSpec -> sigslots = TRUE;
        }
    break;

  case 287:
#line 2036 "parser.y"
    {
            yyval.memArg.atype = qobject_type;
            yyval.memArg.argflags = 0;
            yyval.memArg.nrderefs = 0;
            yyval.memArg.name = yyvsp[0].text;
        }
    break;

  case 288:
#line 2042 "parser.y"
    {
            yyval.memArg = yyvsp[-1].memArg;
            yyval.memArg.defval = yyvsp[0].valp;
        }
    break;

  case 289:
#line 2048 "parser.y"
    {currentIsStatic = TRUE;}
    break;

  case 294:
#line 2056 "parser.y"
    {currentOverIsVirt = TRUE;}
    break;

  case 297:
#line 2060 "parser.y"
    {
            if (notSkipping())
            {
                /* Check the section. */

                if (sectionFlags != 0)
                {
                    if ((sectionFlags & SECT_IS_PUBLIC) == 0)
                        yyerror("Class variables must be in the public section");

                    if (!currentIsStatic && yyvsp[-2].codeb != NULL)
                        yyerror("%AccessCode cannot be specified for non-static class variables");
                }

                if (currentIsStatic && currentSpec -> genc)
                    yyerror("Cannot have static members in a C structure");

                if (yyvsp[-1].codeb != NULL || yyvsp[0].codeb != NULL)
                {
                    if (yyvsp[-2].codeb != NULL)
                        yyerror("Cannot mix %AccessCode and %GetCode or %SetCode");

                    if (currentScope() == NULL)
                        yyerror("Cannot specify %GetCode or %SetCode for global variables");
                }

                newVar(currentSpec,currentModule,yyvsp[-5].text,currentIsStatic,&yyvsp[-6].memArg,&yyvsp[-4].optflags,yyvsp[-2].codeb,yyvsp[-1].codeb,yyvsp[0].codeb);
            }

            currentIsStatic = FALSE;
        }
    break;

  case 298:
#line 2093 "parser.y"
    {
            yyval.memArg = yyvsp[-2].memArg;
            yyval.memArg.nrderefs = yyvsp[-1].number;
            yyval.memArg.argflags = ARG_IS_CONST | yyvsp[0].number;
            yyval.memArg.name = NULL;
        }
    break;

  case 299:
#line 2099 "parser.y"
    {
            yyval.memArg = yyvsp[-2].memArg;
            yyval.memArg.nrderefs = yyvsp[-1].number;
            yyval.memArg.argflags = yyvsp[0].number;
            yyval.memArg.name = NULL;
        }
    break;

  case 300:
#line 2107 "parser.y"
    {
            yyval.memArg = yyvsp[-2].memArg;
            yyval.memArg.name = yyvsp[-1].text;

            if (findOptFlag(&yyvsp[0].optflags,"AllowNone",bool_flag) != NULL)
                yyval.memArg.argflags |= ARG_ALLOW_NONE;

            if (findOptFlag(&yyvsp[0].optflags,"GetWrapper",bool_flag) != NULL)
                yyval.memArg.argflags |= ARG_GET_WRAPPER;

            if (findOptFlag(&yyvsp[0].optflags,"Array",bool_flag) != NULL)
                yyval.memArg.argflags |= ARG_ARRAY;

            if (findOptFlag(&yyvsp[0].optflags,"ArraySize",bool_flag) != NULL)
                yyval.memArg.argflags |= ARG_ARRAY_SIZE;

            if (findOptFlag(&yyvsp[0].optflags,"Transfer",bool_flag) != NULL)
                yyval.memArg.argflags |= ARG_XFERRED;

            if (findOptFlag(&yyvsp[0].optflags,"TransferThis",bool_flag) != NULL)
                yyval.memArg.argflags |= ARG_THIS_XFERRED;

            if (findOptFlag(&yyvsp[0].optflags,"TransferBack",bool_flag) != NULL)
                yyval.memArg.argflags |= ARG_XFERRED_BACK;

            if (findOptFlag(&yyvsp[0].optflags,"In",bool_flag) != NULL)
                yyval.memArg.argflags |= ARG_IN;

            if (findOptFlag(&yyvsp[0].optflags,"Out",bool_flag) != NULL)
                yyval.memArg.argflags |= ARG_OUT;

            if (findOptFlag(&yyvsp[0].optflags,"Constrained",bool_flag) != NULL)
            {
                yyval.memArg.argflags |= ARG_CONSTRAINED;

                switch (yyval.memArg.atype)
                {
                case bool_type:
                    yyval.memArg.atype = cbool_type;
                    break;

                case int_type:
                    yyval.memArg.atype = cint_type;
                    break;

                case float_type:
                    yyval.memArg.atype = cfloat_type;
                    break;

                case double_type:
                    yyval.memArg.atype = cdouble_type;
                    break;
                }
            }
        }
    break;

  case 301:
#line 2164 "parser.y"
    {
            yyval.number = 0;
        }
    break;

  case 302:
#line 2167 "parser.y"
    {
            if (currentSpec -> genc)
                yyerror("References not allowed in a C module");

            yyval.number = ARG_IS_REF;
        }
    break;

  case 303:
#line 2175 "parser.y"
    {
            yyval.number = 0;
        }
    break;

  case 304:
#line 2178 "parser.y"
    {
            yyval.number = yyvsp[-1].number + 1;
        }
    break;

  case 305:
#line 2183 "parser.y"
    {
            yyval.memArg.atype = defined_type;
            yyval.memArg.u.snd = yyvsp[0].scpvalp;
        }
    break;

  case 306:
#line 2187 "parser.y"
    {
            templateDef *td;

            td = sipMalloc(sizeof(templateDef));
            td -> fqname = yyvsp[-3].scpvalp;
            td -> types = yyvsp[-1].signature;

            yyval.memArg.atype = template_type;
            yyval.memArg.u.td = td;
        }
    break;

  case 307:
#line 2197 "parser.y"
    {
            /* In a C module all structures must be defined. */
            if (currentSpec -> genc)
            {
                yyval.memArg.atype = defined_type;
                yyval.memArg.u.snd = yyvsp[0].scpvalp;
            }
            else
            {
                yyval.memArg.atype = struct_type;
                yyval.memArg.u.sname = yyvsp[0].scpvalp;
            }
        }
    break;

  case 308:
#line 2210 "parser.y"
    {
            yyval.memArg.atype = ushort_type;
        }
    break;

  case 309:
#line 2213 "parser.y"
    {
            yyval.memArg.atype = short_type;
        }
    break;

  case 310:
#line 2216 "parser.y"
    {
            yyval.memArg.atype = uint_type;
        }
    break;

  case 311:
#line 2219 "parser.y"
    {
            yyval.memArg.atype = uint_type;
        }
    break;

  case 312:
#line 2222 "parser.y"
    {
            yyval.memArg.atype = int_type;
        }
    break;

  case 313:
#line 2225 "parser.y"
    {
            yyval.memArg.atype = long_type;
        }
    break;

  case 314:
#line 2228 "parser.y"
    {
            yyval.memArg.atype = ulong_type;
        }
    break;

  case 315:
#line 2231 "parser.y"
    {
            yyval.memArg.atype = longlong_type;
        }
    break;

  case 316:
#line 2234 "parser.y"
    {
            yyval.memArg.atype = ulonglong_type;
        }
    break;

  case 317:
#line 2237 "parser.y"
    {
            yyval.memArg.atype = float_type;
        }
    break;

  case 318:
#line 2240 "parser.y"
    {
            yyval.memArg.atype = double_type;
        }
    break;

  case 319:
#line 2243 "parser.y"
    {
            yyval.memArg.atype = bool_type;
        }
    break;

  case 320:
#line 2246 "parser.y"
    {
            yyval.memArg.atype = sstring_type;
        }
    break;

  case 321:
#line 2249 "parser.y"
    {
            yyval.memArg.atype = ustring_type;
        }
    break;

  case 322:
#line 2252 "parser.y"
    {
            yyval.memArg.atype = string_type;
        }
    break;

  case 323:
#line 2255 "parser.y"
    {
            yyval.memArg.atype = void_type;
        }
    break;

  case 324:
#line 2258 "parser.y"
    {
            yyval.memArg.atype = pyobject_type;
        }
    break;

  case 325:
#line 2261 "parser.y"
    {
            yyval.memArg.atype = pytuple_type;
        }
    break;

  case 326:
#line 2264 "parser.y"
    {
            yyval.memArg.atype = pylist_type;
        }
    break;

  case 327:
#line 2267 "parser.y"
    {
            yyval.memArg.atype = pydict_type;
        }
    break;

  case 328:
#line 2270 "parser.y"
    {
            yyval.memArg.atype = pycallable_type;
        }
    break;

  case 329:
#line 2273 "parser.y"
    {
            yyval.memArg.atype = pyslice_type;
        }
    break;

  case 330:
#line 2276 "parser.y"
    {
            yyval.memArg.atype = pytype_type;
        }
    break;

  case 331:
#line 2279 "parser.y"
    {
            yyval.memArg.atype = ellipsis_type;
        }
    break;

  case 332:
#line 2284 "parser.y"
    {
            /* The single or first type. */

            yyval.signature.args[0] = yyvsp[0].memArg;
            yyval.signature.nrArgs = 1;
        }
    break;

  case 333:
#line 2290 "parser.y"
    {
            /* Check there is nothing after an ellipsis. */
            if (yyvsp[-2].signature.args[yyvsp[-2].signature.nrArgs - 1].atype == ellipsis_type)
                yyerror("An ellipsis must be at the end of the argument list");

            /* Check there is room. */
            if (yyvsp[-2].signature.nrArgs == MAX_NR_ARGS)
                yyerror("Internal error - increase the value of MAX_NR_ARGS");

            yyval.signature = yyvsp[-2].signature;

            yyval.signature.args[yyval.signature.nrArgs] = yyvsp[0].memArg;
            yyval.signature.nrArgs++;
        }
    break;

  case 334:
#line 2306 "parser.y"
    {
            yyval.throwlist = NULL;
        }
    break;

  case 335:
#line 2309 "parser.y"
    {
            if (currentSpec->genc)
                yyerror("Exceptions not allowed in a C module");

            if (notSkipping() && inMainModule())
            {
                int e;
                ifaceFileList **ifl;

                /*
                 * Make sure the exceptions' header files are
                 * included.  We unconditionally mark them to
                 * be included in the current scope's header
                 * file to save us the effort of checking if
                 * they are being used with a protected method,
                 * a virtual or a signal.
                 */
                ifl = (currentScope() != NULL) ? &currentScope()->iff->used : &currentSpec->used;

                for (e = 0; e < yyvsp[-1].throwlist->nrArgs; ++e)
                    addToUsedList(ifl, yyvsp[-1].throwlist->args[e]->iff);
            }

            yyval.throwlist = yyvsp[-1].throwlist;
        }
    break;

  case 336:
#line 2336 "parser.y"
    {
            /* Empty list so use a blank. */

            yyval.throwlist = sipMalloc(sizeof (throwArgs));
            yyval.throwlist -> nrArgs = 0;
        }
    break;

  case 337:
#line 2342 "parser.y"
    {
            /* The only or first exception. */

            yyval.throwlist = sipMalloc(sizeof (throwArgs));
            yyval.throwlist -> nrArgs = 1;
            yyval.throwlist -> args[0] = findException(currentSpec, yyvsp[0].scpvalp, FALSE);
        }
    break;

  case 338:
#line 2349 "parser.y"
    {
            /* Check that it wasn't ...(,arg...). */

            if (yyvsp[-2].throwlist -> nrArgs == 0)
                yyerror("First exception of throw specifier is missing");

            /* Check there is room. */

            if (yyvsp[-2].throwlist -> nrArgs == MAX_NR_ARGS)
                yyerror("Internal error - increase the value of MAX_NR_ARGS");

            yyval.throwlist = yyvsp[-2].throwlist;
            yyval.throwlist -> args[yyval.throwlist -> nrArgs++] = findException(currentSpec, yyvsp[0].scpvalp, FALSE);
        }
    break;


    }

/* Line 1010 of yacc.c.  */
#line 4723 "parser.c"

  yyvsp -= yylen;
  yyssp -= yylen;


  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  YYSIZE_T yysize = 0;
	  int yytype = YYTRANSLATE (yychar);
	  const char* yyprefix;
	  char *yymsg;
	  int yyx;

	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  int yyxbegin = yyn < 0 ? -yyn : 0;

	  /* Stay within bounds of both yycheck and yytname.  */
	  int yychecklim = YYLAST - yyn;
	  int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
	  int yycount = 0;

	  yyprefix = ", expecting ";
	  for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      {
		yysize += yystrlen (yyprefix) + yystrlen (yytname [yyx]);
		yycount += 1;
		if (yycount == 5)
		  {
		    yysize = 0;
		    break;
		  }
	      }
	  yysize += (sizeof ("syntax error, unexpected ")
		     + yystrlen (yytname[yytype]));
	  yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg != 0)
	    {
	      char *yyp = yystpcpy (yymsg, "syntax error, unexpected ");
	      yyp = yystpcpy (yyp, yytname[yytype]);

	      if (yycount < 5)
		{
		  yyprefix = ", expecting ";
		  for (yyx = yyxbegin; yyx < yyxend; ++yyx)
		    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
		      {
			yyp = yystpcpy (yyp, yyprefix);
			yyp = yystpcpy (yyp, yytname[yyx]);
			yyprefix = " or ";
		      }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    yyerror ("syntax error; also virtual memory exhausted");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror ("syntax error");
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* If at end of input, pop the error token,
	     then the rest of the stack, then return failure.  */
	  if (yychar == YYEOF)
	     for (;;)
	       {
		 YYPOPSTACK;
		 if (yyssp == yyss)
		   YYABORT;
		 YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
		 yydestruct (yystos[*yyssp], yyvsp);
	       }
        }
      else
	{
	  YYDSYMPRINTF ("Error: discarding", yytoken, &yylval, &yylloc);
	  yydestruct (yytoken, &yylval);
	  yychar = YYEMPTY;

	}
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

#ifdef __GNUC__
  /* Pacify GCC when the user code never invokes YYERROR and the label
     yyerrorlab therefore never appears in user code.  */
  if (0)
     goto yyerrorlab;
#endif

  yyvsp -= yylen;
  yyssp -= yylen;
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
      yydestruct (yystos[yystate], yyvsp);
      YYPOPSTACK;
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  YYDPRINTF ((stderr, "Shifting error token, "));

  *++yyvsp = yylval;


  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*----------------------------------------------.
| yyoverflowlab -- parser overflow comes here.  |
`----------------------------------------------*/
yyoverflowlab:
  yyerror ("parser stack overflow");
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}


#line 2365 "parser.y"



/*
 * Parse the specification.
 */
void parse(sipSpec *spec,FILE *fp,char *filename,stringList *tsl,
       stringList *xfl)
{
    classTmplDef *tcd;

        /* Initialise the spec. */
 
    spec -> modules = NULL;
    spec -> namecache = NULL;
    spec -> ifacefiles = NULL;
    spec -> classes = NULL;
    spec -> classtemplates = NULL;
    spec -> proxies = NULL;
    spec -> exceptions = NULL;
    spec -> mappedtypes = NULL;
    spec -> mappedtypetemplates = NULL;
    spec -> qobjclass = -1;
    spec -> enums = NULL;
    spec -> vars = NULL;
    spec -> othfuncs = NULL;
    spec -> overs = NULL;
    spec -> typedefs = NULL;
    spec -> copying = NULL;
    spec -> exphdrcode = NULL;
    spec -> hdrcode = NULL;
    spec -> cppcode = NULL;
    spec -> docs = NULL;
    spec -> preinitcode = NULL;
    spec -> postinitcode = NULL;
    spec -> unitcode = NULL;
    spec -> used = NULL;
    spec -> sigslots = FALSE;
    spec -> genc = -1;
    spec -> options = NULL;

    currentSpec = spec;
    neededQualifiers = tsl;
    excludedQualifiers = xfl;
    currentModule = NULL;
    currentMappedType = NULL;
    currentOverIsVirt = FALSE;
    currentCtorIsExplicit = FALSE;
    currentIsStatic = FALSE;
    previousFile = NULL;
    skipStackPtr = 0;
    currentScopeIdx = 0;
    sectionFlags = 0;

    newModule(fp,filename);
    spec -> module = currentModule;

    yyparse();

    handleEOF();
    handleEOM();

    /*
     * Go through each template class and remove it from the list of
     * classes.
     */
    for (tcd = spec->classtemplates; tcd != NULL; tcd = tcd->next)
    {
        classDef **cdp;

        for (cdp = &spec->classes; *cdp != NULL; cdp = &(*cdp)->next)
            if (*cdp == tcd->cd)
            {
                ifaceFileDef **ifdp;

                /* Remove the interface file as well. */
                for (ifdp = &spec->ifacefiles; *ifdp != NULL; ifdp = &(*ifdp)->next)
                    if (*ifdp == tcd->cd->iff)
                    {
                        *ifdp = (*ifdp)->next;
                        break;
                    }

                *cdp = (*cdp)->next;
                break;
            }
    }
}


/*
 * Tell the parser that a complete file has now been read.
 */
void parserEOF(char *name,parserContext *pc)
{
    previousFile = sipStrdup(name);
    newContext = *pc;
}


/*
 * Append a class definition to a class list if it doesn't already appear.
 * Append is needed specifically for the list of super-classes because the
 * order is important to Python.
 */
void appendToClassList(classList **clp,classDef *cd)
{
    classList *new;

    /* Find the end of the list. */

    while (*clp != NULL)
    {
        if ((*clp) -> cd == cd)
            return;

        clp = &(*clp) -> next;
    }

    new = sipMalloc(sizeof (classList));

    new -> cd = cd;
    new -> next = NULL;

    *clp = new;
}


/*
 * Create a new module for the current specification and make it current.
 */
static void newModule(FILE *fp,char *filename)
{
    moduleDef *newmod;

    parseFile(fp,filename,currentModule,FALSE);

    newmod = sipMalloc(sizeof (moduleDef));
    newmod -> fullname = NULL;
    newmod -> name = NULL;
    newmod -> version = -1;
    newmod -> modflags = 0;
    newmod -> modulenr = -1;
    newmod -> file = filename;
    newmod -> qualifiers = NULL;
    newmod -> root.cd = NULL;
    newmod -> root.child = NULL;
    newmod -> nrtimelines = 0;
    newmod -> nrclasses = 0;
    newmod -> nrexceptions = 0;
    newmod -> nrmappedtypes = 0;
    newmod -> nrenums = 0;
    newmod -> nrtypedefs = 0;
    newmod -> nrvirthandlers = 0;
    newmod -> virthandlers = NULL;
    newmod -> license = NULL;
    newmod -> allimports = NULL;
    newmod -> imports = NULL;
    newmod -> next = currentSpec -> modules;

    currentModule = currentSpec->modules = newmod;
}


/*
 * Switch to parsing a new file.
 */
static void parseFile(FILE *fp,char *name,moduleDef *prevmod,int optional)
{
    parserContext pc;

    pc.ifdepth = skipStackPtr;
    pc.prevmod = prevmod;

    setInputFile(fp,name,&pc,optional);
}


/*
 * Find an interface file, or create a new one.
 */
ifaceFileDef *findIfaceFile(sipSpec *pt, moduleDef *mod, scopedNameDef *fqname,
                ifaceFileType iftype, argDef *ad)
{
    ifaceFileDef *iff;

    /* See if the name is already used. */

    for (iff = pt -> ifacefiles; iff != NULL; iff = iff -> next)
    {
        if (!sameScopedName(iff -> fqcname,fqname))
            continue;

        /*
         * They must be the same type except that we allow a class if
         * if we want an exception.  This is because we allow classes
         * to be used before they are defined.
         */
        if (iff -> type != iftype)
            if (iftype != exception_iface || iff -> type != class_iface)
                yyerror("A class, exception, namespace or mapped type has already been defined with the same name");

        /* Ignore an external class declared in another module. */
        if (iftype == class_iface && iff->module != mod)
        {
            classDef *cd;

            for (cd = pt->classes; cd != NULL; cd = cd->next)
                if (cd->iff == iff)
                    break;

            if (cd != NULL && iff->module != NULL && isExternal(cd))
                continue;
        }

        /*
         * If this is a mapped type with the same name defined in a
         * different module, then check that this type isn't the same
         * as any of the mapped types defined in that module.
         */
        if (iftype == mappedtype_iface && iff -> module != mod)
        {
            mappedTypeDef *mtd;

            for (mtd = pt -> mappedtypes; mtd != NULL; mtd = mtd -> next)
            {
                if (mtd -> iff != iff)
                    continue;

                if (ad -> atype != template_type ||
                    mtd -> type.atype != template_type ||
                    sameBaseType(ad,&mtd -> type))
                    yyerror("Mapped type has already been defined in another module");
            }

            /*
             * If we got here then we have a mapped type based on
             * an existing template, but with unique parameters.
             * We don't want to use interface files from other
             * modules, so skip this one.
             */

            continue;
        }

        /* Ignore a namespace defined in another module. */
        if (iftype == namespace_iface && iff->module != mod)
            continue;

        return iff;
    }

    iff = sipMalloc(sizeof (ifaceFileDef));

    iff -> name = cacheName(pt,scopedNameTail(fqname));
    iff -> type = iftype;
    iff -> fqcname = fqname;
    iff -> module = NULL;
    iff -> used = NULL;
    iff -> next = pt -> ifacefiles;

    pt -> ifacefiles = iff;

    return iff;
}


/*
 * Find a class definition in a parse tree.
 */
static classDef *findClass(sipSpec *pt,ifaceFileType iftype,
               scopedNameDef *fqname)
{
    return findClassWithInterface(pt, findIfaceFile(pt, currentModule, fqname, iftype, NULL));
}


/*
 * Find a class definition given an existing interface file.
 */
static classDef *findClassWithInterface(sipSpec *pt, ifaceFileDef *iff)
{
    classDef *cd;

    for (cd = pt -> classes; cd != NULL; cd = cd -> next)
        if (cd -> iff == iff)
            return cd;

    /* Create a new one. */
    cd = sipMalloc(sizeof (classDef));

    cd -> iff = iff;
    cd -> pyname = classBaseName(cd);
    cd -> classnr = -1;
    cd -> classflags = 0;
    cd -> ecd = NULL;
    cd -> dtorexceptions = NULL;
    cd -> real = NULL;
    cd -> node = NULL;
    cd -> supers = NULL;
    cd -> mro = NULL;
    cd -> td = NULL;
    cd -> ctors = NULL;
    cd -> defctor = NULL;
    cd -> dealloccode = NULL;
    cd -> dtorcode = NULL;
    cd -> members = NULL;
    cd -> overs = NULL;
    cd -> casts = NULL;
    cd -> vmembers = NULL;
    cd -> visible = NULL;
    cd -> cppcode = NULL;
    cd -> hdrcode = NULL;
    cd -> convtosubcode = NULL;
    cd -> subbase = NULL;
    cd -> convtocode = NULL;
    cd -> travcode = NULL;
    cd -> clearcode = NULL;
    cd -> readbufcode = NULL;
    cd -> writebufcode = NULL;
    cd -> segcountcode = NULL;
    cd -> charbufcode = NULL;
    cd -> next = pt -> classes;

    pt -> classes = cd;

    return cd;
}


/*
 * Add an interface file to an interface file list if it isn't already there.
 */
ifaceFileList *addToUsedList(ifaceFileList **ifflp, ifaceFileDef *iff)
{
    ifaceFileList *iffl;

    while ((iffl = *ifflp) != NULL)
    {
        /* Don't bother if it is already there. */
        if (iffl -> iff == iff)
            return iffl;

        ifflp = &iffl -> next;
    }

    iffl = sipMalloc(sizeof (ifaceFileList));

    iffl->iff = iff;
    iffl->header = FALSE;
    iffl->next = NULL;

    *ifflp = iffl;

    return iffl;
}


/*
 * Find an undefined (or create a new) exception definition in a parse tree.
 */
static exceptionDef *findException(sipSpec *pt, scopedNameDef *fqname, int new)
{
    exceptionDef *xd, **tail;
    ifaceFileDef *iff;
    classDef *cd;

    iff = findIfaceFile(pt, currentModule, fqname, exception_iface, NULL);

    /* See if it is an existing one. */
    for (xd = pt->exceptions; xd != NULL; xd = xd->next)
        if (xd->iff == iff)
            return xd;

    /*
     * If it is an exception interface file then we have never seen this
     * name before.  We require that exceptions are defined before being
     * used, but don't make the same requirement of classes (for reasons of
     * backwards compatibility).  Therefore the name must be reinterpreted
     * as a (as yet undefined) class.
     */
    if (new)
        if (iff->type == exception_iface)
            cd = NULL;
        else
            yyerror("There is already a class with the same name or the exception has been used before being defined");
    else
    {
        if (iff->type == exception_iface)
            iff->type = class_iface;

        cd = findClassWithInterface(pt, iff);
    }

    /* Create a new one. */
    xd = sipMalloc(sizeof (exceptionDef));

    xd->exceptionnr = -1;
    xd->iff = iff;
    xd->pyname = NULL;
    xd->cd = cd;
    xd->bibase = NULL;
    xd->base = NULL;
    xd->hdrcode = NULL;
    xd->raisecode = NULL;
    xd->next = NULL;

    /* Append it to the list. */
    for (tail = &pt->exceptions; *tail != NULL; tail = &(*tail)->next)
        ;

    *tail = xd;

    return xd;
}


/*
 * Find an undefined (or create a new) class definition in a parse tree.
 */
static classDef *newClass(sipSpec *pt,ifaceFileType iftype,
              scopedNameDef *fqname)
{
    int flags;
    classDef *cd, *scope;
    codeBlock *hdrcode;

    if (sectionFlags & SECT_IS_PRIVATE)
        yyerror("Classes, structs and namespaces must be in the public or or protected sections");

    flags = 0;

    if ((scope = currentScope()) != NULL)
    {
        if (sectionFlags & SECT_IS_PROT)
            flags = CLASS_IS_PROTECTED;

        hdrcode = scope -> hdrcode;
    }
    else
        hdrcode = NULL;

    if (pt -> genc)
    {
        /* C structs are always global types. */
        while (fqname -> next != NULL)
            fqname = fqname -> next;

        scope = NULL;
    }

    cd = findClass(pt,iftype,fqname);

    /* Check it hasn't already been defined. */
    if (iftype != namespace_iface && cd->iff->module != NULL)
        yyerror("The struct/class has already been defined");

    /* Complete the initialisation. */
    cd->classflags |= flags;
    cd->ecd = scope;
    cd->iff->module = currentModule;

    appendCodeBlock(&cd->hdrcode, hdrcode);

    /* See if it is a namespace extender. */
    if (iftype == namespace_iface)
    {
        classDef *ns;

        for (ns = pt->classes; ns != NULL; ns = ns->next)
        {
            if (ns == cd)
                continue;

            if (ns->iff->type != namespace_iface)
                continue;

            if (!sameScopedName(ns->iff->fqcname, fqname))
                continue;

            cd->real = ns;
            break;
        }
    }

    return cd;
}


/*
 * Tidy up after finishing a class definition.
 */
static void finishClass(sipSpec *pt, moduleDef *mod, classDef *cd, optFlags *of)
{
    char *pyname;

    /* Get the Python name and see if it is different to the C++ name. */
    pyname = getPythonName(of, classBaseName(cd));

    cd -> pyname = NULL;
    checkAttributes(pt, cd->ecd, pyname, FALSE);
    cd->pyname = pyname;

    if (cd->pyname != classBaseName(cd))
        setIsRenamedClass(cd);

    if (isOpaque(cd))
    {
        if (findOptFlag(of, "External", bool_flag) != NULL)
            setIsExternal(cd);
    }
    else
    {
        int seq_might, seq_not;
        memberDef *md;

        if (findOptFlag(of, "NoDefaultCtors", bool_flag) != NULL)
            setNoDefaultCtors(cd);

        if (cd -> ctors == NULL)
        {
            if (!noDefaultCtors(cd))
            {
                /* Provide a default ctor. */

                cd->ctors = sipMalloc(sizeof (ctorDef));
 
                cd->ctors->ctorflags = SECT_IS_PUBLIC;
                cd->ctors->pysig.nrArgs = 0;
                cd->ctors->cppsig = &cd -> ctors -> pysig;
                cd->ctors->exceptions = NULL;
                cd->ctors->methodcode = NULL;
                cd->ctors->prehook = NULL;
                cd->ctors->posthook = NULL;
                cd->ctors->next = NULL;

                cd->defctor = cd->ctors;

                setCanCreate(cd);
            }
        }
        else if (cd -> defctor == NULL)
        {
            ctorDef *ct, *last = NULL;

            for (ct = cd -> ctors; ct != NULL; ct = ct -> next)
            {
                if (!isPublicCtor(ct))
                    continue;

                if (ct -> pysig.nrArgs == 0 || ct -> pysig.args[0].defval != NULL)
                {
                    cd -> defctor = ct;
                    break;
                }

                if (last == NULL)
                    last = ct;
            }

            /* The last resort is the first public ctor. */
            if (cd->defctor == NULL)
                cd->defctor = last;
        }

        if (findOptFlag(of,"Abstract",bool_flag) != NULL)
        {
            setIsAbstractClass(cd);
            setIsIncomplete(cd);
            resetCanCreate(cd);
        }

        /* We assume a public dtor if nothing specific was provided. */
        if (!isDtor(cd))
            setIsPublicDtor(cd);

        if (findOptFlag(of, "DelayDtor", bool_flag) != NULL)
        {
            setIsDelayedDtor(cd);
            setHasDelayedDtors(mod);
        }

        /*
         * There are subtle differences between the add and concat methods and
         * the multiply and repeat methods.  The number versions can have their
         * operands swapped and may return NotImplemented.  If the user has
         * used the /Numeric/ annotation or there are other numeric operators
         * then we use add/multiply.  Otherwise, if there are indexing
         * operators then we use concat/repeat.
         */
        seq_might = seq_not = FALSE;

        for (md = cd -> members; md != NULL; md = md -> next)
            switch (md -> slot)
            {
            case getitem_slot:
            case setitem_slot:
            case delitem_slot:
                /* This might be a sequence. */
                seq_might = TRUE;
                break;

            case sub_slot:
            case isub_slot:
            case div_slot:
            case idiv_slot:
            case mod_slot:
            case imod_slot:
            case pos_slot:
            case neg_slot:
                /* This is definately not a sequence. */
                seq_not = TRUE;
                break;
            }

        if (!seq_not && seq_might)
            for (md = cd -> members; md != NULL; md = md -> next)
            {
                /* Ignore if the user has been explicit. */
                if (isNumeric(md))
                    continue;

                switch (md -> slot)
                {
                case add_slot:
                    md -> slot = concat_slot;
                    break;

                case iadd_slot:
                    md -> slot = iconcat_slot;
                    break;

                case mul_slot:
                    md -> slot = repeat_slot;
                    break;

                case imul_slot:
                    md -> slot = irepeat_slot;
                    break;
                }
            }
    }

    if (inMainModule())
    {
        setIsUsedName(cd->iff->name);
        setIsClassName(cd->iff->name);
    }
}


/*
 * Create a new mapped type.
 */
static mappedTypeDef *newMappedType(sipSpec *pt,argDef *ad)
{
    mappedTypeDef *mtd;
    scopedNameDef *snd;
    ifaceFileDef *iff;

    /* Check that the type is one we want to map. */
    switch (ad -> atype)
    {
    case defined_type:
        snd = ad -> u.snd;
        break;

    case template_type:
        snd = ad -> u.td -> fqname;
        break;

    case struct_type:
        snd = ad -> u.sname;
        break;

    default:
        yyerror("Invalid type for %MappedType");
    }

    iff = findIfaceFile(pt, currentModule, snd, mappedtype_iface, ad);

    if (inMainModule())
        setIsUsedName(iff -> name);

    /* Check it hasn't already been defined. */
    for (mtd = pt -> mappedtypes; mtd != NULL; mtd = mtd -> next)
        if (mtd -> iff == iff)
        {
            /*
             * We allow types based on the same template but with
             * different arguments.
             */

            if (ad -> atype != template_type ||
                sameBaseType(ad,&mtd -> type))
                yyerror("Mapped type has already been defined in this module");
        }

    /* The module may not have been set yet. */
    iff -> module = currentModule;

    /* Create a new mapped type. */
    mtd = allocMappedType(ad);

    mtd -> iff = iff;
    mtd -> next = pt -> mappedtypes;

    pt -> mappedtypes = mtd;

    return mtd;
}


/*
 * Allocate, intialise and return a mapped type structure.
 */
mappedTypeDef *allocMappedType(argDef *type)
{
    mappedTypeDef *mtd;

    mtd = sipMalloc(sizeof (mappedTypeDef));

    mtd->type = *type;
    mtd->type.argflags = 0;
    mtd->type.nrderefs = 0;

    mtd->mappednr = -1;
    mtd->iff = NULL;
    mtd->hdrcode = NULL;
    mtd->convfromcode = NULL;
    mtd->convtocode = NULL;
    mtd->next = NULL;

    return mtd;
}


/*
 * Create a new enum.
 */
static enumDef *newEnum(sipSpec *pt,moduleDef *mod,char *name,optFlags *of,
            int flags)
{
    enumDef *ed;
    classDef *escope = currentScope();

    ed = sipMalloc(sizeof (enumDef));

    if (name != NULL)
    {
        ed -> fqcname = text2scopedName(name);
        ed -> pyname = cacheName(pt, getPythonName(of, name));

        checkAttributes(pt, escope, ed->pyname->text, FALSE);
    }
    else
    {
        ed -> fqcname = NULL;
        ed -> pyname = NULL;
    }

    ed -> enumflags = flags;
    ed -> enumnr = -1;
    ed -> ecd = escope;
    ed -> pcd = (flags & SECT_IS_PROT) ? escope : NULL;
    ed -> module = mod;
    ed -> members = NULL;
    ed -> slots = NULL;
    ed -> overs = NULL;
    ed -> next = pt -> enums;

    if (name != NULL && strcmp(ed->pyname->text, name) != 0)
        setIsRenamedEnum(ed);

    pt -> enums = ed;

    if (escope != NULL)
        setHasEnums(escope);

    return ed;
}


/*
 * Get the type values and (optionally) the type names for substitution in
 * handwritten code.
 */
void appendTypeStrings(scopedNameDef *ename, signatureDef *patt, signatureDef *src, signatureDef *known, scopedNameDef **names, scopedNameDef **values)
{
    int a;

    for (a = 0; a < patt->nrArgs; ++a)
    {
        argDef *pad = &patt->args[a];

        if (pad->atype == defined_type)
        {
            char *nam = NULL;

            /*
             * If the type names are already known then check that
             * this is one of them.
             */
            if (known == NULL)
                nam = scopedNameTail(pad->u.snd);
            else if (pad->u.snd->next == NULL)
            {
                int k;

                for (k = 0; k < known->nrArgs; ++k)
                    if (strcmp(pad->u.snd->name, known->args[k].u.snd->name) == 0)
                    {
                        nam = pad->u.snd->name;
                        break;
                    }
            }

            if (nam == NULL)
                continue;

            /* Add the name. */
            appendScopedName(names, text2scopePart(nam));

            /* Add the corresponding value. */
            appendScopedName(values, text2scopePart(getType(ename, &src->args[a])));
        }
        else if (pad->atype == template_type)
        {
            argDef *sad = &src->args[a];

            /* These checks shouldn't be necessary, but... */
            if (sad->atype == template_type && pad->u.td->types.nrArgs == sad->u.td->types.nrArgs)
                appendTypeStrings(ename, &pad->u.td->types, &sad->u.td->types, known, names, values);
        }
    }
}


/*
 * Convert a type to a string.  We impose some limitations because I'm too lazy
 * to handle everything that might be needed one day.
 */
static char *getType(scopedNameDef *ename, argDef *ad)
{
    if (ad->atype == defined_type)
        return scopedNameToString(ad->u.snd);

    fatalScopedName(ename);
    fatal(": unsupported type argument to template class instantiation\n");

    return NULL;
}


/*
 * Convert a scoped name to a string on the heap.
 */
static char *scopedNameToString(scopedNameDef *name)
{
    static const char scope_string[] = "::";
    size_t len;
    scopedNameDef *snd;
    char *s, *dp;

    /* Work out the length of buffer needed. */
    len = 0;

    for (snd = name; snd != NULL; snd = snd->next)
    {
        len += strlen(snd->name);

        if (snd->next != NULL)
            len += strlen(scope_string);
    }

    /* Allocate and populate the buffer. */
    dp = s = sipMalloc(len + 1);

    for (snd = name; snd != NULL; snd = snd->next)
    {
        strcpy(dp, snd->name);
        dp += strlen(snd->name);

        if (snd->next != NULL)
        {
            strcpy(dp, scope_string);
            dp += strlen(scope_string);
        }
    }

    return s;
}


/*
 * Instantiate a class template.
 */
static void instantiateClassTemplate(sipSpec *pt, moduleDef *mod, classDef *scope, scopedNameDef *fqname, classTmplDef *tcd, templateDef *td)
{
    scopedNameDef *type_names, *type_values;
    classDef *cd;
    ctorDef *oct, **cttail;
    memberDef *omd, **mdtail;
    overDef *ood, **odtail;
    argDef *ad;
    ifaceFileList *iffl, **used;

    type_names = type_values = NULL;
    appendTypeStrings(classFQCName(tcd->cd), &tcd->sig, &td->types, NULL, &type_names, &type_values);

    /*
     * Add a mapping from the template name to the instantiated name.  If
     * we have got this far we know there is room for it.
     */
    ad = &tcd->sig.args[tcd->sig.nrArgs++];
    ad->atype = defined_type;
    ad->name = NULL;
    ad->argflags = 0;
    ad->nrderefs = 0;
    ad->defval = NULL;
    ad->u.snd = classFQCName(tcd->cd);

    appendScopedName(&type_names, text2scopePart(scopedNameTail(classFQCName(tcd->cd))));
    appendScopedName(&type_values, text2scopePart(scopedNameToString(fqname)));

    /* Create the new class. */
    cd = sipMalloc(sizeof (classDef));

    /* Start with a shallow copy. */
    *cd = *tcd->cd;

    cd->pyname = scopedNameTail(fqname);
    cd->td = td;

    /* Handle the interface file. */
    cd->iff = findIfaceFile(pt, mod, fqname, class_iface, NULL);
    cd->iff->module = mod;

    /* Make a copy of the used list and add the enclosing scope. */
    used = &cd->iff->used;

    for (iffl = tcd->cd->iff->used; iffl != NULL; iffl = iffl->next)
        addToUsedList(used, iffl->iff);

    if (scope != NULL)
        addToUsedList(&cd->iff->used, scope->iff);

    if (inMainModule())
    {
        setIsUsedName(cd->iff->name);
        setIsClassName(cd->iff->name);
    }

    cd->ecd = currentScope();

    /* Handle the ctors. */
    cd->ctors = NULL;
    cttail = &cd->ctors;

    for (oct = tcd->cd->ctors; oct != NULL; oct = oct->next)
    {
        ctorDef *nct = sipMalloc(sizeof (ctorDef));

        /* Start with a shallow copy. */
        *nct = *oct;

        templateSignature(&nct->pysig, FALSE, tcd, td, cd);

        if (oct->cppsig == NULL)
            nct->cppsig = NULL;
        else if (oct->cppsig == &oct->pysig)
            nct->cppsig = &nct->pysig;
        else
        {
            nct->cppsig = sipMalloc(sizeof (signatureDef));

            *nct->cppsig = *oct->cppsig;

            templateSignature(nct->cppsig, FALSE, tcd, td, cd);
        }

        nct->methodcode = templateCode(pt, used, nct->methodcode, type_names, type_values);

        nct->next = NULL;
        *cttail = nct;
        cttail = &nct->next;

        /* Handle the default ctor. */
        if (tcd->cd->defctor == oct)
            cd->defctor = nct;
    }

    cd->dealloccode = templateCode(pt, used, cd->dealloccode, type_names, type_values);
    cd->dtorcode = templateCode(pt, used, cd->dtorcode, type_names, type_values);

    /* Handle the members, ie. the common parts of overloads. */
    cd->members = NULL;
    mdtail = &cd->members;

    for (omd = tcd->cd->members; omd != NULL; omd = omd->next)
    {
        memberDef *nmd = sipMalloc(sizeof (memberDef));

        /* Start with a shallow copy. */
        *nmd = *omd;

        nmd->module = mod;

        nmd->next = NULL;
        *mdtail = nmd;
        mdtail = &nmd->next;
    }

    /* Handle the overloads. */
    cd->overs = NULL;
    odtail = &cd->overs;

    for (ood = tcd->cd->overs; ood != NULL; ood = ood->next)
    {
        overDef *nod = sipMalloc(sizeof (overDef));
        memberDef *nmd;

        /* Start with a shallow copy. */
        *nod = *ood;

        for (nmd = cd->members, omd = tcd->cd->members; omd != NULL; omd = omd->next, nmd = nmd->next)
            if (omd == ood->common)
            {
                nod->common = nmd;
                break;
            }

        templateSignature(&nod->pysig, TRUE, tcd, td, cd);

        if (ood->cppsig == &ood->pysig)
            nod->cppsig = &nod->pysig;
        else
        {
            nod->cppsig = sipMalloc(sizeof (signatureDef));

            *nod->cppsig = *ood->cppsig;

            templateSignature(nod->cppsig, TRUE, tcd, td, cd);
        }

        nod->methodcode = templateCode(pt, used, nod->methodcode, type_names, type_values);

        /* Handle any virtual handler. */
        if (ood->virthandler != NULL)
        {
            nod->virthandler = sipMalloc(sizeof (virtHandlerDef));

            /* Start with a shallow copy. */
            *nod->virthandler = *ood->virthandler;

            if (ood->virthandler->cppsig == &ood->pysig)
                nod->virthandler->cppsig = &nod->pysig;
            else
            {
                nod->virthandler->cppsig = sipMalloc(sizeof (signatureDef));

                *nod->virthandler->cppsig = *ood->virthandler->cppsig;

                templateSignature(nod->virthandler->cppsig, TRUE, tcd, td, cd);
            }

            nod->virthandler->module = mod;
            nod->virthandler->virtcode = templateCode(pt, used, nod->virthandler->virtcode, type_names, type_values);
            nod->virthandler->next = mod->virthandlers;

            mod->virthandlers = nod->virthandler;
        }

        nod->next = NULL;
        *odtail = nod;
        odtail = &nod->next;
    }

    cd->cppcode = templateCode(pt, used, cd->cppcode, type_names, type_values);
    cd->hdrcode = templateCode(pt, used, cd->hdrcode, type_names, type_values);
    cd->convtosubcode = templateCode(pt, used, cd->convtosubcode, type_names, type_values);
    cd->convtocode = templateCode(pt, used, cd->convtocode, type_names, type_values);
    cd->travcode = templateCode(pt, used, cd->travcode, type_names, type_values);
    cd->clearcode = templateCode(pt, used, cd->clearcode, type_names, type_values);
    cd->readbufcode = templateCode(pt, used, cd->readbufcode, type_names, type_values);
    cd->writebufcode = templateCode(pt, used, cd->writebufcode, type_names, type_values);
    cd->segcountcode = templateCode(pt, used, cd->segcountcode, type_names, type_values);
    cd->charbufcode = templateCode(pt, used, cd->charbufcode, type_names, type_values);
    cd->next = pt->classes;

    pt->classes = cd;

    tcd->sig.nrArgs--;

    freeScopedName(type_names);
    freeScopedName(type_values);
}


/*
 * Replace any template arguments in a signature.
 */
static void templateSignature(signatureDef *sd, int result, classTmplDef *tcd, templateDef *td, classDef *ncd)
{
    int a;

    if (result)
        templateType(&sd->result, tcd, td, ncd);

    for (a = 0; a < sd->nrArgs; ++a)
        templateType(&sd->args[a], tcd, td, ncd);
}


/*
 * Replace any template arguments in a type.
 */
static void templateType(argDef *ad, classTmplDef *tcd, templateDef *td, classDef *ncd)
{
    int a;
    char *name;

    /* Ignore if it isn't an unscoped name. */
    if (ad->atype != defined_type || ad->u.snd->next != NULL)
        return;

    name = ad->u.snd->name;

    for (a = 0; a < tcd->sig.nrArgs - 1; ++a)
        if (strcmp(name, scopedNameTail(tcd->sig.args[a].u.snd)) == 0)
        {
            ad->atype = td->types.args[a].atype;

            /* We take the constrained flag from the real type. */
            resetIsConstrained(ad);

            if (isConstrained(&td->types.args[a]))
                setIsConstrained(ad);

            ad->u = td->types.args[a].u;

            return;
        }

    /* Handle the class name itself. */
    if (strcmp(name, scopedNameTail(classFQCName(tcd->cd))) == 0)
    {
        ad->atype = class_type;
        ad->u.cd = ncd;
    }
}


/*
 * Replace any template arguments in a literal code block.
 */
codeBlock *templateCode(sipSpec *pt, ifaceFileList **used, codeBlock *ocb, scopedNameDef *names, scopedNameDef *values)
{
    codeBlock *ncb = NULL, **tail = &ncb;

    while (ocb != NULL)
    {
        char *at = ocb->frag;

        do
        {
            char *first = NULL;
            codeBlock *cb;
            scopedNameDef *nam, *val, *nam_first, *val_first;

            /*
             * Go through the rest of this fragment looking for
             * each of the types and the name of the class itself.
             */
            nam = names;
            val = values;

            while (nam != NULL && val != NULL)
            {
                char *cp;

                if ((cp = strstr(at, nam->name)) != NULL)
                    if (first == NULL || first > cp)
                    {
                        nam_first = nam;
                        val_first = val;
                        first = cp;
                    }

                nam = nam->next;
                val = val->next;
            }

            /* Create the new fragment. */
            cb = sipMalloc(sizeof (codeBlock));

            if (at == ocb->frag)
            {
                cb->filename = ocb->filename;
                cb->linenr = ocb->linenr;
            }
            else
                cb->filename = NULL;

            cb->next = NULL;
            *tail = cb;
            tail = &cb->next;

            /* See if anything was found. */
            if (first == NULL)
            {
                /* We can just point to this. */
                cb->frag = at;

                /* All done with this one. */
                at = NULL;
            }
            else
            {
                static char *gen_names[] = {
                    "sipForceConvertToTransfer_",
                    "sipForceConvertTo_",
                    "sipConvertFromTransfer_",
                    "sipConvertFrom_",
                    "sipClass_",
                    "sipEnum_",
                    "sipException_",
                    NULL
                };

                char *dp, *sp, **gn;
                int genname = FALSE;

                /*
                 * If the context in which the text is used is
                 * in the name of a SIP generated object then
                 * translate any "::" scoping to "_".
                 */
                for (gn = gen_names; *gn != NULL; ++gn)
                    if (search_back(first, at, *gn))
                    {
                        addUsedFromCode(pt, used, val_first->name);
                        genname = TRUE;
                        break;
                    }

                /* Fragment the fragment. */
                cb->frag = sipMalloc(first - at + strlen(val_first->name) + 1);

                strncpy(cb->frag, at, first - at);

                dp = &cb->frag[first - at];
                sp = val_first->name;

                if (genname)
                {
                    char gch;

                    while ((gch = *sp++) != '\0')
                        if (gch == ':' && *sp == ':')
                        {
                            *dp++ = '_';
                            ++sp;
                        }
                        else
                            *dp++ = gch;

                    *dp = '\0';
                }
                else
                    strcpy(dp, sp);

                /* Move past the replaced text. */
                at = first + strlen(nam_first->name);
            }
        }
        while (at != NULL && *at != '\0');

        ocb = ocb->next;
    }

    return ncb;
}


/*
 * Return TRUE if the text at the end of a string matches the target string.
 */
static int search_back(const char *end, const char *start, const char *target)
{
    size_t tlen = strlen(target);

    if (start + tlen >= end)
        return FALSE;

    return (strncmp(end - tlen, target, tlen) == 0);
}


/*
 * Add any needed interface files based on handwritten code.
 */
static void addUsedFromCode(sipSpec *pt, ifaceFileList **used, const char *sname)
{
    ifaceFileDef *iff;
    enumDef *ed;

    for (iff = pt->ifacefiles; iff != NULL; iff = iff->next)
    {
        if (iff->type != class_iface && iff->type != exception_iface)
            continue;

        if (sameName(iff->fqcname, sname))
        {
            addToUsedList(used, iff);

            return;
        }
    }

    for (ed = pt->enums; ed != NULL; ed = ed->next)
    {
        if (ed->ecd == NULL)
            continue;

        if (sameName(ed->fqcname, sname))
        {
            addToUsedList(used, ed->ecd->iff);

            return;
        }
    }
}


/*
 * Compare a scoped name with its string equivalent.
 */
static int sameName(scopedNameDef *snd, const char *sname)
{
    while (snd != NULL && *sname != '\0')
    {
        const char *sp = snd->name;

        while (*sp != '\0' && *sname != ':' && *sname != '\0')
            if (*sp++ != *sname++)
                return FALSE;

        if (*sp != '\0' || (*sname != ':' && *sname != '\0'))
            return FALSE;

        snd = snd->next;

        if (*sname == ':')
            sname += 2;
    }

    return (snd == NULL && *sname == '\0');
}


/*
 * Create a new typedef.
 */
static void newTypedef(sipSpec *pt,moduleDef *mod,char *name,argDef *type)
{
    typedefDef *td;
    scopedNameDef *fqname = text2scopedName(name);
    classDef *scope = currentScope();

    /* See if we are instantiating a template class. */
    if (type->atype == template_type)
    {
        classTmplDef *tcd;
        templateDef *td = type->u.td;

        for (tcd = pt->classtemplates; tcd != NULL; tcd = tcd->next)
            if (sameScopedName(tcd->cd->iff->fqcname, td->fqname))
            {
                if (!sameTemplateSignature(&tcd->sig, &td->types, FALSE))
                    continue;

                instantiateClassTemplate(pt, mod, scope, fqname, tcd, td);

                /* All done. */
                return;
            }
    }

    /* Check it doesn't already exist. */
    for (td = pt -> typedefs; td != NULL; td = td -> next)
        if (sameScopedName(td -> fqname,fqname))
        {
            fatalScopedName(fqname);
            fatal(" already defined\n");
        }

    td = sipMalloc(sizeof (typedefDef));

    td -> fqname = fqname;
    td -> ecd = scope;
    td -> module = mod;
    td -> type = *type;
    td -> next = pt -> typedefs;

    mod -> nrtypedefs++;

    pt -> typedefs = td;
}


/*
 * Return TRUE if the template signatures are the same.  A deep comparison is
 * used for mapped type templates where we want to recurse into any nested
 * templates.
 */
int sameTemplateSignature(signatureDef *sd1, signatureDef *sd2, int deep)
{
    int a;

    if (sd1->nrArgs != sd2->nrArgs)
        return FALSE;

    for (a = 0; a < sd1->nrArgs; ++a)
    {
        argDef *ad1 = &sd1->args[a];
        argDef *ad2 = &sd2->args[a];

        /*
         * If we are doing a shallow comparision (ie. for class
         * templates) then a type name on the left hand side matches
         * anything on the right hand side.
         */
        if (ad1->atype == defined_type && !deep)
            continue;

        /*
         * For type names only compare the references and pointers, and
         * do the same for any nested templates.
         */
        if (ad1->atype == defined_type && ad2->atype == defined_type)
        {
            if (isReference(ad1) != isReference(ad2) || ad1->nrderefs != ad2->nrderefs)
                return FALSE;
        }
        else if (ad1->atype == template_type && ad2->atype == template_type)
        {
            if (!sameTemplateSignature(&ad1->u.td->types, &ad2->u.td->types, deep))
                return FALSE;
        }
        else if (!sameBaseType(ad1, ad2))
            return FALSE;
    }

    return TRUE;
}


/*
 * Create a new variable.
 */
static void newVar(sipSpec *pt,moduleDef *mod,char *name,int isstatic,
           argDef *type,optFlags *of,codeBlock *acode,codeBlock *gcode,
           codeBlock *scode)
{
    varDef *var;
    classDef *escope = currentScope();
    nameDef *nd = cacheName(pt,getPythonName(of,name));

    if (inMainModule())
        setIsUsedName(nd);

    checkAttributes(pt,escope,nd -> text,FALSE);

    var = sipMalloc(sizeof (varDef));

    var -> pyname = nd;
    var -> fqcname = text2scopedName(name);
    var -> ecd = escope;
    var -> module = mod;
    var -> varflags = 0;
    var -> type = *type;
    var -> accessfunc = acode;
    var -> getcode = gcode;
    var -> setcode = scode;
    var -> next = pt -> vars;

    if (isstatic || (escope != NULL && escope->iff->type == namespace_iface))
        setIsStaticVar(var);

    pt -> vars = var;
}


/*
 * Create a new ctor.
 */
static void newCtor(char *name,int sectFlags,signatureDef *args,
            optFlags *optflgs,codeBlock *methodcode,
            throwArgs *exceptions,signatureDef *cppsig,int explicit)
{
    ctorDef *ct, **ctp;
    classDef *cd = currentScope();

    /* Check the name of the constructor. */
    if (strcmp(classBaseName(cd),name) != 0)
        yyerror("Constructor doesn't have the same name as its class");

    /* Add to the list of constructors. */
    ct = sipMalloc(sizeof (ctorDef));

    ct -> ctorflags = sectFlags;
    ct -> pysig = *args;
    ct -> cppsig = (cppsig != NULL ? cppsig : &ct -> pysig);
    ct -> exceptions = exceptions;
    ct -> methodcode = methodcode;
    ct -> next = NULL;

    if (!isPrivateCtor(ct))
        setCanCreate(cd);

    if (isProtectedCtor(ct))
        setHasShadow(cd);

    if (explicit)
        setIsExplicitCtor(ct);

    getHooks(optflgs,&ct -> prehook,&ct -> posthook);

    if (getReleaseGIL(optflgs))
        setIsReleaseGILCtor(ct);

    if (findOptFlag(optflgs,"NoDerived",bool_flag) != NULL)
    {
        if (cppsig != NULL)
            yyerror("The /NoDerived/ annotation cannot be used with a C++ signature");

        if (methodcode == NULL)
            yyerror("The /NoDerived/ annotation must be used with %MethodCode");

        ct->cppsig = NULL;
    }

    if (findOptFlag(optflgs,"Default",bool_flag) != NULL)
    {
        if (cd -> defctor != NULL)
            yyerror("A constructor with the /Default/ annotation has already been defined");

        cd -> defctor = ct;
    }

    /* Append to the list. */
    for (ctp = &cd->ctors; *ctp != NULL; ctp = &(*ctp)->next)
        ;

    *ctp = ct;
}


/*
 * Create a new function.
 */
static void newFunction(sipSpec *pt,moduleDef *mod,int sflags,int isstatic,
            int isvirt,char *name,signatureDef *sig,int isconst,
            int isabstract,optFlags *optflgs,codeBlock *methodcode,
            codeBlock *vcode,throwArgs *exceptions,
            signatureDef *cppsig)
{
    classDef *cd = currentScope();
    nameDef *pname;
    int factory, xferback;
    overDef *od, **odp, **headp;
    optFlag *of;
    virtHandlerDef *vhd;

    /* Extra checks for a C module. */
    if (pt -> genc)
    {
        if (cd != NULL)
            yyerror("Function declaration not allowed in a struct in a C module");

        if (isstatic)
            yyerror("Static functions not allowed in a C module");

        if (exceptions != NULL)
            yyerror("Exceptions not allowed in a C module");
    }

    headp = (cd != NULL ?  &cd -> overs : &pt -> overs);

    /* See if it is a factory method. */
    if (findOptFlag(optflgs,"Factory",bool_flag) != NULL)
        factory = TRUE;
    else
    {
        int a;

        factory = FALSE;

        /* Check /TransferThis/ wasn't specified. */
        if (cd == NULL || isstatic)
            for (a = 0; a < sig -> nrArgs; ++a)
                if (isThisTransferred(&sig -> args[a]))
                    yyerror("/TransferThis/ may only be specified in constructors and class methods");
    }

    /* See if the result is to be returned to Python ownership. */
    xferback = (findOptFlag(optflgs,"TransferBack",bool_flag) != NULL);

    if (factory && xferback)
        yyerror("/TransferBack/ and /Factory/ cannot both be specified");

    /* Use the C++ name if a Python name wasn't given. */
    pname = cacheName(pt, getPythonName(optflgs, name));

    /* Create a new overload definition. */

    od = sipMalloc(sizeof (overDef));

    /* Set the overload flags. */

    od -> overflags = sflags;

    if (factory)
        setIsFactory(od);

    if (xferback)
        setIsResultTransferredBack(od);

    if (isProtected(od))
        setHasShadow(cd);

    if ((isSlot(od) || isSignal(od)) && !isPrivate(od))
    {
        if (isSignal(od))
            setHasShadow(cd);

        pt -> sigslots = TRUE;
    }

    if (isSignal(od) && (methodcode != NULL || vcode != NULL))
        yyerror("Cannot provide code for signals");

    if (isstatic)
    {
        if (isSignal(od))
            yyerror("Static functions cannot be signals");

        if (isvirt)
            yyerror("Static functions cannot be virtual");

        setIsStatic(od);
    }

    if (isconst)
        setIsConst(od);

    if (isabstract)
    {
        if (sflags == 0)
            yyerror("Non-class function specified as abstract");

        setIsAbstract(od);
    }

    if ((of = findOptFlag(optflgs,"AutoGen",opt_name_flag)) != NULL)
    {
        setIsAutoGen(od);

        if (of -> fvalue.sval != NULL)
        {
            qualDef *qd;

            if ((qd = findQualifier(of -> fvalue.sval)) == NULL || qd -> qtype != feature_qualifier)
                yyerror("No such feature");

            if (excludedFeature(excludedQualifiers,qd))
                resetIsAutoGen(od);
        }
    }

    if (isvirt)
    {
        if (isSignal(od) && !optNoEmitters(pt))
            yyerror("Virtual signals aren't supported");

        setIsVirtual(od);
        setHasShadow(cd);

        vhd = sipMalloc(sizeof (virtHandlerDef));

        vhd -> virthandlernr = -1;
        vhd -> vhflags = 0;
        vhd -> pysig = &od -> pysig;
        vhd -> cppsig = (cppsig != NULL ? cppsig : &od -> pysig);
        vhd -> module = currentModule;
        vhd -> virtcode = vcode;
        vhd -> next = currentModule -> virthandlers;

        if (factory || xferback)
            setIsTransferVH(vhd);

        currentModule -> virthandlers = vhd;
    }
    else
    {
        if (vcode != NULL)
            yyerror("%VirtualCatcherCode provided for non-virtual function");

        vhd = NULL;
    }

    od -> cppname = name;
    od -> pysig = *sig;
    od -> cppsig = (cppsig != NULL ? cppsig : &od -> pysig);
    od -> exceptions = exceptions;
    od -> methodcode = methodcode;
    od -> virthandler = vhd;
    od -> common = findFunction(pt,mod,cd,pname,(methodcode != NULL),sig -> nrArgs);

    if (findOptFlag(optflgs,"Numeric",bool_flag) != NULL)
        setIsNumeric(od -> common);

    /* Methods that run in new threads must be virtual. */
    if (findOptFlag(optflgs,"NewThread",bool_flag) != NULL)
    {
        argDef *res;

        if (!isvirt)
            yyerror("/NewThread/ may only be specified for virtual functions");

        /*
         * This is an arbitary limitation to make the code generator
         * slightly easier - laziness on my part.
         */
        res = &od -> cppsig -> result;

        if (res -> atype != void_type || res -> nrderefs != 0)
            yyerror("/NewThread/ may only be specified for void functions");

        setIsNewThread(od);
    }

    getHooks(optflgs,&od -> prehook,&od -> posthook);

    if (getReleaseGIL(optflgs))
        setIsReleaseGIL(od);

    od -> next = NULL;

    /* Append to the list. */
    for (odp = headp; *odp != NULL; odp = &(*odp)->next)
        ;

    *odp = od;
}


/*
 * Return the Python name based on the C/C++ name and any /PyName/ annotation.
 */
static char *getPythonName(optFlags *optflgs, char *cname)
{
    char *pname;
    optFlag *of;

    if ((of = findOptFlag(optflgs, "PyName", name_flag)) != NULL)
        pname = of -> fvalue.sval;
    else
        pname = cname;

    return pname;
}


/*
 * Cache a name in a module.
 */
static nameDef *cacheName(sipSpec *pt,char *name)
{
    nameDef *nd;

    /* See if it already exists. */
    for (nd = pt -> namecache; nd != NULL; nd = nd -> next)
        if (strcmp(nd -> text,name) == 0)
            return nd;

    /* Create a new one. */
    nd = sipMalloc(sizeof (nameDef));

    nd -> nameflags = 0;
    nd -> module = currentSpec -> module;
    nd -> text = name;
    nd -> next = pt -> namecache;

    pt -> namecache = nd;

    return nd;
}


/*
 * Find (or create) an overloaded function name.
 */
static memberDef *findFunction(sipSpec *pt,moduleDef *mod,classDef *cd,
                   nameDef *pname,int hwcode,int nrargs)
{
    static struct slot_map {
        char *name;     /* The slot name. */
        slotType type;      /* The corresponding type. */
        int needs_hwcode;   /* If handwritten code is required. */
        int nrargs;     /* Nr. of arguments. */
    } slot_table[] = {
        {"__str__", str_slot, TRUE, 0},
        {"__unicode__", unicode_slot, TRUE, 0},
        {"__int__", int_slot, FALSE, 0},
        {"__long__", long_slot, FALSE, 0},
        {"__float__", float_slot, FALSE, 0},
        {"__len__", len_slot, TRUE, 0},
        {"__contains__", contains_slot, TRUE, 1},
        {"__add__", add_slot, FALSE, 1},
        {"__sub__", sub_slot, FALSE, 1},
        {"__mul__", mul_slot, FALSE, 1},
        {"__div__", div_slot, FALSE, 1},
        {"__mod__", mod_slot, FALSE, 1},
        {"__and__", and_slot, FALSE, 1},
        {"__or__", or_slot, FALSE, 1},
        {"__xor__", xor_slot, FALSE, 1},
        {"__lshift__", lshift_slot, FALSE, 1},
        {"__rshift__", rshift_slot, FALSE, 1},
        {"__iadd__", iadd_slot, FALSE, 1},
        {"__isub__", isub_slot, FALSE, 1},
        {"__imul__", imul_slot, FALSE, 1},
        {"__idiv__", idiv_slot, FALSE, 1},
        {"__imod__", imod_slot, FALSE, 1},
        {"__iand__", iand_slot, FALSE, 1},
        {"__ior__", ior_slot, FALSE, 1},
        {"__ixor__", ixor_slot, FALSE, 1},
        {"__ilshift__", ilshift_slot, FALSE, 1},
        {"__irshift__", irshift_slot, FALSE, 1},
        {"__invert__", invert_slot, FALSE, 0},
        {"__call__", call_slot, FALSE, -1},
        {"__getitem__", getitem_slot, FALSE, -1},
        {"__setitem__", setitem_slot, TRUE, -1},
        {"__delitem__", delitem_slot, TRUE, -1},
        {"__lt__", lt_slot, FALSE, 1},
        {"__le__", le_slot, FALSE, 1},
        {"__eq__", eq_slot, FALSE, 1},
        {"__ne__", ne_slot, FALSE, 1},
        {"__gt__", gt_slot, FALSE, 1},
        {"__ge__", ge_slot, FALSE, 1},
        {"__cmp__", cmp_slot, FALSE, 1},
        {"__nonzero__", nonzero_slot, TRUE, 0},
        {"__neg__", neg_slot, FALSE, 0},
        {"__pos__", pos_slot, FALSE, 0},
        {"__abs__", abs_slot, TRUE, 0},
        {"__repr__", repr_slot, TRUE, 0},
        {"__hash__", hash_slot, TRUE, 0},
        {NULL}
    };

    memberDef *md, **flist;
    struct slot_map *sm;
    slotType st;

    /* Get the slot type. */
    st = no_slot;

    for (sm = slot_table; sm -> name != NULL; ++sm)
        if (strcmp(sm -> name,pname -> text) == 0)
        {
            if (sm -> needs_hwcode && !hwcode)
                yyerror("This Python slot requires %MethodCode");

            if (sm -> nrargs < 0)
            {
                int min_nr;

                /* These require a minimum number. */
                switch (sm -> type)
                {
                case getitem_slot:
                case delitem_slot:
                    min_nr = 1;
                    break;

                case setitem_slot:
                    min_nr = 2;
                    break;

                default:
                    min_nr = 0;
                }

                if (nrargs < min_nr)
                    yyerror("Insufficient number of arguments to Python slot");
            }
            else if (cd == NULL)
            {
                /* Global operators need one extra argument. */
                if (sm -> nrargs + 1 != nrargs)
                    yyerror("Incorrect number of arguments to global operator");
            }
            else if (sm -> nrargs != nrargs)
                yyerror("Incorrect number of arguments to Python slot");

            st = sm -> type;

            break;
        }

    if (inMainModule())
        setIsUsedName(pname);

    /* Check there is no name clash. */
    checkAttributes(pt,cd,pname -> text,TRUE);

    /* See if it already exists. */
    flist = (cd != NULL ? &cd -> members : &pt -> othfuncs);

    for (md = *flist; md != NULL; md = md -> next)
        if (md -> pyname == pname && md -> module == mod)
            return md;

    /* Create a new one. */
    md = sipMalloc(sizeof (memberDef));

    md -> pyname = pname;
    md -> memberflags = 0;
    md -> slot = st;
    md -> module = mod;
    md -> next = *flist;

    *flist = md;

    /* Global operators are a subset. */
    if (cd == NULL && st != no_slot && st != neg_slot && st != pos_slot && !isNumberSlot(md) && !isRichCompareSlot(md))
        yyerror("Global operators must be either numeric or comparison operators");

    return md;
}


/*
 * Search a set of flags for a particular one and check its type.
 */
static optFlag *findOptFlag(optFlags *flgs,char *name,flagType ft)
{
    int f;

    for (f = 0; f < flgs -> nrFlags; ++f)
    {
        optFlag *of = &flgs -> flags[f];

        if (strcmp(of -> fname,name) == 0)
        {
            /*
             * An optional name can look like a boolean or a name.
             */

            if (ft == opt_name_flag)
            {
                if (of -> ftype == bool_flag)
                {
                    of -> ftype = opt_name_flag;
                    of -> fvalue.sval = NULL;
                }
                else if (of -> ftype == name_flag)
                    of -> ftype = opt_name_flag;
            }

            if (ft != of -> ftype)
                yyerror("Optional flag has a value of the wrong type");

            return of;
        }
    }

    return NULL;
}


/*
 * A name is going to be used as a Python attribute name within a Python scope
 * (ie. a Python dictionary), so check against what we already know is going in
 * the same scope in case there is a clash.
 */
static void checkAttributes(sipSpec *pt,classDef *pyscope,char *attr,int isfunc)
{
    enumDef *ed;
    varDef *vd;
    classDef *cd;

    /* Check the enums. */

    for (ed = pt -> enums; ed != NULL; ed = ed -> next)
    {
        enumMemberDef *emd;

        if (ed -> ecd != pyscope || ed -> pyname == NULL)
            continue;

        if (strcmp(ed->pyname->text, attr) == 0)
            yyerror("There is already an enum in scope with the same Python name");

        for (emd = ed -> members; emd != NULL; emd = emd -> next)
            if (strcmp(emd -> pyname -> text, attr) == 0)
                yyerror("There is already an enum member in scope with the same Python name");
    }

    /* Check the variables. */

    for (vd = pt -> vars; vd != NULL; vd = vd -> next)
    {
        if (vd -> ecd != pyscope)
            continue;

        if (strcmp(vd -> pyname -> text, attr) == 0)
            yyerror("There is already a variable in scope with the same Python name");
    }

    /*
     * Only check the members if this attribute isn't a member because we
     * can handle members with the same name in the same scope.
     */
    if (!isfunc)
    {
        memberDef *md, *membs;

        membs = (pyscope != NULL ? pyscope -> members : pt -> othfuncs);

        for (md = membs; md != NULL; md = md -> next)
        {
            overDef *od, *overs;

            if (strcmp(md -> pyname -> text, attr) != 0)
                continue;

            /* Check for a conflict with all overloads. */

            overs = (pyscope != NULL ? pyscope -> overs : pt -> overs);

            for (od = overs; od != NULL; od = od -> next)
            {
                if (od -> common != md)
                    continue;

                yyerror("There is already a function in scope with the same Python name");
            }
        }
    }

    /* Check the classes. */

    for (cd = pt -> classes; cd != NULL; cd = cd -> next)
    {
        if (cd -> ecd != pyscope || cd -> pyname == NULL)
            continue;

        if (strcmp(cd->pyname, attr) == 0 && !isExternal(cd))
            yyerror("There is already a class or namespace in scope with the same Python name");
    }

    /* Check the exceptions. */

    if (pyscope == NULL)
    {
        exceptionDef *xd;

        for (xd = pt->exceptions; xd != NULL; xd = xd->next)
            if (xd->pyname != NULL && strcmp(xd->pyname, attr) == 0)
                yyerror("There is already an exception with the same Python name");
    }
}


/*
 * Append a code block to a list of them.  Append is needed to give the
 * specifier easy control over the order of the documentation.
 */
static void appendCodeBlock(codeBlock **headp,codeBlock *new)
{
    while (*headp != NULL)
        headp = &(*headp) -> next;

    *headp = new;
}


/*
 * Handle the end of a fully parsed a file.
 */
static void handleEOF()
{
    /*
     * Check that the number of nested if's is the same as when we started
     * the file.
     */

    if (skipStackPtr > newContext.ifdepth)
        fatal("Too many %%If statements in %s\n",previousFile);

    if (skipStackPtr < newContext.ifdepth)
        fatal("Too many %%End statements in %s\n",previousFile);
}


/*
 * Handle the end of a fully parsed a module.
 */
static void handleEOM()
{
    /* Check it has been named. */

    if (currentModule -> name == NULL)
        fatal("No %%Module has been specified for module defined in %s\n",previousFile);

    /* The previous module is now current. */

    currentModule = newContext.prevmod;
}


/*
 * Find an existing qualifier.
 */
static qualDef *findQualifier(char *name)
{
    moduleDef *mod;

    for (mod = currentSpec -> modules; mod != NULL; mod = mod -> next)
    {
        qualDef *qd;

        for (qd = mod -> qualifiers; qd != NULL; qd = qd -> next)
            if (strcmp(qd -> name,name) == 0)
                return qd;
    }

    return NULL;
}


/*
 * Return a copy of a scoped name.
 */
scopedNameDef *copyScopedName(scopedNameDef *snd)
{
    scopedNameDef *head;

    head = NULL;

    while (snd != NULL)
    {
        appendScopedName(&head,text2scopePart(snd -> name));
        snd = snd -> next;
    }

    return head;
}


/*
 * Append a name to a list of scopes.
 */
void appendScopedName(scopedNameDef **headp,scopedNameDef *newsnd)
{
    while (*headp != NULL)
        headp = &(*headp) -> next;

    *headp = newsnd;
}


/*
 * Free a scoped name - but not the text itself.
 */
void freeScopedName(scopedNameDef *snd)
{
    while (snd != NULL)
    {
        scopedNameDef *next = snd -> next;

        free(snd);

        snd = next;
    }
}


/*
 * Convert a text string to a scope part structure.
 */
scopedNameDef *text2scopePart(char *text)
{
    scopedNameDef *snd;

    snd = sipMalloc(sizeof (scopedNameDef));

    snd -> name = text;
    snd -> next = NULL;

    return snd;
}


/*
 * Convert a text string to a fully scoped name.
 */
static scopedNameDef *text2scopedName(char *text)
{
    return scopeScopedName(text2scopePart(text));
}


/*
 * Prepend any current scope to a scoped name.
 */
static scopedNameDef *scopeScopedName(scopedNameDef *name)
{
    classDef *cd = currentScope();
    scopedNameDef *snd;

    snd = (cd != NULL ? copyScopedName(cd->iff->fqcname) : NULL);

    appendScopedName(&snd, name);

    return snd;
}


/*
 * Return a pointer to the tail part of a scoped name.
 */
char *scopedNameTail(scopedNameDef *snd)
{
    if (snd == NULL)
        return NULL;

    while (snd -> next != NULL)
        snd = snd -> next;

    return snd -> name;
}


/*
 * Push the given scope onto the scope stack.
 */
static void pushScope(classDef *scope)
{
    if (currentScopeIdx >= MAX_NESTED_SCOPE)
        fatal("Internal error: increase the value of MAX_NESTED_SCOPE\n");

    scopeStack[currentScopeIdx] = scope;
    sectFlagsStack[currentScopeIdx] = sectionFlags;

    ++currentScopeIdx;
}


/*
 * Pop the scope stack.
 */
static void popScope(void)
{
    if (currentScopeIdx > 0)
        sectionFlags = sectFlagsStack[--currentScopeIdx];
}


/*
 * Return non-zero if the current input should be parsed rather than be
 * skipped.
 */
static int notSkipping()
{
    return (skipStackPtr == 0 ? TRUE : skipStack[skipStackPtr - 1]);
}


/*
 * Return the value of an expression involving a time period.
 */
static int timePeriod(char *lname,char *uname)
{
    int this, line;
    qualDef *qd, *lower, *upper;
    moduleDef *mod;

    if (lname == NULL)
        lower = NULL;
    else if ((lower = findQualifier(lname)) == NULL || lower -> qtype != time_qualifier)
        yyerror("Lower bound is not a time version");

    if (uname == NULL)
        upper = NULL;
    else if ((upper = findQualifier(uname)) == NULL || upper -> qtype != time_qualifier)
        yyerror("Upper bound is not a time version");

    /* Sanity checks on the bounds. */

    if (lower == NULL && upper == NULL)
        yyerror("Lower and upper bounds cannot both be omitted");

    if (lower != NULL && upper != NULL)
    {
        if (lower -> module != upper -> module || lower -> line != upper -> line)
            yyerror("Lower and upper bounds are from different timelines");

        if (lower == upper)
            yyerror("Lower and upper bounds must be different");

        if (lower -> order > upper -> order)
            yyerror("Later version specified as lower bound");
    }

    /* Go through each slot in the relevant timeline. */

    if (lower != NULL)
    {
        mod = lower -> module;
        line = lower -> line;
    }
    else
    {
        mod = upper -> module;
        line = upper -> line;
    }

    this = FALSE;

    for (qd = mod -> qualifiers; qd != NULL; qd = qd -> next)
    {
        if (qd -> qtype != time_qualifier || qd -> line != line)
            continue;

        if (lower != NULL && qd -> order < lower -> order)
            continue;

        if (upper != NULL && qd -> order >= upper -> order)
            continue;

        /*
         * This is within the required range so if it is also needed
         * then the expression is true.
         */

        if (isNeeded(qd))
        {
            this = TRUE;
            break;
        }
    }

    return this;
}


/*
 * Return the value of an expression involving a single platform or feature.
 */
static int platOrFeature(char *name,int optnot)
{
    int this;
    qualDef *qd;

    if ((qd = findQualifier(name)) == NULL || qd -> qtype == time_qualifier)
        yyerror("No such platform or feature");

    /* Assume this sub-expression is false. */

    this = FALSE;

    if (qd -> qtype == feature_qualifier)
    {
        if (!excludedFeature(excludedQualifiers,qd))
            this = TRUE;
    }
    else if (isNeeded(qd))
        this = TRUE;

    if (optnot)
        this = !this;

    return this;
}


/*
 * Return TRUE if the given qualifier is excluded.
 */
int excludedFeature(stringList *xsl,qualDef *qd)
{
    while (xsl != NULL)
    {
        if (strcmp(qd -> name,xsl -> s) == 0)
            return TRUE;

        xsl = xsl -> next;
    }

    return FALSE;
}


/*
 * Return TRUE if the given qualifier is needed.
 */
static int isNeeded(qualDef *qd)
{
    stringList *sl;

    for (sl = neededQualifiers; sl != NULL; sl = sl -> next)
        if (strcmp(qd -> name,sl -> s) == 0)
            return TRUE;

    return FALSE;
}


/*
 * Return the current scope.  currentScope() is only valid if notSkipping()
 * returns non-zero.
 */
static classDef *currentScope(void)
{
    return (currentScopeIdx > 0 ? scopeStack[currentScopeIdx - 1] : NULL);
}


/*
 * Create a new qualifier.
 */
static void newQualifier(moduleDef *mod,int line,int order,char *name,qualType qt)
{
    qualDef *qd;

    /* Check it doesn't already exist. */

    if (findQualifier(name) != NULL)
        yyerror("Version is already defined");

    qd = sipMalloc(sizeof (qualDef));
    qd -> name = name;
    qd -> qtype = qt;
    qd -> module = mod;
    qd -> line = line;
    qd -> order = order;
    qd -> next = mod -> qualifiers;
    mod -> qualifiers = qd;
}


/*
 * Create a new imported module.
 */
static void newImport(char *name)
{
    moduleDef *from, *mod;
    moduleListDef *mld;

    /* Create a new module if it has already been imported. */
    for (mod = currentSpec -> modules; mod != NULL; mod = mod -> next)
        if (strcmp(mod -> file,name) == 0)
            break;

    from = currentModule;

    if (mod == NULL)
    {
        newModule(NULL,name);
        mod = currentModule;
    }

    /* Add the new import unless it has already been imported. */
    for (mld = from->imports; mld != NULL; mld = mld->next)
        if (mld->module == mod)
            return;

    mld = sipMalloc(sizeof (moduleListDef));
    mld -> module = mod;
    mld -> next = from->imports;

    from->imports = mld;
}


/*
 * Set up pointers to hook names.
 */
static void getHooks(optFlags *optflgs,char **pre,char **post)
{
    optFlag *of;

    if ((of = findOptFlag(optflgs,"PreHook",name_flag)) != NULL)
        *pre = of -> fvalue.sval;
    else
        *pre = NULL;

    if ((of = findOptFlag(optflgs,"PostHook",name_flag)) != NULL)
        *post = of -> fvalue.sval;
    else
        *post = NULL;
}


/*
 * Get the /ReleaseGIL/ option flag.
 */
static int getReleaseGIL(optFlags *optflgs)
{
    return (findOptFlag(optflgs,"ReleaseGIL",bool_flag) != NULL);
}


/*
 * Return TRUE if the QtNoEmitters option was specified.
 */
int optNoEmitters(sipSpec *pt)
{
    return optFind(pt, "QtNoEmitters");
}


/*
 * Return TRUE if the QtRegisterTypes option was specified.
 */
int optRegisterTypes(sipSpec *pt)
{
    return optFind(pt, "QtRegisterTypes");
}


/*
 * Return TRUE if a particular option was specified with %SIPOptions.
 */
static int optFind(sipSpec *pt, const char *opt)
{
    stringList *sl;

    for (sl = pt->options; sl != NULL; sl = sl->next)
        if (strcmp(sl->s, opt) == 0)
            return TRUE;

    return FALSE;
}

